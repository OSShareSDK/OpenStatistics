//
//  OSLaunch.h
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-3-6.
//  Copyright (c) 2014年 shareSDK. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OSLaunch : NSObject<NSCoding,NSCopying>

@property (nonatomic ,copy) NSString *sessionID;   //设备启动标识
@property (nonatomic ,copy) NSString *createDate;  //启动时间

@end
