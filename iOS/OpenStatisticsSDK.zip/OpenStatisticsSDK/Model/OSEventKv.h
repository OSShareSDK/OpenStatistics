//
//  OSEventKv.h
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-3-13.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OSEventKv : NSObject<NSCoding>

@property (nonatomic ,copy) NSString *sessionID;        //设备启动标识
@property (nonatomic ,strong) NSDate *createDate;       //创建时间
@property (nonatomic ,copy) NSString *eventKey;         //事件KEY
@property (nonatomic ,copy) NSString *page;             //访问页面
@property (nonatomic ,strong) NSDictionary *attributes; //事件标识字典

@property (nonatomic ,copy) NSString *label;       //事件标记
@property (nonatomic ,assign) NSInteger noticeNum; //消息数量
@property (nonatomic ,assign) NSInteger duration;  //访问时长（毫秒）

@end
