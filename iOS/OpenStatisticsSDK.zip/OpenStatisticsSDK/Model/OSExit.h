//
//  OSExit.h
//  OpenStatistics_Demo
//
//  Created by ljh on 14-4-25.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OSExit : NSObject<NSCoding>

@property (nonatomic ,copy) NSString *sessionID;   //设备启动标识
@property (nonatomic ,copy) NSString *createDate;  //启动时间
@property (nonatomic ,copy) NSString *endDate;     //退出时间

@end
