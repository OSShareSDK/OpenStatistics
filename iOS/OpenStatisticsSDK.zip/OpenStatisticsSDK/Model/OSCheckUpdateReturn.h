//
//  OSCheckUpdateReturn.h
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-3-9.
//  Copyright (c) 2014年 shareSDK. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OSCheckUpdateReturn : NSObject

@end
