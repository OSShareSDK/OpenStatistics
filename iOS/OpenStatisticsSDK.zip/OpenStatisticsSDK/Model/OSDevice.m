//
//  OSDevice.m
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-3-6.
//  Copyright (c) 2014年 shareSDK. All rights reserved.
//

#import "OSDevice.h"

@implementation OSDevice

#pragma mark - 
#pragma mark NSCoding

-(void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.deviceID forKey:@"deviceID"];
    [aCoder encodeObject:self.appVersion forKey:@"appVersion"];
    [aCoder encodeObject:self.appVersion forKey:@"appPackage"];
    [aCoder encodeInteger:self.platformID forKey:@"platformID"];
    [aCoder encodeObject:self.sdkVersion forKey:@"sdkVersion"];
    
    [aCoder encodeObject:self.channelName forKey:@"channelName"];
    [aCoder encodeObject:self.mac forKey:@"mac"];
    [aCoder encodeObject:self.model forKey:@"model"];
    [aCoder encodeObject:self.sysVersion forKey:@"sysVersion"];
    [aCoder encodeObject:self.carrier forKey:@"carrier"];
    
    [aCoder encodeObject:self.screenSize forKey:@"screenSize"];
    [aCoder encodeObject:self.factory forKey:@"factory"];
    [aCoder encodeObject:self.networkType forKey:@"networkType"];
    [aCoder encodeInteger:self.isJailbroken forKey:@"isJailbroken"];
    [aCoder encodeInteger:self.isPirated forKey:@"isPirated"];
    
    [aCoder encodeObject:self.longitude forKey:@"longitude"];
    [aCoder encodeObject:self.latitude forKey:@"latitude"];
    [aCoder encodeObject:self.language forKey:@"language"];
    [aCoder encodeObject:self.timeZone forKey:@"timeZone"];
    [aCoder encodeObject:self.cpu forKey:@"cpu"];
    
    [aCoder encodeObject:self.manuID forKey:@"manuID"];
    [aCoder encodeObject:self.manuTime forKey:@"manuTime"];
    
}

-(id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init])
    {
        self.deviceID = [aDecoder decodeObjectForKey:@"deviceID"];
        self.appVersion = [aDecoder decodeObjectForKey:@"appVersion"];
        self.appPackage = [aDecoder decodeObjectForKey:@"appPackage"];
        self.platformID = [aDecoder decodeIntegerForKey:@"platformID"];
        self.sdkVersion = [aDecoder decodeObjectForKey:@"sdkVersion"];
        
        self.channelName = [aDecoder decodeObjectForKey:@"channelName"];
        self.mac = [aDecoder decodeObjectForKey:@"mac"];
        self.model = [aDecoder decodeObjectForKey:@"model"];
        self.sysVersion = [aDecoder decodeObjectForKey:@"sysVersion"];
        self.carrier = [aDecoder decodeObjectForKey:@"carrier"];
        
        self.screenSize = [aDecoder decodeObjectForKey:@"screenSize"];
        self.factory = [aDecoder decodeObjectForKey:@"factory"];
        self.networkType = [aDecoder decodeObjectForKey:@"networkType"];
        self.isJailbroken = [aDecoder decodeIntegerForKey:@"isJailbroken"];
        self.isPirated = [aDecoder decodeIntegerForKey:@"isPirated"];
        
        self.longitude = [aDecoder decodeObjectForKey:@"longitude"];
        self.latitude = [aDecoder decodeObjectForKey:@"latitude"];
        self.language = [aDecoder decodeObjectForKey:@"language"];
        self.timeZone = [aDecoder decodeObjectForKey:@"timeZone"];
        self.cpu = [aDecoder decodeObjectForKey:@"cpu"];
        
        self.manuID = [aDecoder decodeObjectForKey:@"manuID"];
        self.manuTime = [aDecoder decodeObjectForKey:@"manuTime"];
        
    }
    return self;
}

- (void)dealloc
{
    [_deviceID release];
    [_appVersion release];
    [_appPackage release];
    [_sdkVersion release];
    
    [_channelName release];
    [_mac release];
    [_model release];
    [_sysVersion release];
    [_carrier release];
    
    [_screenSize release];
    [_factory release];
    [_networkType release];
    [_longitude release];
    [_latitude release];
    
    [_timeZone release];
    [_language release];
    [_cpu release];
    [_manuID release];
    [_manuTime release];
    
    [super dealloc];
}



@end






