//
//  OSCommonReturn.h
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-3-6.
//  Copyright (c) 2014年 shareSDK. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OSCommonReturn : NSObject

@property (nonatomic ) NSInteger status;                   //状态标识，=200成功,!=200失败
@property (nonatomic ,copy) NSString *message;             //提示信息
@property (nonatomic ,copy) NSMutableDictionary *result;   //返回数据

@end
