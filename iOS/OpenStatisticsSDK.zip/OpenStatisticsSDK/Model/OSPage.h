//
//  OSPage.h
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-3-6.
//  Copyright (c) 2014年 shareSDK. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OSPage : NSObject<NSCoding>

@property (nonatomic ,copy) NSString *sessionID;   //设备启动标识
@property (nonatomic ,strong) NSDate *startDate;   //开始时间
@property (nonatomic ,strong) NSDate *endDate;     //结束时间
@property (nonatomic ,copy) NSString *page;        //访问页面
@property (nonatomic ,assign) NSInteger duration;  //访问时长（毫秒）

@end
