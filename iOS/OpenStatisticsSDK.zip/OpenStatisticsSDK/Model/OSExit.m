//
//  OSExit.m
//  OpenStatistics_Demo
//
//  Created by ljh on 14-4-25.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "OSExit.h"
#define kSessionId  @"sessionID"
#define kCreateDate @"createDate"
#define kEndDate    @"endDate"

@implementation OSExit


#pragma mark NSCoding

-(void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.sessionID forKey:kSessionId];
    [aCoder encodeObject:self.createDate forKey:kCreateDate];
    [aCoder encodeObject:self.endDate forKey:kEndDate];
}


-(id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init])
    {
        self.sessionID = [aDecoder decodeObjectForKey:kSessionId];
        self.createDate = [aDecoder decodeObjectForKey:kCreateDate];
        self.endDate = [aDecoder decodeObjectForKey:kEndDate];
    }
    return self;
}


- (void)dealloc
{
    [_sessionID release];
    [_createDate release];
    [_endDate release];
    
    [super dealloc];
}

@end
