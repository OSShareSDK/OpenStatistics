//
//  OSEvent.m
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-3-6.
//  Copyright (c) 2014年 shareSDK. All rights reserved.
//

#import "OSEvent.h"

@implementation OSEvent

#pragma mark -
#pragma mark NSCoding
-(void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.sessionID forKey:@"sessionID"];
    [aCoder encodeObject:self.createDate forKey:@"createDate"];
    [aCoder encodeObject:self.eventKey forKey:@"eventKey"];
    [aCoder encodeObject:self.page forKey:@"page"];
    [aCoder encodeObject:self.label forKey:@"label"];
    
    [aCoder encodeInteger:self.noticeNum forKey:@"noticeNum"];
    [aCoder encodeInteger:self.duration forKey:@"duration"];
}

-(id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init])
    {
        self.sessionID = [aDecoder decodeObjectForKey:@"sessionID"];
        self.createDate = [aDecoder decodeObjectForKey:@"createDate"];
        self.eventKey = [aDecoder decodeObjectForKey:@"eventKey"];
        self.page = [aDecoder decodeObjectForKey:@"page"];
        self.label = [aDecoder decodeObjectForKey:@"label"];
        
        self.noticeNum = [aDecoder decodeIntegerForKey:@"noticeNum"];
        self.duration = [aDecoder decodeIntegerForKey:@"duration"];
    }
    return self;
}

-(void)dealloc
{
    [_sessionID release];
    [_createDate release];
    [_eventKey release];
    [_page release];
    [_label release];
    
    [super dealloc];
}


@end
