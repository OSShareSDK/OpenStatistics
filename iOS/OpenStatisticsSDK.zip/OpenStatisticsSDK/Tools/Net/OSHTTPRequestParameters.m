//
//  HTTPRequestParameters.m
//  CommonModule
//
//  Created by 冯 鸿杰 on 12-10-13.
//  Copyright (c) 2012年 掌淘科技. All rights reserved.
//

#import "CoreDefinition.h"
#import "OSHTTPRequestParameters.h"
#import "OSHTTPPostedFile.h"

@interface OSHTTPRequestParameters (Private)

/**
 *	@brief	进行URL编码
 *
 *	@param 	string 	需要编码的字符串
 *  @param  encoding    编码
 *
 *	@return	进行编码后的字符串
 */
- (NSString*)encodeURL:(NSString *)string encoding:(NSStringEncoding) encoding;

/**
 *	@brief	解析参数字符串
 *
 *	@param 	queryString 	参数字符串
 *
 *	@return	保存参数的字典对象
 */
- (NSDictionary *)parseQueryString:(NSString *)queryString;


@end

@implementation OSHTTPRequestParameters

@synthesize parameterDictionary = _parameterDict;

- (id)init
{
    if (self = [super init])
    {
        _parameterDict = [[NSMutableDictionary alloc] init];
    }
    return self;
}

- (id)initWithQueryString:(NSString *)queryString
{
    if (self = [self init])
    {
        //解析字符串
        NSDictionary *paramsDict = [self parseQueryString:queryString];
        [_parameterDict setDictionary:paramsDict];
    }
    return self;
}

- (id)initWithURL:(NSURL *)url
{
    if (self = [self initWithQueryString:url.query])
    {
        
    }
    return self;
}

- (void)dealloc
{
    SAFE_RELEASE(_parameterDict);
    [super dealloc];
}

- (void)addParameterWithName:(NSString *)name value:(id)value
{
    if (value == nil)
    {
        value = [NSNull null];
    }
    [_parameterDict setObject:value forKey:name];
}

- (void)addParameters:(OSHTTPRequestParameters *)parameters
{
    [self addParametersWithDictionary:parameters.parameterDictionary];
}

- (void)addParametersWithDictionary:(NSDictionary *)dictionary
{
    NSArray *keys = [dictionary allKeys];
    for (int i = 0; i < [keys count]; i++)
    {
        NSString *keyName = [keys objectAtIndex:i];
        id value = [_parameterDict objectForKey:keyName];
        if (value)
        {
            //合并多个值
            NSMutableArray *newValue = nil;
            if ([value isKindOfClass:[NSArray class]])
            {
                newValue = [NSMutableArray arrayWithArray:value];
                [newValue addObject:[dictionary objectForKey:keyName]];
            }
            else if (![value isKindOfClass:[NSNull class]])
            {
                newValue = [NSMutableArray arrayWithObjects:
                            value,
                            [dictionary objectForKey:keyName],
                            nil];
            }
            else
            {
                newValue = [NSMutableArray arrayWithObject:value];
            }
            
            [_parameterDict setObject:newValue forKey:keyName];
        }
        else
        {
            [_parameterDict setObject:[dictionary objectForKey:keyName] forKey:keyName];
        }
    }
}

- (void)removeParameterWithName:(NSString *)name
{
    [_parameterDict removeObjectForKey:name];
}

- (id)getValueForName:(NSString *)name
{
    return [_parameterDict objectForKey:name];
}

- (void)clear
{
    [_parameterDict removeAllObjects];
}

- (NSData *)dataUsingEncoding:(NSStringEncoding)encoding
{
    return [[self stringUsingEncoding:encoding] dataUsingEncoding:encoding];
}

- (NSString *)stringUsingEncoding:(NSStringEncoding)encoding
{
    NSMutableString *requestString = [NSMutableString string];
    
    NSArray *keyArray = [_parameterDict allKeys];
    NSInteger keyCount = [keyArray count] - 1;
    for (int i = 0; i < [keyArray count]; i++ )
    {
        NSString *keyString = [keyArray objectAtIndex:i];
        id value = [_parameterDict objectForKey:keyString];
        if ([value isKindOfClass:[NSArray class]])
        {
            for (int j = 0; j < [value count]; j++)
            {
                NSString *valueString = [[value objectAtIndex:j] isKindOfClass:[NSNull class]] ? @"" : [NSString stringWithFormat:@"%@",[value objectAtIndex:j]];
                
                NSString *dataString = [NSString stringWithFormat:
                                        @"%@=%@%@",
                                        [self encodeURL:keyString encoding:encoding],
                                        [self encodeURL:valueString encoding:encoding],
                                        (i < keyCount || j < [value count] - 1 ? @"&" : @"")];
                [requestString appendString:dataString];
            }
        }
        else if ([value isKindOfClass:[NSData class]])
        {
            NSString *valueString = [[[NSString alloc] initWithData:value encoding:encoding] autorelease];
            NSString *dataString = [NSString stringWithFormat:
                                    @"%@=%@%@",
                                    [self encodeURL:keyString encoding:encoding],
                                    valueString,
                                    (i < keyCount ? @"&" : @"")];
            [requestString appendString:dataString];
        }
        else if ([value isKindOfClass:[OSHTTPPostedFile class]])
        {
            NSString *valueString = [[[NSString alloc] initWithData:((OSHTTPPostedFile *)value).fileData encoding:encoding] autorelease];
            NSString *dataString = [NSString stringWithFormat:
                                    @"%@=%@%@",
                                    [self encodeURL:keyString encoding:encoding],
                                    valueString,
                                    (i < keyCount ? @"&" : @"")];
            [requestString appendString:dataString];
        }
        else
        {
            NSString *valueString = [[_parameterDict objectForKey:keyString] isKindOfClass:[NSNull class]] ? @"" : [NSString stringWithFormat:@"%@",[_parameterDict objectForKey:keyString]];
            
            NSString *dataString = [NSString stringWithFormat:
                                    @"%@=%@%@",
                                    [self encodeURL:keyString encoding:encoding],
                                    [self encodeURL:valueString encoding:encoding],
                                    (i < keyCount ? @"&" : @"")];
            [requestString appendString:dataString];
        }
    }
    
    return requestString;
}

- (NSData *)multipartDataUsingEncoding:(NSStringEncoding)encoding boundary:(NSString *)boundary
{
	NSMutableData *postData = [NSMutableData data];
    [postData appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:encoding]];
	
	NSData *endItemBoundaryData = [[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:encoding];
    
    NSArray *keyArray = [_parameterDict allKeys];
    NSInteger keyCount = [keyArray count] - 1;
    for (int i = 0; i < [keyArray count]; i++)
    {
        NSString *keyString = [keyArray objectAtIndex:i];
        id value = [_parameterDict objectForKey:keyString];

        if ([value isKindOfClass:[NSArray class]])
        {
            for (int j = 0; j < [value count]; j++)
            {
                id item = [value objectAtIndex:j];
                if ([item isKindOfClass:[NSData class]])
                {
                    [postData appendData:[[NSString stringWithFormat:
                                           @"Content-Disposition: form-data; name=\"%@\"\r\n\r\n",
                                           keyString]
                                          dataUsingEncoding:encoding]];
                    [postData appendData:item];
                }
                else if ([item isKindOfClass:[OSHTTPPostedFile class]])
                {
                    [postData appendData:[[NSString stringWithFormat:
                                           @"Content-Disposition: form-data; name=\"%@\"; filename=\"%@\"\r\n",
                                           keyString,
                                           ((OSHTTPPostedFile *)item).fileName]
                                          dataUsingEncoding:encoding]];
                    
                    if (((OSHTTPPostedFile *)item).transferEncoding)
                    {
                        [postData appendData:[[NSString stringWithFormat:
                                               @"Content-Type: %@\r\n",
                                               ((OSHTTPPostedFile *)item).contentType]
                                              dataUsingEncoding:encoding]];
                        [postData appendData:[[NSString stringWithFormat:
                                               @"Content-Transfer-Encoding: %@\r\n\r\n",
                                               ((OSHTTPPostedFile *)item).transferEncoding] dataUsingEncoding:encoding]];
                    }
                    else
                    {
                        [postData appendData:[[NSString stringWithFormat:
                                               @"Content-Type: %@\r\n\r\n",
                                               ((OSHTTPPostedFile *)item).contentType]
                                              dataUsingEncoding:encoding]];
                    }
                    
                    [postData appendData:((OSHTTPPostedFile *)item).fileData];
                }
                else
                {
                    NSString *valueString = [item isKindOfClass:[NSNull class]] ? @"" : [NSString stringWithFormat:@"%@",item];
                    
                    [postData appendData:[[NSString stringWithFormat:
                                           @"Content-Disposition: form-data; name=\"%@\"\r\n\r\n",
                                           keyString]
                                          dataUsingEncoding:encoding]];
                    [postData appendData:[valueString dataUsingEncoding:encoding]];
                }
                
                if (i < keyCount || j < [value count] - 1)
                {
                    [postData appendData:endItemBoundaryData];
                }
            }
        }
        else if ([value isKindOfClass:[NSData class]])
        {
            [postData appendData:[[NSString stringWithFormat:
                                   @"Content-Disposition: form-data; name=\"%@\"\r\n\r\n",
                                   keyString]
                                  dataUsingEncoding:encoding]];
            [postData appendData:value];
            
            if (i < keyCount)
            {
                [postData appendData:endItemBoundaryData];
            }
        }
        else if ([value isKindOfClass:[OSHTTPPostedFile class]])
        {
            [postData appendData:[[NSString stringWithFormat:
                                   @"Content-Disposition: form-data; name=\"%@\"; filename=\"%@\"\r\n",
                                   keyString,
                                   ((OSHTTPPostedFile *)value).fileName]
                                  dataUsingEncoding:encoding]];
            
            if (((OSHTTPPostedFile *)value).transferEncoding)
            {
                [postData appendData:[[NSString stringWithFormat:
                                       @"Content-Type: %@\r\n",
                                       ((OSHTTPPostedFile *)value).contentType]
                                      dataUsingEncoding:encoding]];
                [postData appendData:[[NSString stringWithFormat:
                                       @"Content-Transfer-Encoding: %@\r\n\r\n",
                                       ((OSHTTPPostedFile *)value).transferEncoding] dataUsingEncoding:encoding]];
            }
            else
            {
                [postData appendData:[[NSString stringWithFormat:
                                       @"Content-Type: %@\r\n\r\n",
                                       ((OSHTTPPostedFile *)value).contentType]
                                      dataUsingEncoding:encoding]];
            }
            
            [postData appendData:((OSHTTPPostedFile *)value).fileData];
            
            if (i < keyCount)
            {
                [postData appendData:endItemBoundaryData];
            }
        }
        else
        {
            NSString *valueString = [value isKindOfClass:[NSNull class]] ? @"" : [NSString stringWithFormat:@"%@",value];

            [postData appendData:[[NSString stringWithFormat:
                                   @"Content-Disposition: form-data; name=\"%@\"\r\n\r\n",
                                   keyString]
                                  dataUsingEncoding:encoding]];
            [postData appendData:[valueString dataUsingEncoding:encoding]];
            
            if (i < keyCount)
            {
                [postData appendData:endItemBoundaryData];
            }
        }
    }
	
    [postData appendData:[[NSString stringWithFormat:
                           @"\r\n--%@--\r\n",
                           boundary]
                          dataUsingEncoding:encoding]];
    
    return postData;
}

#pragma mark - Private

- (NSString*)encodeURL:(NSString *)string encoding:(NSStringEncoding)encoding
{
	NSString *newString = [NSMakeCollectable(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (CFStringRef)string, NULL, CFSTR(":/?#[]@!$ &'()*+,;=\"<>%{}|\\^~`"), CFStringConvertNSStringEncodingToEncoding(encoding))) autorelease];
	if (newString)
    {
		return newString;
	}
	return @"";
}

- (NSDictionary *)parseQueryString:(NSString *)queryString
{
    NSMutableDictionary *keyValueDict = [NSMutableDictionary dictionary];
    NSArray *keyValueStringArray = [queryString componentsSeparatedByString:@"&"];
    for (int i = 0; i < [keyValueStringArray count]; i++)
    {
        NSString *keyValueString = [keyValueStringArray objectAtIndex:i];
        NSArray *keyValueArray = [keyValueString componentsSeparatedByString:@"="];
        if ([keyValueArray count] > 0)
        {
            NSString *keyString = [keyValueArray objectAtIndex:0];
            NSString *valueString = @"";
            if ([keyValueArray count] > 1)
            {
                valueString = [keyValueArray objectAtIndex:1];
            }
            [keyValueDict setObject:valueString forKey:keyString];
        }
    }
    
    return keyValueDict;
}

@end
