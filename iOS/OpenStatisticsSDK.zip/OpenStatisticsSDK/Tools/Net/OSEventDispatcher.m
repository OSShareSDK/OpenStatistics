//
//  EventDispatcher.m
//  MeYou
//
//  Created by hower on 5/27/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "OSEventDispatcher.h"
#import "CoreDefinition.h"


@implementation OSEventDispatcher 

- (id)init
{
	if (self = [super init])
    {
		_handle = [[NSNotificationCenter alloc] init];
	}
	return self;
}

- (void)dealloc
{
    SAFE_RELEASE(_handle);
	[super dealloc];
}

- (void)addNotificationWithName:(NSString *)name
                         target:(id)target
                         action:(SEL)action
{
    [_handle addObserver:target selector:action name:name object:nil];
}

- (void)removeNotificationWithName:(NSString *)name
                            target:(id)target
{
    [_handle removeObserver:target name:name object:nil];
}

- (void)removeAllNotificationWithTarget:(id)target
{
    [_handle removeObserver:target];
}

- (void)postNotificationWithName:(NSString *)name data:(NSDictionary *)data
{
    [_handle postNotificationName:name object:self userInfo:data];
}

@end
