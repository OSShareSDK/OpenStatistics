//
//  NSString+Common.m
//  Common
//
//  Created by vimfung on 12-8-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "NSString+Common.h"
#import "NSData+Common.h"
#import <CommonCrypto/CommonDigest.h>



@implementation NSString (Common)


- (NSString *)sha1String
{
    unsigned char result[CC_SHA1_DIGEST_LENGTH];
    const char *cStr = [self UTF8String];
    CC_SHA1(cStr, strlen(cStr), result);
    
    NSMutableString *ret = [NSMutableString stringWithCapacity:CC_SHA1_DIGEST_LENGTH];
    for (int i = 0; i < CC_SHA1_DIGEST_LENGTH; i++)
    {
        [ret appendFormat:@"%02X",result[i]];
    }
    return  ret;
}

- (NSString *)md5HexDigestString
{
    const char* str = [self UTF8String];
    unsigned char result[CC_MD5_DIGEST_LENGTH];
    CC_MD5(str, strlen(str), result);
    NSMutableString *ret = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH];
    
    for(int i = 0; i<CC_MD5_DIGEST_LENGTH; i++) {
        [ret appendFormat:@"%02X",result[i]];
    }
    return ret;
}

- (NSString *)md5DHexDigestString
{
    const char* str = [self UTF8String];
    unsigned char result[32];
    CC_MD5(str, strlen(str), result);
    NSMutableString *ret = [NSMutableString stringWithCapacity:32];
    
    for(int i = 0; i < 32; i++) {
        [ret appendFormat:@"%02X",result[i]];
    }
    return ret;
}

- (long long)hexValue
{
    return strtoull([self UTF8String], nil, 16);
}

@end
