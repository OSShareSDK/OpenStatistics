//
//  BaseViewController.h
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-3-13.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@end
