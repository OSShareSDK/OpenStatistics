//
//  HomeViewController.m
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-3-13.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "HomeViewController.h"
#import "OpenStatistics.h"

@interface HomeViewController ()

@end

@implementation HomeViewController


#pragma mark - the lifecycle of view
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"首页";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.data = [NSArray arrayWithObjects:@"Mac Pro", @"Mac mini", @"iMac",
                 @"MacBook", @"MacBook Pro", @"MacBook Air", nil];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    NSIndexPath *tableSelection = [self.tableView indexPathForSelectedRow];
	[self.tableView deselectRowAtIndexPath:tableSelection animated:NO];
    
    //页面开始
    [OpenStatistics beginLogPageView:@"HomePage"];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    //页面结束
    [OpenStatistics endLogPageView:@"HomePage"];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}


-(void)dealloc
{
     self.data = nil ;
    [super dealloc];
}


#pragma mark - UITableViewDelegate and UITableViewDataSource

//表视图行数
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.data count];
}

//单元格数据
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *TableViewCellIdentifier = @"cellID";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:TableViewCellIdentifier];
	if (cell == nil)
	{
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:TableViewCellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		cell.selectionStyle = UITableViewCellSelectionStyleBlue;   //缺省
	}
    
	cell.textLabel.text = [self.data objectAtIndex:indexPath.row];
	return cell;
}

//选择单元格触发
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
	self.subLevel.title = cell.textLabel.text;
    NSLog(@"%@被触发",cell.textLabel.text);
    
    //使用事件接口
    [OpenStatistics event:@"btn_click" label:cell.textLabel.text];
    
    _subLevel = [[SubLevelViewController alloc] init];
    [self.navigationController pushViewController:_subLevel animated:YES];
}

@end
