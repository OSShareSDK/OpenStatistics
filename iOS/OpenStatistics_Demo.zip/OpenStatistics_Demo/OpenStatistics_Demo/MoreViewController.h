//
//  MoreViewController.h
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-3-13.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "BaseViewController.h"
#import "CustomCell.h"
#import "OSRefreshTableHeaderView.h"
@class SubLevelViewController;

@interface MoreViewController : BaseViewController<UITableViewDataSource,UITableViewDelegate,OSRefreshTableHeaderDelegate>
{
    UIActivityIndicatorView *_activityView;
    OSRefreshTableHeaderView *_refreshHeaderView;  //下拉刷新
    BOOL _reloading;    //标识是否刷新
}

@property (nonatomic, strong) SubLevelViewController *subLevel;   //子视图
@property (nonatomic, retain) IBOutlet UITableView *tableView;    //
@property (nonatomic, retain) NSArray *listArray;


@end
