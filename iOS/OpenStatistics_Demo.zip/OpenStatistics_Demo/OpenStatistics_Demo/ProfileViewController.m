//
//  ProfileViewController.m
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-3-13.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "ProfileViewController.h"
#import "OpenStatistics.h"

@interface ProfileViewController ()

@end

NSString *kBadgeValuePrefKey = @"kBadgeValue";
@implementation ProfileViewController


#pragma mark - the lifeCycle of view
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"个人中心";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //完成按钮
    UIBarButtonItem *doneItem = [[UIBarButtonItem alloc]
                                   initWithTitle:@"done"
                                   style:UIBarButtonItemStyleBordered
                                   target:self
                                   action:@selector(doneAction:)];
    
    self.navigationItem.rightBarButtonItem = [doneItem autorelease];
}

//完成按钮
- (void)doneAction:(id)sender
{
	[self.badgeField resignFirstResponder];
    
    [OpenStatistics endEvent:@"btn_click" label:@"mark"];
	
	if (self.badgeField.text.length > 0)
	{
        _showValue.text = self.badgeField.text;
        
	}
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)dealloc
{
    [_badgeField release];
    [_showValue release];
    [super dealloc];
}


#pragma mark - 页面开始和结束
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [OpenStatistics beginLogPageView:@"Profile"];
    
    NSString *badgeValue = [[NSUserDefaults standardUserDefaults] stringForKey:kBadgeValuePrefKey];
	if (badgeValue.length != 0)
    {
        self.badgeField.text = badgeValue;
    }
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [OpenStatistics endLogPageView:@"Profile"];
    
    [[NSUserDefaults standardUserDefaults] setValue:self.badgeField.text forKey:kBadgeValuePrefKey];
}


#pragma mark - UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
	BOOL result = YES;
	
	// restrict the maximum number of characters to 5
	if (textField.text.length == 5 && string.length > 0)
		result = NO;
	
	return result;
}
@end
