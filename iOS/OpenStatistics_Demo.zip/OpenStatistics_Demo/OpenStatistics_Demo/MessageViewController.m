//
//  MessageViewController.m
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-3-13.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "MessageViewController.h"
#import "SubLevelViewController.h"
#import "OpenStatistics.h"

@interface MessageViewController ()

@property (nonatomic ,strong) NSArray *dataArray;
@property (nonatomic ,strong) SubLevelViewController *subLevel;

@end

@implementation MessageViewController


#pragma mark - the lifeCycle of view
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"消息";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.dataArray = [NSArray arrayWithObjects:@"iPod", @"iPod touch", @"iPod nano", @"iPod shuffle", nil];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    //页面开始
    [OpenStatistics beginLogPageView:@"Message"];
    
    [OpenStatistics beginEvent:@"btn_click" label:@"mark"];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    //页面结束
    [OpenStatistics endLogPageView:@"Message"];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


#pragma mark - UITableViewDelegate and UITableViewDataSource
//表视图行数
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

//单元格
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cellID";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleBlue;
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    cell.textLabel.text = [self.dataArray objectAtIndex:indexPath.row];
    return cell;
    [cell release];
    
}

//选择单元格触发
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
	_subLevel.title = cell.textLabel.text;
    _subLevel = [[SubLevelViewController alloc] init];
    
    [self.navigationController pushViewController:_subLevel animated:YES];
    
}


-(void)dealloc
{
    self.dataArray = nil ;
    [super dealloc];
}

@end
