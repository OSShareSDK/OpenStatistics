//
//  MainViewController.m
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-3-13.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "MainViewController.h"
#import "HomeViewController.h"
#import "MessageViewController.h"
#import "ProfileViewController.h"
#import "DiscoverViewController.h"
#import "MoreViewController.h"

#import "BaseNavigationController.h"

@interface MainViewController ()

@end

@implementation MainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        //隐藏系统自带的TabBar工具栏
        self.tabBar.hidden = YES;
        
    }
    return self;
}

#pragma mark - the lifeCycle of view
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self _initViewController];
    [self _initTabBarView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/**
 *	@brief	初始化控制器，加一个下划线区别和系统的类
 *
 *	@return	void
 */
- (void) _initViewController
{
    HomeViewController *home = [[HomeViewController alloc] init];
    MessageViewController *message = [[MessageViewController alloc] init];
    ProfileViewController *profile = [[ProfileViewController alloc] init];
    DiscoverViewController *discover = [[DiscoverViewController alloc] init];
    MoreViewController *more = [[MoreViewController alloc] init];
    
    //视图控制器数组
    NSArray *views = [NSArray arrayWithObjects:home,message,profile,discover,more,nil];
    NSMutableArray *viewControllers = [NSMutableArray arrayWithCapacity:5];
    for (UIViewController *viewController in views)
    {
        BaseNavigationController *nav = [[BaseNavigationController alloc] initWithRootViewController:viewController];
        [viewControllers addObject:nav];
        [nav release];
    }
    
    self.viewControllers = viewControllers;
    [home release];
    [message release];
    [profile release];
    [discover release];
    [more release];
}



/**
 *	@brief	初始化标签栏控制器：创建一个UIView，再添加5个按钮
 */
-(void)_initTabBarView
{
    _tabBarView = [[UIView alloc] initWithFrame:CGRectMake(0.0, ScreenHeight-49, ScreenWidth, 49)];
    _tabBarView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"tabbar_background.png"]];
    [self.view addSubview:_tabBarView];
    
    NSArray *background = @[@"tabbar_home.png",
                            @"tabbar_message_center.png",
                            @"tabbar_profile.png",
                            @"tabbar_discover.png",
                            @"tabbar_more.png"];
    
    NSArray *highlightedBackground = @[@"tabbar_home_highlighted.png",
                                       @"tabbar_message_center_highlighted.png",
                                       @"tabbar_profile_highlighted.png",
                                       @"tabbar_discover_highlighted.png",
                                       @"tabbar_more_highlighted.png"];
    
    //添加加5个按钮:normal和高亮下
    for (int i=0; i<background.count; i++)
    {
        NSString *backImage = background[i];
        NSString *highlightedImage = highlightedBackground[i];
        
        UIButton *button=[UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake((ScreenWidth/5-30)/2+(i*ScreenWidth/5), (49-30)/2, 30.0, 30.0);  //图片的长度和宽度：30、（320/5)
        
        button.tag=i;
        [button setImage:[UIImage imageNamed:backImage] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:highlightedImage] forState:UIControlStateHighlighted];
        
        //当点击图片按钮时触发
        [button addTarget:self action:@selector(selectedTab:) forControlEvents:UIControlEventTouchUpInside];
        [_tabBarView addSubview:button];
    }
}


//标签被选择
-(void) selectedTab:(UIButton *)button
{
    self.selectedIndex = button.tag;
}



@end
