//
//  MoreViewController.m
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-3-13.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "MoreViewController.h"
#import "SubLevelViewController.h"
#import "OpenStatistics.h"

@interface MoreViewController ()

@property (nonatomic ,strong) NSArray *dataArray;

@end

@implementation MoreViewController

#pragma mark - the lifeCycle of view
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"更多";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _dataArray = @[@"Featured",@"Favourites"];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    //页面的开始
//    [OpenStatistics beginLogPageView:@"More"];
//    [OpenStatistics beginEvent:@"btn_click"];
//    [OpenStatistics beginEvent:@"btn_click" label:@"music"];

    NSDictionary *dic = @{@"A":@"a",@"B":@"b",@"C":@"c"};
    [OpenStatistics beginEvent:@"btn_click" primarykey:@"music" attributes:dic];
    
    
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    //页面的结束
//    [OpenStatistics endLogPageView:@"More"];
//    [OpenStatistics endEvent:@"btn_click"];
//    [OpenStatistics endEvent:@"btn_click" label:@"music"];
    
    [OpenStatistics endEvent:@"btn_click" primarykey:@"music"];
}

#pragma mark - UITableViewDelegate and UITableViewDataSource
//表视图行数
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

//单元格
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cellID";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleBlue;
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    cell.textLabel.text = [self.dataArray objectAtIndex:indexPath.row];
    return cell;
    
    [cell release];
}

//选择单元格触发
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
	_subLevel.title = cell.textLabel.text;
    _subLevel = [[SubLevelViewController alloc] init];
    
    [self.navigationController pushViewController:_subLevel animated:YES];
}



@end
