//
//  MoreViewController.m
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-3-13.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "MoreViewController.h"
#import "OpenStatistics.h"
#import "OSRecommendedList.h"
#import "OSCommonReturn.h"
#import "OSJSONKit.h"

#import "CustomCell.h"

@interface MoreViewController ()

@property (nonatomic ,strong) NSArray *dataArray;

@end

@implementation MoreViewController

#pragma mark - the lifeCycle of view
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"推荐列表";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //隐藏表视图，加入活动指示器
    self.tableView.hidden = YES;
    _activityView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    _activityView.center = CGPointMake(self.view.frame.size.width*0.5, self.view.frame.size.height *0.5);
    [self.view addSubview:_activityView];
    [_activityView startAnimating];
    
    //请求加载推荐列表数据
//    [self loadRecommendedListData];
//    [NSThread detachNewThreadSelector:@selector(loadRecommendedListData) toTarget:self withObject:nil];
    [self performSelectorInBackground:@selector(loadRecommendedListData) withObject:self];
    
    
    if (_refreshHeaderView == nil)
    {
        //初始化下拉控件
        _refreshHeaderView = [[OSRefreshTableHeaderView alloc] initWithFrame:CGRectMake(0.0f, 0.0f - self.view.bounds.size.height,self.view.frame.size.width ,self.view.bounds.size.height ) arrowImage:[UIImage imageNamed:@"blueArrow.png"] textColor:nil];
        _refreshHeaderView.delegate = self;
        [self.tableView addSubview:_refreshHeaderView];
        [_refreshHeaderView refreshLastUpdatedDate];
        
        [_refreshHeaderView release];
    }
    
}

- (void)loadRecommendedListData
{
    //加载数据
    OSRecommendedList *recomend = [[OSRecommendedList alloc] init];
    [recomend getReconmendedListWithResult:^(id responder)
     {
         NSLog(@"get recommended list");
         OSCommonReturn *result = [[OSCommonReturn alloc] init];
         result.status = [[responder objectForKey:@"status"] intValue];
         result.message = [responder objectForKey:@"msg"];
         result.result = [responder objectForKey:@"res"];
         
         if (result.status == 200)
         {
             NSLog(@"请求推荐列表数据成功");
//             NSLog(@"result:%@",result.result);
             self.dataArray = [result.result objectForKey:@"item"];
         }else
         {
             NSLog(@"请求推荐列表数据失败");
         }
         
         [result release];
         
         [self.tableView reloadData];    //重新加载数据
         _reloading = NO;
         [_refreshHeaderView refreshScrollViewDataSourceDidFinishedLoading:self.tableView];
         
         [_activityView stopAnimating];  //活动指示器停止
         self.tableView.hidden = NO;     //显示表视图
         
     }];
    
    [recomend release];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    //页面的开始
    //    [OpenStatistics beginLogPageView:@"More"];
    //    [OpenStatistics beginEvent:@"btn_click"];
    //    [OpenStatistics beginEvent:@"btn_click" label:@"music"];
    
    NSDictionary *dic = @{@"A":@"a",@"B":@"b",@"C":@"c"};
    [OpenStatistics beginEvent:@"btn_click" primarykey:@"music" attributes:dic];
    
    
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    //页面的结束
    //    [OpenStatistics endLogPageView:@"More"];
    //    [OpenStatistics endEvent:@"btn_click"];
    //    [OpenStatistics endEvent:@"btn_click" label:@"music"];
    
    [OpenStatistics endEvent:@"btn_click" primarykey:@"music"];
}

#pragma mark - UITableViewDelegate and UITableViewDataSource
//表视图行数
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSLog(@"dataArray.count:%i",self.dataArray.count);
    return self.dataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

//单元格
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cellID";
    CustomCell *cell = (CustomCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil)
    {
//        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier] autorelease];
        
        cell = [[[NSBundle mainBundle] loadNibNamed:@"CustomCell"
                                              owner:self
                                            options:nil] objectAtIndex:0];
//        cell.selectionStyle = UITableViewCellSelectionStyleBlue;
//        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    NSLog(@"dataArray:%@",self.dataArray);
    NSInteger row = [indexPath row];
    
    cell.thumbImage.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[[self.dataArray objectAtIndex:row] objectForKey:@"icon"]]]];
    cell.appNameLabel.text = [[self.dataArray objectAtIndex:row] objectForKey:@"app_name"];
    cell.detailLabel.text = [[self.dataArray objectAtIndex:row] objectForKey:@"description"];
    
    return cell;
}

//选择单元格触发
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger row = [indexPath row];
    NSString *downLoadUrlStr = [[self.dataArray objectAtIndex:row] objectForKey:@"download_url"];
    NSURL *downLoadURL = [NSURL URLWithString:downLoadUrlStr];
    
    NSLog(@"url:%@",downLoadURL);
    [[UIApplication sharedApplication] openURL:downLoadURL];
}


-(void)dealloc
{
    _refreshHeaderView = nil;
    [super dealloc];
}


#pragma mark -
#pragma mark EGORefreshTableHeaderDelegate Methods

//下拉时调用的委托方法
-(void)refreshTableHeaderDidTriggerRefresh:(OSRefreshTableHeaderView *)view
{
    if (_reloading == NO)
    {
        _reloading = YES;
        [self loadRecommendedListData];
    }
}

//返回当前是刷新还是无刷新状态
-(BOOL)refreshTableHeaderDataSourceIsLoading:(OSRefreshTableHeaderView *)view
{
    return _reloading;
}

//返回刷新时间的回调方法
-(NSDate *)refreshTableHeaderDataSourceLastUpdated:(OSRefreshTableHeaderView *)view
{
    return [NSDate date];
}

#pragma mark -
#pragma mark UIScrollViewDelegate Methods   

//滚动控件的委托方法
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [_refreshHeaderView refreshScrollViewDidScroll:scrollView];
}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    [_refreshHeaderView refreshScrollViewDidEndDragging:scrollView];
    
    if (scrollView.contentSize.height - scrollView.contentOffset.y < self.view.frame.size.height - 44 - 20 -30)
    {
        if (_reloading == YES)
        {
            [self loadRecommendedListData];
        }
    }
}

@end
