//
//  DiscoverViewController.h
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-3-13.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "BaseViewController.h"

@interface DiscoverViewController : BaseViewController

- (IBAction)checkUpdateButtonClick:(id)sender;
- (IBAction)checkOnlineConfigButtonClick:(id)sender;
- (IBAction)exception;
- (IBAction)showFeedback:(id)sender;

@end
