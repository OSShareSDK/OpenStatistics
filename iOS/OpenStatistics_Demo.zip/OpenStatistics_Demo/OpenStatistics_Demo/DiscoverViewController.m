//
//  DiscoverViewController.m
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-3-13.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "DiscoverViewController.h"
#import "OpenStatistics.h"

@interface DiscoverViewController ()

@end

@implementation DiscoverViewController


#pragma mark - the lifeCycle of view
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"发现";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [OpenStatistics beginLogPageView:@"Discover"];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [OpenStatistics endLogPageView:@"Discover"];
}

#pragma mark - SDK方法的调用

//检测更新
-(void)checkUpdateButtonClick:(id)sender
{
    NSLog(@"暂时未实现");
    
}

//检测在线配置
-(void)checkOnlineConfigButtonClick:(id)sender
{
    NSLog(@"暂时未实现");
}

//异常
-(void)exception
{
    NSArray *array = [NSArray array];
    [array objectAtIndex:NSUIntegerMax];
}

//反馈
-(void)showFeedback:(id)sender
{
    NSLog(@"暂时未实现");
}
@end
