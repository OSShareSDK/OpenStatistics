//
//  ProfileViewController.h
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-3-13.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "BaseViewController.h"

@interface ProfileViewController : BaseViewController<UITextFieldDelegate>
@property (retain, nonatomic) IBOutlet UITextField *badgeField;
@property (retain, nonatomic) IBOutlet UILabel *showValue;

@end
