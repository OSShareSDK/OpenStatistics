//
//  CustomCell.m
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-4-14.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "CustomCell.h"
#import "OSImageLoader.h"
#import "OSImageCacheManager.h"


@implementation CustomCell


-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
    }
    return self;
}

- (void)setAppNameLabel:(NSString *)appNameLabel
            detailLabel:(NSString *)detailLabel
                  index:(NSInteger)index
           andDataArray:(NSArray *)dataArray
{
    OSImageLoader *loader = [[OSImageCacheManager sharedInstance] getImage:[[dataArray objectAtIndex:index] objectForKey:@"icon"]];
    if (loader.state == ImageLoaderStateReady)
    {
        self.thumbImage.image = loader.content;
    }
    else
    {
        [loader addNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE target:self action:@selector(imageLoadCompleteHanlder:)];
    }
    self.appNameLabel.text = appNameLabel;
    self.detailLabel.text = detailLabel;
}

- (void)imageLoadCompleteHanlder:(NSNotification *)notification
{
    OSImageLoader *loader = (OSImageLoader *)[notification object];
    self.thumbImage.image = loader.content;
}

- (void)dealloc
{
    [_thumbImage release];
    [_appNameLabel release];
    [_detailLabel release];
    [super dealloc];
}

@end
