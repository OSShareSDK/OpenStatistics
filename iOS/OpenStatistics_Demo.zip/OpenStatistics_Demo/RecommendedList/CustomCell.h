//
//  CustomCell.h
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-4-14.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CustomCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *thumbImage;  //缩略图
@property (strong, nonatomic) IBOutlet UILabel *appNameLabel;    //用户名
@property (strong, nonatomic) IBOutlet UILabel *detailLabel;     //详情列表

//设置Cell元素
- (void)setAppNameLabel:(NSString *)appNameLabel
            detailLabel:(NSString *)detailLabel
                  index:(NSInteger)index
           andDataArray:(NSArray *)dataArray;

@end
