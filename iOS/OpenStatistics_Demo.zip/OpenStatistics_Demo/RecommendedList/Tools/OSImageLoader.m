//
//  U6ImageLoader.m
//  MeYou
//
//  Created by hower on 7/7/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CoreDefinition.h"
#import "OSImageLoader.h"
#import "UIImage+Common.h"

/**
 *	@brief	图像异常域
 */
#define IMAGE_ERROR_DOMAIN @"imageErrorDomain"


@interface OSImageLoader(Private)

/**
 *	@brief	线程处理加载本地文件
 *
 *	@param 	filePath 	文件路径
 */
- (void)doLoadImageByFilePath:(NSString *)filePath;

/**
 *	@brief	释放请求相关的对象信息
 */
- (void)releaseRequestObject;

/**
 *	@brief	获取裁剪图片区域
 *
 *	@param 	image 	图片对象
 *
 *	@return	图片区域
 */
- (CGRect)getClipImageRect:(UIImage *)image;

/**
 *	@brief	处理裁剪图片数据
 *
 *	@param 	data 	图片数据
 *	@param 	needEvent 	是否需要事件派发
 */
- (void)dealClipImageWithData:(NSData *)data needEvent:(BOOL)needEvent;

/**
 *	@brief	处理圆角图片数据
 *
 *	@param 	data 	图片数据
 *	@param 	needEvent 	是否需要事件派发
 */
- (void)dealRoundedCornerRectImageWidthData:(NSData *)data needEvent:(BOOL)needEvent;

/**
 *	@brief	处理裁剪并圆角图片数据
 *
 *	@param 	data 	图片数据
 *	@param 	needEvent 	是否需要事件派发
 */
- (void)dealClipAndRoundedCornerRectImageWithData:(NSData *)data needEvent:(BOOL)needEvent;

/**
 *	@brief	处理实际圆角图片数据
 *
 *	@param 	data 	图片数据
 *	@param 	needEvent 	是否需要事件派发
 */
- (void)dealActualRoundedCornerRectImageWidthData:(NSData *)data needEvent:(BOOL)needEvent;


/**
 *	@brief	请求失败
 *
 *	@param 	connection 	连接对象
 *	@param 	error 	错误对象
 */
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error;

/**
 *	@brief	接收回复数据
 *
 *	@param 	connection 	连接对象
 *	@param 	data 	数据
 */
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data;

/**
 *	@brief	接收回复对象
 *
 *	@param 	connection 	连接对象
 *	@param 	response 	回复对象
 */
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response;

/**
 *	@brief	完成请求
 *
 *	@param 	connection 	连接对象
 */
- (void)connectionDidFinishLoading:(NSURLConnection *)connection;


@end


@implementation OSImageLoader

@synthesize content = _content;
@synthesize state = _state;
@synthesize sourceType = _sourceType;
@synthesize tag = _tag;

- (id)initWithClipSize:(CGSize)clipSize clipType:(OSImageClipType)clipType
{
	if (self = [super init])
	{
		_clipSize = clipSize;
		_imageClipType = clipType;
        _iDealType = 1;
	}
	return self;
}

- (id)initWithCornerRadius:(CGFloat)cornerRadius
{
    if (self = [super init]) 
    {
        _iDealType = 2;
        _fCornerRadius = cornerRadius;
    }
    return self;
}

- (id)initWithCornerRadius:(CGFloat)cornerRadius
                      size:(CGSize)size
{
    if (self = [super init])
    {
        _iDealType = 4;
        _fCornerRadius = cornerRadius;
        _clipSize = size;
    }
    return self;
}

- (id)initWithClipSize:(CGSize)clipSize
              clipType:(OSImageClipType)clipType
          cornerRadius:(CGFloat)cornerRadius
{
    if (self = [super init])
    {
        _iDealType = 3;
        _clipSize = clipSize;
		_imageClipType = clipType;
        _fCornerRadius = cornerRadius;
    }
    return self;
}

- (id)init
{
	if (self = [super init])
	{
		_clipSize = CGSizeZero;
		_imageClipType = ImageClipTypeNone;
        _iDealType = 0;
	}
	return self;
}

- (void)loadImageByUrl:(NSString *)url
{
	_sourceType = ImageLoaderSourceTypeUrl;
	_state = ImageLoaderStateLoading;
	if (_conn != nil)
    {
		[_conn cancel];
        [_conn release];
	}
	
	if (_receiveData == nil)
    {
		_receiveData = [[NSMutableData alloc] init];
	}
	[_receiveData setData:nil];
    
	NSURLRequest *request = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:url]];
	_conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	[_conn start];
    [request release];
}

- (void)loadImageByFilePath:(NSString *)filePath
{
	_sourceType = ImageLoaderSourceTypeFile;
	_state = ImageLoaderStateLoading;
    
	[self doLoadImageByFilePath:filePath];
}

- (void)loadImageByCache:(UIImage *)image
{
	_sourceType = ImageLoaderSourceTypeCache;
	[image retain];
    [_content release];
	_content = image;
	
	_state = ImageLoaderStateReady;
}

- (void)dealloc
{
    
    SAFE_RELEASE(_response);
    SAFE_RELEASE(_receiveData);
    SAFE_RELEASE(_content);
    
	[_conn cancel];
    SAFE_RELEASE(_conn);
    
	self.tag = nil;
    
	[super dealloc];
}

#pragma mark -
#pragma mark 私有实现

- (void)doLoadImageByFilePath:(NSString *)filePath{
	NSData *data=[NSData dataWithContentsOfFile:filePath];
	
    switch (_iDealType) 
    {
        case 1:
            [self dealClipImageWithData:data needEvent:NO];
            break;
        case 2:
            [self dealRoundedCornerRectImageWidthData:data needEvent:NO];
            break;
        case 3:
            [self dealClipAndRoundedCornerRectImageWithData:data needEvent:NO];
            break;
        case 4:
            [self dealActualRoundedCornerRectImageWidthData:data needEvent:NO];
            break;
        default:
            [_content release];
            _content=[[UIImage imageWithData:data] retain];
            break;
    }

	_state = ImageLoaderStateReady;
    [self postNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE data:nil];
}

- (void)releaseRequestObject
{
	[_receiveData setData:nil];
    
    SAFE_RELEASE(_response);
    SAFE_RELEASE(_conn);
}

- (CGRect)getClipImageRect:(UIImage *)image
{
	CGFloat vw = _clipSize.width;
	CGFloat vh = _clipSize.height;
	CGFloat w = image.size.width;
	CGFloat h = image.size.height;
    
	CGFloat scale = w / vw < h / vh ? w / vw : h / vh;
	
	vw = vw * scale;
	vh = vh * scale;
	
	switch (_imageClipType)
	{
		case ImageClipTypeCenter:
			return CGRectMake((w - vw) / 2, (h - vh) / 2, vw, vh);
		case ImageClipTypeBottom:
			return CGRectMake((w - vw) / 2, h - vh, vw, vh);
		case ImageClipTypeTop:
			return CGRectMake((w - vw) / 2, 0.0, vw, vh);
		default:
			return CGRectZero;
	}
}

- (void)dealClipImageWithData:(NSData *)data needEvent:(BOOL)needEvent
{
    //进行裁剪
    UIImage *srcImage = [UIImage imageWithData:data];
    CGRect clipRect = [self getClipImageRect:srcImage];
    UIImage *clipImage = [srcImage clipImageWithRect:clipRect];
    
    [_content release];
    _content = [clipImage retain];
    
    if (needEvent) 
    {
        NSData *clipData = UIImageJPEGRepresentation(clipImage, 0.6);
        [self postNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE
                                  data:[NSDictionary dictionaryWithObject:clipData forKey:NOTIF_KEY_IMAGE_DATA]];
    }
    
}

- (void)dealRoundedCornerRectImageWidthData:(NSData *)data needEvent:(BOOL)needEvent
{
    UIImage *srcImage = [UIImage imageWithData:data];
    UIImage *roundedCornerImage = [srcImage createRoundedRectWithsize:srcImage.size
                                                            ovalWidth:_fCornerRadius
                                                           ovalHeight:_fCornerRadius];
    [_content release];
    _content = [roundedCornerImage retain];
    
    if (needEvent) 
    {
        NSData *targetData = UIImagePNGRepresentation(roundedCornerImage);
        [self postNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE
                                  data:[NSDictionary dictionaryWithObject:targetData forKey:NOTIF_KEY_IMAGE_DATA]];
    }
}

- (void)dealClipAndRoundedCornerRectImageWithData:(NSData *)data needEvent:(BOOL)needEvent
{
    UIImage *srcImage = [UIImage imageWithData:data];
    
    CGRect clipRect = [self getClipImageRect:srcImage];
    UIImage *clipImage = [srcImage clipImageWithRect:clipRect];
    
    UIImage *roundedCornerImage = [clipImage createRoundedRectWithsize:_clipSize
                                                            ovalWidth:_fCornerRadius
                                                           ovalHeight:_fCornerRadius];
    
    [_content release];
    _content = [roundedCornerImage retain];
    
    if (needEvent)
    {
        NSData *targetData = UIImagePNGRepresentation(roundedCornerImage);
        [self postNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE
                                  data:[NSDictionary dictionaryWithObject:targetData forKey:NOTIF_KEY_IMAGE_DATA]];
    }
}

- (void)dealActualRoundedCornerRectImageWidthData:(NSData *)data needEvent:(BOOL)needEvent
{
    UIImage *srcImage = [UIImage imageWithData:data];
    //计算圆角值
    CGFloat cornerRadius = _fCornerRadius * srcImage.size.width / _clipSize.width;
    UIImage *roundedCornerImage = [srcImage createRoundedRectWithsize:srcImage.size
                                                            ovalWidth:cornerRadius
                                                           ovalHeight:cornerRadius];
    [_content release];
    _content = [roundedCornerImage retain];
    
    if (needEvent)
    {
        NSData *targetData = UIImagePNGRepresentation(roundedCornerImage);
        [self postNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE
                                  data:[NSDictionary dictionaryWithObject:targetData forKey:NOTIF_KEY_IMAGE_DATA]];
    }
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	_state = ImageLoaderStateUnset;
    
	//派发异常事件
    [self postNotificationWithName:NOTIF_IMAGE_LOAD_ERROR
                              data:[NSDictionary dictionaryWithObject:error forKey:NOTIF_KEY_IMAGE_ERROR]];
	[self releaseRequestObject];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
	[_receiveData appendData:data];
    
    //派发进度通知
    [self postNotificationWithName:NOTIF_IMAGE_LOAD_PROGRESS
                              data:[NSDictionary dictionaryWithObjectsAndKeys:
                                    [NSNumber numberWithInteger:_imageContentLength],
                                    NOTIF_KEY_TOTAL_BYTES,
                                    [NSNumber numberWithInteger:_receiveData.length],
                                    NOTIF_KEY_LOADED_BYTES,
                                    nil]];
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
	[response retain];
    [_response release];
	_response = response;
    
    id value = [[(NSHTTPURLResponse *)response allHeaderFields] objectForKey:@"Content-Length"];
    if ([value isKindOfClass:[NSString class]])
    {
        _imageContentLength = [value integerValue];
    }
    else
    {
        _imageContentLength = 0;
    }
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	NSHTTPURLResponse *response = (NSHTTPURLResponse *)_response;
//    NSLog(@"==============begin http headers");
//    
//    NSArray *keys = [[response allHeaderFields] allKeys];
//    for (int i = 0; i < [keys count]; i++)
//    {
//        NSString *keyName = [keys objectAtIndex:i];
//        NSLog(@"========= key = %@", keyName);
//        NSLog(@"========= value = %@",  [[response allHeaderFields] objectForKey:keyName]);
//    }
//    
//    NSLog(@"==============end http headers");
    
	if ([response statusCode]/100 == 2)
    {
		_state = ImageLoaderStateReady;
		//请求成功
		/*********************************************
		 * 备注：将接收数据赋予一个新的data类型，
		 * 由于IOS4.3版本上如果直接使用接收数据初始化图片会导致图片显示不正常。
		 * 原因分析：有可能是NSMutableData在接收HTTP数据后进行附加数据时
		 * 将读取数据指针指向数据末端，而UIImage初始化时也需要使用到该指针引起。
		 *********************************************/
		NSData *data = [NSData dataWithData:_receiveData];
        
        switch (_iDealType) 
        {
            case 1:
                [self dealClipImageWithData:data needEvent:YES];
                break;
            case 2:
                [self dealRoundedCornerRectImageWidthData:data needEvent:YES];
                break;
            case 3:
                [self dealClipAndRoundedCornerRectImageWithData:data needEvent:YES];
                break;
            case 4:
                [self dealActualRoundedCornerRectImageWidthData:data needEvent:YES];
                break;
            default:
                [_content release];
                _content = [[UIImage imageWithData:data] retain];
                [self postNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE
                                          data:[NSDictionary dictionaryWithObject:_receiveData forKey:NOTIF_KEY_IMAGE_DATA]];
                break;
        }
	}
    else 
    {
        
		_state = ImageLoaderStateUnset;
		//请求失败
        NSError *error = [NSError errorWithDomain:IMAGE_ERROR_DOMAIN code:[response statusCode] userInfo:nil];
        [self postNotificationWithName:NOTIF_IMAGE_LOAD_ERROR
                                  data:[NSDictionary dictionaryWithObject:error forKey:NOTIF_KEY_IMAGE_ERROR]];
	}
	[self releaseRequestObject];
}

@end
