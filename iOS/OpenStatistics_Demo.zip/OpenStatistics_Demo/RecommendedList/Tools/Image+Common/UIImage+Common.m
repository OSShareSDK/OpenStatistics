//
//  UIImage+Common.m
//  Common
//
//  Created by 冯 鸿杰 on 12/8/19.
//
//

#import "UIImage+Common.h"
#import <QuartzCore/QuartzCore.h>

typedef enum
{
    ALPHA = 0,
    BLUE = 1,
    GREEN = 2,
    RED = 3
}
PIXELS;

@interface UIImage (Private)

/**
 *	@brief	绘制圆角矩形
 *
 *	@param 	context 	上下文对象
 *	@param 	rect 	矩形范围
 *	@param 	ovalWidth 	圆角宽度
 *	@param 	ovalHeight 	圆角高度
 */
- (void)drawRoundedRect:(CGContextRef)context
                   rect:(CGRect)rect
              ovalWidth:(CGFloat)ovalWidth
             ovalHeight:(CGFloat)ovalHeight;


@end

@implementation UIImage (Private)

- (void)drawRoundedRect:(CGContextRef)context
                   rect:(CGRect)rect
              ovalWidth:(CGFloat)ovalWidth
             ovalHeight:(CGFloat)ovalHeight
{
    float fw, fh;
    if (ovalWidth == 0 || ovalHeight == 0)
    {
		CGContextAddRect(context, rect);
		return;
    }
    
    CGContextSaveGState(context);
    CGContextTranslateCTM(context, CGRectGetMinX(rect), CGRectGetMinY(rect));
    CGContextScaleCTM(context, ovalWidth, ovalHeight);
    fw = CGRectGetWidth(rect) / ovalWidth;
    fh = CGRectGetHeight(rect) / ovalHeight;
    
    CGContextMoveToPoint(context, fw, fh/2);  // Start at lower right corner
    CGContextAddArcToPoint(context, fw, fh, fw/2, fh, 1);  // Top right corner
    CGContextAddArcToPoint(context, 0, fh, 0, fh/2, 1); // Top left corner
    CGContextAddArcToPoint(context, 0, 0, fw/2, 0, 1); // Lower left corner
    CGContextAddArcToPoint(context, fw, 0, fw, fh/2, 1); // Back to lower right
    
    CGContextClosePath(context);
    CGContextRestoreGState(context);
}

@end

@implementation UIImage (Common)

+ (UIImage *)imageWithView:(UIView *)view
{
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, YES, 0.0);
    //UIGraphicsBeginImageContext(view.bounds.size);
	[view.layer renderInContext:UIGraphicsGetCurrentContext()];
	UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
    
	return image;
}

+ (UIImage *)imageNamed:(NSString *)name bundleName:(NSString *)bundleName
{
    NSBundle *bundle = [[[NSBundle alloc] initWithPath:[[NSBundle mainBundle] pathForResource:bundleName ofType:@"bundle"]] autorelease];
    
    NSRange range = [name rangeOfString:[NSString stringWithFormat:@".%@",[name pathExtension]]];
    if (range.location != NSNotFound)
    {
        NSString *fileName = [name substringToIndex:range.location];
        NSString *path = [bundle pathForResource:fileName ofType:[name pathExtension]];
        return [UIImage imageWithContentsOfFile:path];
    }
    
    return nil;
}

- (UIImage *)scaleImageWithSize:(CGSize)size
{
    CGFloat w = self.size.width;
	CGFloat h = self.size.height;
	
	UIImage *resultImg = nil;
    
	CGFloat b = (CGFloat)size.width / w < (CGFloat)size.height / h ? (CGFloat)size.width / w : (CGFloat)size.height / h;
	CGSize itemSize = CGSizeMake(b * w, b * h);
    
	UIGraphicsBeginImageContext(itemSize);
	CGRect imageRect = CGRectMake(0, 0, b*w, b*h);
	[self drawInRect:imageRect];
	resultImg = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	
	return resultImg;
}

- (UIImage *)createRoundedRectWithsize:(CGSize)size
                             ovalWidth:(CGFloat)ovalWidth
                            ovalHeight:(CGFloat)ovalHeight
{
    int w = size.width;
    int h = size.height;
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = CGBitmapContextCreate(NULL, w, h, 8, 4 * w, colorSpace, kCGImageAlphaPremultipliedFirst);
    CGRect rect = CGRectMake(0, 0, w, h);
    
    CGContextBeginPath(context);
	[self drawRoundedRect:context rect:rect ovalWidth:ovalWidth ovalHeight:ovalHeight];
    CGContextClosePath(context);
    
    CGContextClip(context);
    CGContextDrawImage(context, CGRectMake(0, 0, w, h), self.CGImage);
    CGImageRef imageMasked = CGBitmapContextCreateImage(context);
    CGContextRelease(context);
    CGColorSpaceRelease(colorSpace);
	UIImage * targetImage = [UIImage imageWithCGImage:imageMasked];
	CGImageRelease(imageMasked);
    
    return targetImage;
}

- (UIImage *)clipImageWithRect:(CGRect)rect
{
    switch (self.imageOrientation)
    {
        case UIImageOrientationLeft:
            rect = CGRectMake(rect.origin.y,
                              rect.origin.x,
                              rect.size.height,
                              rect.size.width);
            break;
        case UIImageOrientationRight:
            rect = CGRectMake(rect.origin.y,
                              self.size.width - rect.size.width - rect.origin.x,
                              rect.size.height,
                              rect.size.width);
            break;
        case UIImageOrientationDown:
            rect = CGRectMake(self.size.width - rect.size.width - rect.origin.x,
                              self.size.height - rect.size.height - rect.origin.y,
                              rect.size.width,
                              rect.size.height);
            break;
        default:
            break;
    }
    
	CGImageRef clipImageRef = CGImageCreateWithImageInRect(self.CGImage, rect);
	
    CGRect clipBounds = CGRectMake(0, 0, CGImageGetWidth(clipImageRef), CGImageGetHeight(clipImageRef));
	
    UIGraphicsBeginImageContext(clipBounds.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextDrawImage(context, clipBounds, clipImageRef);
    UIImage* clipImage = [UIImage imageWithCGImage:clipImageRef
                                             scale:self.scale
                                       orientation:self.imageOrientation];
	
	CGImageRelease(clipImageRef);
    UIGraphicsEndImageContext();
	
    return clipImage;
}

- (UIImage *)grayImage
{
    CGSize size = [self size];
    int width = size.width;
    int height = size.height;
    
    // the pixels will be painted to this array
    uint32_t *pixels = (uint32_t *) malloc(width * height * sizeof(uint32_t));
    
    // clear the pixels so any transparency is preserved
    
    memset(pixels, 0, width * height * sizeof(uint32_t));
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    
    // create a context with RGBA pixels
    CGContextRef context = CGBitmapContextCreate(pixels, width, height, 8, width * sizeof(uint32_t), colorSpace,kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedLast);
    
    // paint the bitmap to our context which will fill in the pixels array
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), [self CGImage]);
    for(int y = 0; y < height; y++) {
        for(int x = 0; x < width; x++) {
            
            uint8_t *rgbaPixel = (uint8_t *) &pixels[y * width + x];
            // convert to grayscale using recommended method: http://en.wikipedia.org/wiki/Grayscale#Converting_color_to_grayscale
            uint32_t gray = 0.3 * rgbaPixel[RED] + 0.59 * rgbaPixel[GREEN] + 0.11 * rgbaPixel[BLUE];
            
            // set the pixels to gray
            
            rgbaPixel[RED] = gray;
            
            rgbaPixel[GREEN] = gray;
            
            rgbaPixel[BLUE] = gray;
            
        }
        
    }
    
    // create a new CGImageRef from our context with the modified pixels
    
    CGImageRef image = CGBitmapContextCreateImage(context);
    
    
    // we're done with the context, color space, and pixels
    
    CGContextRelease(context);
    
    CGColorSpaceRelease(colorSpace);
    
    free(pixels);
    
    
    // make a new UIImage to return
    
    UIImage *resultUIImage = [UIImage imageWithCGImage:image];
    
    // we're done with image now too
    
    CGImageRelease(image);
    
    
    return resultUIImage;
}

@end
