//
//  U6ImagePool.m
//  MeYou
//
//  Created by hower on 7/7/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CoreDefinition.h"
#import "OSImageCacheManager.h"
#import "NSString+Common.h"

@interface OSImageCacheManager(Private)

/**
 *	@brief	获取缓存文件夹路径
 *
 *	@return	缓存文件夹路径
 */
- (NSString *)getCachePath;

/**
 *	@brief	判断是否存在本地缓存
 *
 *	@param 	cacheName 	缓存名称
 *
 *	@return	YES表示存在，否则不存在。
 */
- (BOOL)existsLocalCache:(NSString *)cacheName;

/**
 *	@brief	获取缓存文件路径
 *
 *	@param 	cacheName 	缓存名称
 *
 *	@return	缓存文件路径
 */
- (NSString *)getCacheFileName:(NSString *)cacheName;

/**
 *	@brief	从队列中获取图片加载器
 *
 *	@param 	cacheName 	缓存名称
 *
 *	@return	图片加载器
 */
- (OSImageLoader *)getLoaderByQueue:(NSString *)cacheName;

/**
 *	@brief	获取图片加载器
 *
 *	@param 	url 	图片路径
 *
 *	@return	加载器对象
 */
- (OSImageLoader *)getImageLoaderWithUrl:(NSString *)url;

/**
 *	@brief	获取图片加载器
 *
 *	@param 	url 	图片路径
 *	@param 	size 	裁剪尺寸
 *	@param 	clipType 	裁剪类型
 *
 *	@return	图片加载器
 */
- (OSImageLoader *)getImageLoaderWithUrl:(NSString *)url
									size:(CGSize)size
								clipType:(OSImageClipType)clipType;

/**
 *	@brief	获取图片加载器
 *
 *	@param 	url 	图片路径
 *	@param 	cornerRadius 	圆角
 *
 *	@return	图片加载器
 */
- (OSImageLoader *)getImageLoaderWithUrl:(NSString *)url
                            cornerRadius:(CGFloat)cornerRadius;

/**
 *	@brief	获取图片加载器
 *
 *	@param 	url 	图片路径
 *	@param 	cornerRadius 	圆角
 *  @param  size    尺寸
 *
 *	@return	图片加载器
 */
- (OSImageLoader *)getImageLoaderWithUrl:(NSString *)url
                          cornerRadius:(CGFloat)cornerRadius
                                  size:(CGSize)size;

/**
 *	@brief	获取图片加载器
 *
 *	@param 	url 	图片路径
 *	@param 	cornerRadius 	圆角
 *	@param 	size 	裁剪尺寸
 *	@param 	clipType 	裁剪类型
 *
 *	@return	图片加载器
 */
- (OSImageLoader *)getImageLoaderWithUrl:(NSString *)url
                          cornerRadius:(CGFloat)cornerRadius
                                  size:(CGSize)size
                              clipType:(OSImageClipType)clipType;


/**
 *	@brief	获取裁剪图片路径
 *
 *	@param 	url 	图片路径
 *	@param 	size 	裁剪大小
 *	@param 	clipType 	裁剪类型
 *
 *	@return	图片路径
 */
- (NSString *)getClipImagePath:(NSString *)url
						  size:(CGSize)size
					  clipType:(OSImageClipType)clipType;

/**
 *	@brief	获取圆角图片路径
 *
 *	@param 	url 	图片原始路径
 *	@param 	cornerRadius 	圆角
 *
 *	@return	图片路径
 */
- (NSString *)getCornerRadiusPath:(NSString *)url
                     cornerRadius:(CGFloat)cornerRadius;

/**
 *	@brief	获取实际尺寸圆角图片路径
 *
 *	@param 	url 	图片原始路径
 *	@param 	cornerRadius 	圆角
 *	@param 	size 	实际显示尺寸
 *
 *	@return	图片路径
 */
- (NSString *)getCornerRadiusPath:(NSString *)url
                     cornerRadius:(CGFloat)cornerRadius
                             size:(CGSize)size;


/**
 *	@brief	获取圆角裁剪图片路径
 *
 *	@param 	url 	图片原始路径
 *	@param 	cornerRadius 	圆角
 *	@param 	size 	裁剪区域
 *	@param 	clipType 	裁剪类型
 *
 *	@return	图片路径
 */
- (NSString *)getCornerRadiusPath:(NSString *)url
                     cornerRadius:(CGFloat)cornerRadius
                             size:(CGSize)size
                         clipType:(OSImageClipType)clipType;


/**
 *	@brief	图片加载完成
 *
 *	@param 	notif 	通知对象
 */
- (void)onImageLoadComplete:(NSNotification *)notif;

/**
 *	@brief	图片加载异常
 *
 *	@param 	notif 	通知对象
 */
- (void)onImageLoadError:(NSNotification *)notif;

@end


@implementation OSImageCacheManager

+ (OSImageCacheManager *)sharedInstance
{
    static OSImageCacheManager *sharedInstace = nil;
    @synchronized (self)
    {
        if (sharedInstace == nil)
        {
            sharedInstace = [[self alloc] init];
        }
        return sharedInstace;
    }
}

- (id)init
{
	if (self = [super init])
    {
		_loaderQueue = [[NSMutableArray alloc] init];
	}
	return self;
}

-(void)dealloc
{
    for (int i = 0; i < [_loaderQueue count]; i++)
    {
        OSImageLoader *loader = [_loaderQueue objectAtIndex:i];
        [loader removeAllNotificationWithTarget:self];
    }
    
    SAFE_RELEASE(_cachePath);
    SAFE_RELEASE(_loaderQueue);
    
	[super dealloc];
}

- (OSImageLoader *)getImage:(NSString *)url
{
	return [self getImageLoaderWithUrl:url];
}

- (OSImageLoader *)getImage:(NSString *)url size:(CGSize)size clipType:(OSImageClipType)clipType
{
	return [self getImageLoaderWithUrl:url size:size clipType:clipType];
}

- (OSImageLoader *)getImage:(NSString *)url cornerRadius:(CGFloat)cornerRadius
{
    return [self getImageLoaderWithUrl:url cornerRadius:cornerRadius];
}

- (OSImageLoader *)getImage:(NSString *)url
             cornerRadius:(CGFloat)cornerRadius
                     size:(CGSize)size
{
    return [self getImageLoaderWithUrl:url cornerRadius:cornerRadius size:size];
}

- (OSImageLoader *)getImage:(NSString *)url
             cornerRadius:(CGFloat)cornerRadius
                     size:(CGSize)size
                 clipType:(OSImageClipType)clipType
{
    return  [self getImageLoaderWithUrl:url cornerRadius:cornerRadius size:size clipType:clipType];
}

- (BOOL)existsImageCache:(NSString *)url
{
    if ([url isKindOfClass:[NSString class]])
	{
		//取得缓存名称
        NSString *cacheName = [url md5HexDigestString];
        return [self existsLocalCache:cacheName];
	}
    return NO;
}

- (BOOL)existsImageCache:(NSString *)url
                    size:(CGSize)size
                clipType:(OSImageClipType)clipType
{
    if ([url isKindOfClass:[NSString class]])
	{
		//取得缓存名称
        NSString *cacheName = [[self getClipImagePath:url size:size clipType:clipType] md5HexDigestString];
        return [self existsLocalCache:cacheName];
	}
    return NO;
}

- (BOOL)existsImageCache:(NSString *)url
            cornerRadius:(CGFloat)cornerRadius
{
    if ([url isKindOfClass:[NSString class]])
	{
		//取得缓存名称
        NSString *cacheName = [[self getCornerRadiusPath:url cornerRadius:cornerRadius] md5HexDigestString];
        return [self existsLocalCache:cacheName];
	}
    return NO;
}

- (BOOL)existsImageCache:(NSString *)url
                    size:(CGSize)size
                clipType:(OSImageClipType)clipType
            cornerRadius:(CGFloat)cornerRadius
{
    if ([url isKindOfClass:[NSString class]])
	{
		//取得缓存名称
        NSString *cacheName = [[self getCornerRadiusPath:url cornerRadius:cornerRadius size:size clipType:clipType] md5HexDigestString];
        return [self existsLocalCache:cacheName];
	}
    return NO;
}

#pragma mark -
#pragma mark 私有实现

- (NSString *)getCachePath
{
	if (_cachePath == nil)
    {
		_cachePath = [[NSString stringWithFormat:@"%@/Cache/",NSTemporaryDirectory()] retain];
	}
    
    //如果不存在缓存目录
	if (![[NSFileManager defaultManager] fileExistsAtPath:_cachePath])
    {
		[[NSFileManager defaultManager] createDirectoryAtPath:_cachePath
                                  withIntermediateDirectories:YES
                                                   attributes:nil
                                                        error:nil];
	}
    
	return _cachePath;
}

- (BOOL)existsLocalCache:(NSString *)cacheName
{
	NSString *fileName=[self getCacheFileName:cacheName];
	if ([[NSFileManager defaultManager] fileExistsAtPath:fileName])
    {
		return YES;
	}
    else
    {
		return NO;
	}
}

- (NSString *)getCacheFileName:(NSString *)cacheName
{
	return [NSString stringWithFormat:@"%@%@",[self getCachePath], cacheName];
}

- (OSImageLoader *)getLoaderByQueue:(NSString *)cacheName
{
	for (int i=0; i<[_loaderQueue count]; i++)
    {
		OSImageLoader *loader=[_loaderQueue objectAtIndex:i];
		if ([loader.tag isEqualToString:cacheName])
        {
			return loader;
		}
	}
	return nil;
}

- (OSImageLoader *)getImageLoaderWithUrl:(NSString *)url
{
	if (![url isKindOfClass:[NSString class]])
	{
		//非法参数值返回nil
		return nil;
	}
	
	/************************************
	 先判断内存中是否有缓冲图片对象，如果有则进行返回。
	 否则再检测是否有本地缓存，如果有则进行加载，
	 加载前需判断加载队列是否已有此对象加载，如果存在则直接返回该对象，否则进行创建并进入加载队列。
	 如果没有本地缓存则进行网络加载。
	 加载前需要判断加载队列是否已有对象加载，如果存在则直接返回该对象，否则进行创建并进入加载队列。
	 *************************************/
	
	//取得缓存名称
	NSString *cacheName = [url md5HexDigestString];
    //判断本地缓存
    if ([self existsLocalCache:cacheName])
    {
        OSImageLoader *loader = [self getLoaderByQueue:cacheName];
        if (loader == nil)
        {
            loader = [[[OSImageLoader alloc] init] autorelease];
            loader.tag = cacheName;
            @synchronized(self)
            {
                //加入队列,此处需要加入同步控制，避免在多线程中请求导致加入出错。
                [_loaderQueue addObject:loader];
            }
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE
                                     target:self
                                     action:@selector(onImageLoadComplete:)];
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_ERROR
                                     target:self
                                     action:@selector(onImageLoadError:)];
            [loader loadImageByFilePath:[self getCacheFileName:cacheName]];
            
        }
        return loader;
    }
    else
    {
        //进行网络加载
        OSImageLoader *loader = [self getLoaderByQueue:cacheName];
        if (loader == nil)
        {
            loader = [[[OSImageLoader alloc] init] autorelease];
            loader.tag = cacheName;
            @synchronized(self)
            {
                //加入队列,此处需要加入同步控制，避免在多线程中请求导致加入出错。
                [_loaderQueue addObject:loader];
            }
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE
                                     target:self
                                     action:@selector(onImageLoadComplete:)];
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_ERROR
                                     target:self
                                     action:@selector(onImageLoadError:)];
            if ([url rangeOfString:@"://"].location==NSNotFound )
            {
                //加载本地
                [loader loadImageByFilePath:url];
            }
            else
            {
                [loader loadImageByUrl:url];
            }
        }
        return loader;
    }
}

- (OSImageLoader *)getImageLoaderWithUrl:(NSString *)url
									size:(CGSize)size 
								clipType:(OSImageClipType)clipType
{
	if (![url isKindOfClass:[NSString class]])
	{
		//非法参数值返回nil
		return nil;
	}
	
	//取得缓存名称
	NSString *cacheName = [[self getClipImagePath:url size:size clipType:clipType] md5HexDigestString];
    //判断本地缓存
    if ([self existsLocalCache:cacheName])
    {
        OSImageLoader *loader = [self getLoaderByQueue:cacheName];
        if (loader==nil)
        {
            loader = [[[OSImageLoader alloc] init] autorelease];
            loader.tag = cacheName;
            @synchronized(self)
            {
                //加入队列,此处需要加入同步控制，避免在多线程中请求导致加入出错。
                [_loaderQueue addObject:loader];
            }
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE
                                     target:self
                                     action:@selector(onImageLoadComplete:)];
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_ERROR
                                     target:self
                                     action:@selector(onImageLoadError:)];
            [loader loadImageByFilePath:[self getCacheFileName:cacheName]];
        }
        return loader;
    }
    else
    {
        //进行网络加载
        OSImageLoader *loader = [self getLoaderByQueue:cacheName];
        if (loader == nil)
        {
            loader = [[[OSImageLoader alloc] initWithClipSize:size clipType:clipType] autorelease];
            loader.tag = cacheName;
            @synchronized(self)
            {
                //加入队列,此处需要加入同步控制，避免在多线程中请求导致加入出错。
                [_loaderQueue addObject:loader];
            }
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE
                                     target:self
                                     action:@selector(onImageLoadComplete:)];
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_ERROR
                                     target:self
                                     action:@selector(onImageLoadError:)];
            if ([url rangeOfString:@"://"].location == NSNotFound)
            {
                //加载本地
                [loader loadImageByFilePath:url];
            }
            else 
            {
                [loader loadImageByUrl:url];
            }
        }
        return loader;
    }
}

- (OSImageLoader *)getImageLoaderWithUrl:(NSString *)url
                            cornerRadius:(CGFloat)cornerRadius
{
    if (![url isKindOfClass:[NSString class]])
	{
		//非法参数值返回nil
		return nil;
	}
	
	//取得缓存名称
	NSString *cacheName = [[self getCornerRadiusPath:url cornerRadius:cornerRadius] md5HexDigestString];
    //判断本地缓存
    if ([self existsLocalCache:cacheName])
    {
        OSImageLoader *loader=[self getLoaderByQueue:cacheName];
        if (loader==nil) {
            loader=[[[OSImageLoader alloc] init] autorelease];
            loader.tag=cacheName;
            @synchronized(self)
            {
                //加入队列,此处需要加入同步控制，避免在多线程中请求导致加入出错。
                [_loaderQueue addObject:loader];
            }
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE
                                     target:self
                                     action:@selector(onImageLoadComplete:)];
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_ERROR
                                     target:self
                                     action:@selector(onImageLoadError:)];
            [loader loadImageByFilePath:[self getCacheFileName:cacheName]];
        }
        return loader;
    }
    else
    {
        //进行网络加载
        OSImageLoader *loader=[self getLoaderByQueue:cacheName];
        if (loader==nil)
        {
            loader=[[[OSImageLoader alloc] initWithCornerRadius:cornerRadius] autorelease];
            loader.tag=cacheName;
            @synchronized(self)
            {
                //加入队列,此处需要加入同步控制，避免在多线程中请求导致加入出错。
                [_loaderQueue addObject:loader];
            }
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE
                                     target:self
                                     action:@selector(onImageLoadComplete:)];
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_ERROR
                                     target:self
                                     action:@selector(onImageLoadError:)];
            if ([url rangeOfString:@"://"].location == NSNotFound )
            {
                //加载本地
                [loader loadImageByFilePath:url];
            }
            else 
            {
                [loader loadImageByUrl:url];
            }
        }
        return loader;
    }
}

- (OSImageLoader *)getImageLoaderWithUrl:(NSString *)url
                          cornerRadius:(CGFloat)cornerRadius
                                  size:(CGSize)size
{
    if (![url isKindOfClass:[NSString class]])
	{
		//非法参数值返回nil
		return nil;
	}
	
	//取得缓存名称
	NSString *cacheName = [[self getCornerRadiusPath:url cornerRadius:cornerRadius size:size] md5HexDigestString];
    //判断本地缓存
    if ([self existsLocalCache:cacheName])
    {
        OSImageLoader *loader=[self getLoaderByQueue:cacheName];
        if (loader==nil) {
            loader=[[[OSImageLoader alloc] init] autorelease];
            loader.tag=cacheName;
            @synchronized(self)
            {
                //加入队列,此处需要加入同步控制，避免在多线程中请求导致加入出错。
                [_loaderQueue addObject:loader];
            }
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE
                                     target:self
                                     action:@selector(onImageLoadComplete:)];
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_ERROR
                                     target:self
                                     action:@selector(onImageLoadError:)];
            [loader loadImageByFilePath:[self getCacheFileName:cacheName]];
        }
        return loader;
    }
    else
    {
        //进行网络加载
        OSImageLoader *loader=[self getLoaderByQueue:cacheName];
        if (loader==nil)
        {
            loader=[[[OSImageLoader alloc] initWithCornerRadius:cornerRadius size:size] autorelease];
            loader.tag=cacheName;
            @synchronized(self)
            {
                //加入队列,此处需要加入同步控制，避免在多线程中请求导致加入出错。
                [_loaderQueue addObject:loader];
            }
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE
                                     target:self
                                     action:@selector(onImageLoadComplete:)];
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_ERROR
                                     target:self
                                     action:@selector(onImageLoadError:)];
            if ([url rangeOfString:@"://"].location == NSNotFound )
            {
                //加载本地
                [loader loadImageByFilePath:url];
            }
            else
            {
                [loader loadImageByUrl:url];
            }
        }
        return loader;
    }
}

- (OSImageLoader *)getImageLoaderWithUrl:(NSString *)url
                          cornerRadius:(CGFloat)cornerRadius
                                  size:(CGSize)size
                              clipType:(OSImageClipType)clipType
{
    if (![url isKindOfClass:[NSString class]])
	{
		//非法参数值返回nil
		return nil;
	}
	
	//取得缓存名称
	NSString *cacheName = [[self getCornerRadiusPath:url cornerRadius:cornerRadius size:size clipType:clipType] md5HexDigestString];
    
    //判断本地缓存
    if ([self existsLocalCache:cacheName])
    {
        OSImageLoader *loader=[self getLoaderByQueue:cacheName];
        if (loader==nil) {
            loader=[[[OSImageLoader alloc] init] autorelease];
            loader.tag=cacheName;
            @synchronized(self)
            {
                //加入队列,此处需要加入同步控制，避免在多线程中请求导致加入出错。
                [_loaderQueue addObject:loader];
            }
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE
                                     target:self
                                     action:@selector(onImageLoadComplete:)];
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_ERROR
                                     target:self
                                     action:@selector(onImageLoadError:)];
            [loader loadImageByFilePath:[self getCacheFileName:cacheName]];
        }
        return loader;
    }
    else
    {
        //进行网络加载
        OSImageLoader *loader=[self getLoaderByQueue:cacheName];
        if (loader==nil)
        {
            loader=[[[OSImageLoader alloc] initWithClipSize:size clipType:clipType cornerRadius:cornerRadius] autorelease];
            loader.tag=cacheName;
            @synchronized(self)
            {
                //加入队列,此处需要加入同步控制，避免在多线程中请求导致加入出错。
                [_loaderQueue addObject:loader];
            }
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_COMPLETE
                                     target:self
                                     action:@selector(onImageLoadComplete:)];
            [loader addNotificationWithName:NOTIF_IMAGE_LOAD_ERROR
                                     target:self
                                     action:@selector(onImageLoadError:)];
            if ([url rangeOfString:@"://"].location == NSNotFound )
            {
                //加载本地
                [loader loadImageByFilePath:url];
            }
            else
            {
                [loader loadImageByUrl:url];
            }
        }
        return loader;
    }
}
					   
- (NSString *)getClipImagePath:(NSString *)url
						  size:(CGSize)size
					  clipType:(OSImageClipType)clipType
{
	NSString *prefixString = @"";
	switch (clipType)
	{
		case ImageClipTypeTop:
			prefixString = @"_ct";
			break;
		case ImageClipTypeCenter:
			prefixString = @"_cc";
			break;
		case ImageClipTypeBottom:
			prefixString = @"_cb";
			break;
        default:
            break;
	}
    
    return [NSString stringWithFormat:@"%@#%@%.0f%.0f",
            url,
            prefixString,
            size.width,
            size.height];
}

- (NSString *)getCornerRadiusPath:(NSString *)url
                     cornerRadius:(CGFloat)cornerRadius
{
    return [NSString stringWithFormat:@"%@#_r%.0f",
            url,
            cornerRadius];
}

- (NSString *)getCornerRadiusPath:(NSString *)url
                     cornerRadius:(CGFloat)cornerRadius
                             size:(CGSize)size
{
    return [NSString stringWithFormat:@"%@#_r%.0f_%.0fx%.0f",
            url,
            cornerRadius,
            size.width,
            size.height];
}

- (NSString *)getCornerRadiusPath:(NSString *)url
                     cornerRadius:(CGFloat)cornerRadius
                             size:(CGSize)size
                         clipType:(OSImageClipType)clipType
{
    NSString *prefixString = @"";
	switch (clipType)
	{
		case ImageClipTypeTop:
			prefixString = @"_ct";
			break;
		case ImageClipTypeCenter:
			prefixString = @"_cc";
			break;
		case ImageClipTypeBottom:
			prefixString = @"_cb";
			break;
        default:
            break;
	}
    
    return [NSString stringWithFormat:@"%@#%@%.0f%.0f_r%.0f",
            url,
            prefixString,
            size.width,
            size.height,
            cornerRadius];
}

- (void)onImageLoadComplete:(NSNotification *)notif
{
	OSImageLoader *loader = [notif object];
	
	//移除监听
    [loader removeAllNotificationWithTarget:self];
	@synchronized(self)
    {
		if ([_loaderQueue containsObject:loader])
        {
			[_loaderQueue removeObject:loader];
		}
	}
	
	
	if (loader.sourceType == ImageLoaderSourceTypeUrl)
    {
		//缓存到本地
		NSString *cacheName = loader.tag;
		NSString *cacheFileName = [self getCacheFileName:cacheName];
		if ([[NSFileManager defaultManager] fileExistsAtPath:cacheFileName])
        {
			//删除缓存文件
			[[NSFileManager defaultManager] removeItemAtPath:cacheFileName error:nil];
		}
		
		NSDictionary *userInfo = [notif userInfo];
		NSData *data = [userInfo objectForKey:NOTIF_KEY_IMAGE_DATA];
		
		//保存缓存文件到本地
		[[NSFileManager defaultManager] createFileAtPath:cacheFileName contents:data attributes:nil];
	}
}

- (void)onImageLoadError:(NSNotification *)notif
{
	OSImageLoader *loader = [notif object];
	[loader removeAllNotificationWithTarget:self];
	@synchronized(self)
    {
		if ([_loaderQueue containsObject:loader])
        {
			[_loaderQueue removeObject:loader];
		}
	}
}

@end
