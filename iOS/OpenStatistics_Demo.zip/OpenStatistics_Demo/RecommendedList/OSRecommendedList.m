//
//  RecommendedList.m
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-4-14.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "OSRecommendedList.h"
#import "OSHTTPRequestParameters.h"
#import "OSHTTPPostedFile.h"
#import "OSJSONKit.h"
#import "OSHTTPToken.h"

@implementation OSRecommendedList

-(void)getReconmendedListWithResult:(void (^)(id))result
{
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:kGetReconmendedListURL]] ;
    
    [request setHTTPMethod:@"POST"];
    OSHTTPRequestParameters *params = [[OSHTTPRequestParameters alloc] init];
    [request setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
    
    _HT = [OSHTTPToken tokenWithRequest:request userData:nil worker:self];
    [_HT start];
    [params release];
    
    
    if (_resultHandler)
    {
        Block_release(_resultHandler);
    }
    _resultHandler = Block_copy(result);
    
    
}


//下载完成
- (void)httpResult:(OSHTTPToken *)token
{
    NSString *returnStr = [[NSString alloc] initWithData:token.responseData encoding:NSUTF8StringEncoding];
    NSDictionary *returnDic = [returnStr objectFromJSONStringWithParseOptions:OSParseOptionLooseUnicode];
    
    if (_resultHandler)
    {
        _resultHandler (returnDic);
    }
    [returnStr release];
}


-(void)dealloc
{
    if (_resultHandler)
    {
        Block_release(_resultHandler);
    }
    [super dealloc];
}

#pragma mark - other
//以下几个方法是协议必须实现的方法，在此SDK暂时不需要用到，因此是空实现
- (void) httpCacheResult:(OSHTTPToken *)token cacheData:(NSString *)cacheData
{
    
}


- (void) httpFault:(OSHTTPToken *)token
{
    
}


- (NSString *)httpCacheData:(OSHTTPToken *)token
{
    return nil;
}


-(BOOL)httpShouldGetCacheData:(OSHTTPToken *)token
{
    return NO;
}


@end
