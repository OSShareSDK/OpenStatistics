//
//  RecommendedList.h
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-4-14.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OSHTTPToken.h"

//获取推荐列表接口
#define kGetReconmendedListURL @"http://192.168.1.195/statistics.sharesdk.cn/api/index.php/client/app/index"

@interface OSRecommendedList : NSObject<ICMHTTPWorker>
{
    OSHTTPToken *_HT;
    void(^_resultHandler)(id responder);
}


/**
 *	@brief  获取推荐列表
 *
 *	@return	void
 */
-(void)getReconmendedListWithResult:(void(^)(id responder))result;



@end
