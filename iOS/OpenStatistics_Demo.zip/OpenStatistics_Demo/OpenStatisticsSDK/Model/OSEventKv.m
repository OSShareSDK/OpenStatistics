//
//  OSEventKv.m
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-3-13.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "OSEventKv.h"

@implementation OSEventKv

#pragma mark -
#pragma mark NSCoding
-(void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.sessionID forKey:@"sessionID"];
    [aCoder encodeObject:self.createDate forKey:@"createDate"];
    [aCoder encodeObject:self.eventKey forKey:@"eventKey"];
    [aCoder encodeObject:self.page forKey:@"page"];
    [aCoder encodeObject:self.attributes forKey:@"attributes"];
    
    [aCoder encodeObject:self.label forKey:@"label"];
    [aCoder encodeInteger:self.noticeNum forKey:@"noticeNum"];
    [aCoder encodeInteger:self.duration forKey:@"duration"];
}

-(id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init])
    {
        self.sessionID = [aDecoder decodeObjectForKey:@"sessionID"];
        self.createDate = [aDecoder decodeObjectForKey:@"createDate"];
        self.eventKey = [aDecoder decodeObjectForKey:@"eventKey"];
        self.page = [aDecoder decodeObjectForKey:@"page"];
        self.attributes = [aDecoder decodeObjectForKey:@"attributes"];
        
        self.label = [aDecoder decodeObjectForKey:@"label"];
        self.noticeNum = [aDecoder decodeIntegerForKey:@"noticeNum"];
        self.duration = [aDecoder decodeIntegerForKey:@"duration"];
    }
    return self;
}

-(void)dealloc
{
    [_sessionID release];
    [_createDate release];
    [_eventKey release];
    [_page release];
    [_attributes release];
    
    [_label release];
    [super dealloc];
}

@end
