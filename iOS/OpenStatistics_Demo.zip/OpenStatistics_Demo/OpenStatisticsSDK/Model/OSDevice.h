//
//  OSDevice.h
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-3-6.
//  Copyright (c) 2014年 shareSDK. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface OSDevice : NSObject<NSCoding>

@property (nonatomic ,copy) NSString *deviceID;      //设备id
@property (nonatomic ,copy) NSString *appVersion;    //应用版本
@property (nonatomic ,copy) NSString *appPackage;    //应用包名
@property (nonatomic ,assign) NSInteger platformID;  //平台id（1为Android，2为iOS）
@property (nonatomic ,copy) NSString *sdkVersion;    //SDK版本号(1.0.0)

@property (nonatomic ,copy) NSString *channelName;   //渠道名称
@property (nonatomic ,copy) NSString *mac;           //网卡地址
@property (nonatomic ,copy) NSString *model;         //设备型号
@property (nonatomic ,copy) NSString *sysVersion;    //设备系统版本号
@property (nonatomic ,copy) NSString *carrier;       //设备的手机运营商

@property (nonatomic ,copy) NSString *screenSize;    //设备的分辨率
@property (nonatomic ,copy) NSString *factory;       //设备厂商
@property (nonatomic ,copy) NSString *networkType;   //网络类型,3G,WIFI
@property (nonatomic ,assign) NSInteger isJailbroken;//系统是否越狱（0否1是）
@property (nonatomic ,assign) NSInteger isPirated;   //应用是否被破解（0否1是）

@property (nonatomic ,copy) NSString *longitude;     //手机经度
@property (nonatomic ,copy) NSString *latitude;      //手机纬度
@property (nonatomic ,copy) NSString *language;      //系统语言（zh）
@property (nonatomic ,copy) NSString *timeZone;      //所在时区（8）
@property (nonatomic ,copy) NSString *cpu;           //设备cpu

@property (nonatomic ,copy) NSString *manuID;        //设备版本号
@property (nonatomic ,copy) NSString *manuTime;      //设备出厂时间

@end
