//
//  OSError.h
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-3-6.
//  Copyright (c) 2014年 shareSDK. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OSError : NSObject<NSCoding>

@property (nonatomic, copy) NSString *sessionID;     //设备启动标识
@property (nonatomic, strong) NSString *createDate;  //创建时间
@property (nonatomic, copy) NSString *page;          //访问页面
@property (nonatomic, copy) NSString *errorLog;      //错误内容
@property (nonatomic, copy) NSString *stackTrace;    //堆栈轨迹

@end
