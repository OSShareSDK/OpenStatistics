//
//  OSCommonReturn.m
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-3-6.
//  Copyright (c) 2014年 shareSDK. All rights reserved.
//

#import "OSCommonReturn.h"

@implementation OSCommonReturn

-(void)dealloc
{
    [_message release];
    [_result release];
    
    [super dealloc];
}

@end
