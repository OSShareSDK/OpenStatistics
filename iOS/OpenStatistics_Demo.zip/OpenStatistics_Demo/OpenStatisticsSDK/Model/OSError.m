//
//  OSError.m
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-3-6.
//  Copyright (c) 2014年 shareSDK. All rights reserved.
//

#import "OSError.h"

@implementation OSError


#pragma mark -
#pragma mark NSCoding
-(void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.sessionID forKey:@"sessionID"];
    [aCoder encodeObject:self.createDate forKey:@"createDate"];
    [aCoder encodeObject:self.page forKey:@"page"];
    [aCoder encodeObject:self.errorLog forKey:@"errorLog"];
    [aCoder encodeObject:self.stackTrace forKey:@"stackTrace"];
}

-(id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init])
    {
        self.sessionID = [aDecoder decodeObjectForKey:@"sessionID"];
        self.createDate = [aDecoder decodeObjectForKey:@"createDate"];
        self.page = [aDecoder decodeObjectForKey:@"page"];
        self.errorLog = [aDecoder decodeObjectForKey:@"errorLog"];
        self.stackTrace = [aDecoder decodeObjectForKey:@"stackTrace"];
    }
    return self;
}


-(void)dealloc
{
    [_sessionID release];
    [_createDate release];
    [_page release];
    [_errorLog release];
    [_stackTrace release];
    
    [super dealloc];
}

@end
