//
//  OSLaunch.m
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-3-6.
//  Copyright (c) 2014年 shareSDK. All rights reserved.
//

#import "OSLaunch.h"
#define kSessionID   @"sessionID"
#define kDateTime    @"dateTime"
#define kLastEndDate @"lastEndDate"


@implementation OSLaunch


#pragma mark NSCoding

-(void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.sessionID forKey:kSessionID];
    [aCoder encodeObject:self.createDate forKey:kDateTime];
    [aCoder encodeObject:self.lastEndDate forKey:kLastEndDate];
}


-(id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init])
    {
        self.sessionID = [aDecoder decodeObjectForKey:kSessionID];
        self.createDate = [aDecoder decodeObjectForKey:kDateTime];
        self.lastEndDate = [aDecoder decodeObjectForKey:kLastEndDate];
    }
    return self;
}


- (void)dealloc
{
    [_sessionID release];
    [_createDate release];
    [_lastEndDate release];
    
    [super dealloc];
}


#pragma mark -
#pragma mark NSCopying

-(id)copyWithZone:(NSZone *)zone
{
    OSLaunch *copy = [[[self class] allocWithZone:zone] init];
    copy.sessionID = [[self.sessionID copyWithZone:zone] autorelease];
    copy.createDate = [[self.createDate copyWithZone:zone] autorelease];
    copy.lastEndDate = [[self.lastEndDate copyWithZone:zone] autorelease];
    return copy;
    [copy release];
}

@end
