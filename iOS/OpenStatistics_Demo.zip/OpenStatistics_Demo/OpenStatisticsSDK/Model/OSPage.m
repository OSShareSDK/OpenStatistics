//
//  OSPage.m
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-3-6.
//  Copyright (c) 2014年 shareSDK. All rights reserved.
//

#import "OSPage.h"

@implementation OSPage


#pragma mark -
#pragma mark NSCoding
-(id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init])
    {
        self.sessionID = [aDecoder decodeObjectForKey:@"sessionID"];
        self.startDate = [aDecoder decodeObjectForKey:@"startDate"];
        self.endDate = [aDecoder decodeObjectForKey:@"endDate"];
        self.page = [aDecoder decodeObjectForKey:@"page"];
        self.duration = [aDecoder decodeIntegerForKey:@"duration"];
    }
    return self;
}

-(void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.sessionID forKey:@"sessionID"];
    [aCoder encodeObject:self.startDate forKey:@"startDate"];
    [aCoder encodeObject:self.endDate forKey:@"endDate"];
    [aCoder encodeObject:self.page forKey:@"page"];
    [aCoder encodeInteger:self.duration forKey:@"duration"];
}

-(void)dealloc
{
    [_sessionID release];
    [_startDate release];
    [_endDate release];
    [_page release];
    
    [super dealloc];
}


@end
