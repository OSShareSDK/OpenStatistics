//
//  OpenStatistics.h
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-2-20.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#define XcodeAppVersion [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]

/**
 *	@brief	发送策略，即发送数据的方式。
            服务器提供的在线发送策略有BATCH（启动发送）、SEND_INTERVAL（间隔发送）、SEND_ON_EXIT（退出发送）
            REALTIME（实时）和 SENDWIFIONLY（Wifi环境下发送）只在模拟器或DEBUG模式下生效，真机或release模式会自动改成BATCH（启动发送）
 */
typedef enum
{
    REALTIME = 3,         //实时发送
    BATCH = 1,            //应用启动发送
    SEND_INTERVAL = 2,    //按最小间隔发送
    SEND_ON_EXIT = 0,     //退出或进入后台时发送
    SENDDAILY = 4,        //每日发送
    SENDWIFIONLY = 5      //WIFI环境下发送
} ReportPolicy;


@class CLLocation;


/**
 *	@brief	统计SDK的核心类，此类的方法以类方法的形式提供。开发者只需要关注这个类的头文件。
 */
@interface OpenStatistics : NSObject <UIAlertViewDelegate>


#pragma mark - 常用设置

/**
 *	@brief	设置app版本号
 *
 *	@param 	appVersion 	版本号（默认值 XcodeAppVersion）
 *
 *	@return	void
 */
+ (void)setAppVersion:(NSString *)appVersion;


/**
 *	@brief	开启崩溃报告收集
 *
 *	@param 	value 	YES为开启，NO为关闭（默认是开启）
 *
 *	@return	void
 */
+ (void)setCrashReportEnabled:(BOOL)value;


/**
 *	@brief	设置是否打印sdk的log信息
 *
 *	@param 	value 	YES为开启，NO为不开启（默认不开启）
 *
 *	@return	void
 */
+ (void)setLogEnabled:(BOOL)value;


#pragma mark - 开启统计

/**
 *	@brief	开启统计
 *
 *	@param 	appKey 	appKey
 *	@param 	rp   	发送策略，默认值为BATCH（启动发送）发送数据
 *	@param 	cid 	渠道名称，默认值为：@"App Store"
 *
 *	@return	void
 */
+ (void)startWithAppkey:(NSString *)appKey;
+ (void)startWithAppkey:(NSString *)appKey reportPolicy:(ReportPolicy)rp channelId:(NSString *)cid;


/**
 *	@brief	设置日志发送间隔，只有发送策略为SEND_INTERVAL（间隔发送）时才有用
 *
 *	@param 	second 	单位为秒,最小值为10秒（默认值）,最大值为86400秒(一天)
 *
 *	@return	void
 */
+ (void)setLogSendInterval:(double)second;


#pragma mark - 页面时长统计

/**
 *	@brief	页面时长统计,即记录某个页面被打开多长时间。也可以调用beginLogPageView,endLogPageView自动计时
 *
 *	@param 	pageName    需要记录时长的页面名称
 *	@param 	seconds 	页面停留的秒数
 *
 *	@return	void
 */
+ (void)logPageView:(NSString *)pageName seconds:(int)seconds;


/**
 *	@brief	开始页面统计
 *
 *	@param 	pageName 	页面名
 *
 *	@return	void
 */
+ (void)beginLogPageView:(NSString *)pageName;


/**
 *	@brief	停止页面统计
 *
 *	@param 	pageName 	页面名
 *
 *	@return	void
 */
+ (void)endLogPageView:(NSString *)pageName;


#pragma mark - event 事件统计

/**
 *	@brief	自定义事件,数量统计。使用前，先到管理后台->设置->编辑自定义事件中，添加相应的事件ID，然后在这里传入相应的事件ID
 *
 *	@param 	eventId 	    管理后台上注册的事件Id
 *	@param 	label 	        分类标签。不同的标签会分别进行统计，方便同一事件的不同标签的对比。当值为nil或空字符串时后台会生成和eventId同名的标签
 *	@param 	accumulation    累加值。为减少网络交互，可以自行对某一事件ID的某一分类标签进行累加，再传入次数作为参数
 *
 *	@return	void
 */
+ (void)event:(NSString *)eventId;
+ (void)event:(NSString *)eventId label:(NSString *)label;
+ (void)event:(NSString *)eventId acc:(NSInteger)accumulation;
+ (void)event:(NSString *)eventId label:(NSString *)label acc:(NSInteger)accumulation;


/**
 *	@brief	自定义事件
 *
 *	@param 	eventId 	管理后台上注册的事件Id
 *	@param 	attributes 	自定义事件标签（字典），也就是说可自定义多个标签放在字典中
 *
 *	@return	void
 *
 *  @warn  字典attributes的key不能超过10个，超过后将被截短。
 */
+ (void)event:(NSString *)eventId attributes:(NSDictionary *)attributes;


#pragma mark - 自定义事件时长

/**
 *	@brief	自定义事件,数量统计。使用前，先到管理后台->设置->编辑自定义事件中，添加相应的事件ID，然后在工程中传入相应的事件ID
 *
 *	@param 	eventId 	  网站上注册的事件Id
 *	@param 	label 	      分类标签。不同标签分别进行统计，方便同一事件的不同标签的对比。label值为nil或空字符串时，后台会生成和eventI相同的事件
 *	@param 	accumulation  累加值。为减少网络交互，可以自行对某一事件ID的某一分类标签进行累加，再传入次数作为参数
 *  @param  primarykey    用于和eventId一起标识一个唯一事件
 *  @param  attributes    自定义事件标签（字典），即可自定义多个标签然后放在字典中
 *  @param  millisecond   事件计时的毫秒数
 *
 *	@return	void
 */
+ (void)beginEvent:(NSString *)eventId;
+ (void)endEvent:(NSString *)eventId;

+ (void)beginEvent:(NSString *)eventId label:(NSString *)label;
+ (void)endEvent:(NSString *)eventId label:(NSString *)label;

+ (void)beginEvent:(NSString *)eventId primarykey :(NSString *)keyName attributes:(NSDictionary *)attributes;
+ (void)endEvent:(NSString *)eventId primarykey:(NSString *)keyName;

+ (void)event:(NSString *)eventId durations:(int)millisecond;
+ (void)event:(NSString *)eventId label:(NSString *)label durations:(int)millisecond;

+ (void)event:(NSString *)eventId attributes:(NSDictionary *)attributes durations:(int)millisecond;


#pragma mark - 检测更新

+ (void)checkUpdate;
+ (void)checkUpdate:(NSString *)title cancelButtonTitle:(NSString *)cancelTitle otherButtonTitles:(NSString *)otherTitle;
+ (void)checkUpdateWithDelegate:(id)delegate selector:(SEL)callBackSelectorWithDictionary;


#pragma mark - 在线参数

+ (void)updateOnlineConfig;
+ (NSString *)getConfigParams:(NSString *)key;
+ (NSDictionary *)getConfigParams;


#pragma mark - 地理位置设置

/**
 *	@brief	设置经纬度信息。使用此方法需要添加 CoreLocation.framework 并且 #import <CoreLocation/CoreLocation.h>
 *
 *	@param 	latitude 	纬度
 *	@param 	longitude 	经度
 *
 *	@return	void
 */
+ (void)setLatitude:(double)latitude longitude:(double)longitude;


/**
 *	@brief	设置经纬度信息。使用此方法需要添加 CoreLocation.framework 并且 #import <CoreLocation/CoreLocation.h>
 *
 *	@param 	location 	CLLocation *型的地理信息
 *
 *	@return	void
 */
+ (void)setLocation:(CLLocation *)location;


#pragma mark - 是否越狱和被破解

/**
 *	@brief	是否越狱
 *
 *	@return	YES表示越狱，NO表示没有越狱
 */
+ (BOOL)isJailBroken;


/**
 *	@brief	判断你的App是否被破解
 *
 *	@return	YES表示被破解，NO表示未被破解
 */
+ (BOOL)isPirated;



@end