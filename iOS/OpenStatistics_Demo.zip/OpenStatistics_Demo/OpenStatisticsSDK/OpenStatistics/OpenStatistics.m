//
//  OpenStatistics.m
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-2-20.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "OpenStatistics.h"
#import "OpenStatistics_extension.h"
#import "OSService.h"

#import <CoreLocation/CoreLocation.h>
#import "OSJSONKit.h"
#import "NSString+Common.h"
#import "UIDevice+Common.h"
#import "NSData+Common.h"

#import "NSDate+Common.h"
#import "OSDevice.h"
#import "OSLaunch.h"
#import "OSPage.h"
#import "OSEvent.h"

#import "OSEventKv.h"
#import "OSError.h"
#import "OSCommonReturn.h"
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>

#import <CoreTelephony/CTCall.h>
#import <CoreTelephony/CTCallCenter.h>
#import "OSLog.h"
#import "OpenUDID.h"
#import "OSReachability.h"


#define FACTORY @"Apple";     //factory（制造商）
#define PLATFORMID 2;         //platform id（平台id：1为Android，2为iOS）
#define SDKVERSION @"1.0.0";  //SDK Version（SDK 版本）


@interface OpenStatistics()
{
    NSString *_appKey;           //appKey
    NSString *_appVersion;       //app版本号
    ReportPolicy _policy;        //发送策略
    BOOL isLogEnabled;           //是否打印日志
    BOOL isCrashReportEnabled;   //是否开启崩溃报告
    
    NSString *_channelId;        //渠道名
    NSDate *_startDate;          //开始时间
    NSDate *_endDate;            //结束时间
    double logSendInterval;      //日志发送的间隔时间，默认值为10（秒）
    NSString *_page;             //页面
    
    NSString *_sessionID;        //会话ID
    NSString *_createDate;       //创建时间
    NSString *_deviceID;         //设备ID
    OSLog *_log;                 //日志类
    NSDate *_sendDate;           //成功发送数据时的时刻
    
    NSString *_longitude;        //经度
    NSString *_latitude;         //纬度
    NSInteger inc;               //自增参数
}
@end


@implementation OpenStatistics

//直接写入数据的日志的相对路径
#define kDeviceLog  @"deviceLog"
#define kLaunchLog  @"launchLog"
#define kPageLog    @"pageLog"
#define kEventLog   @"eventLog"
#define kEventKvLog @"eventKvLog"
#define kErrorLog   @"errorLog"

//重命名的日志相对路径
#define kAnotherDeviceLog  @"/Log/anotherDeviceLog"
#define kAnotherLaunchLog  @"/Log/anotherLaunchLog"
#define kAnotherPageLog    @"/Log/anotherPageLog"
#define kAnotherEventLog   @"/Log/anotherEventLog"
#define kAnotherEventKvLog @"/Log/anotherEventKvLog"
#define kAnotherErrorLog   @"/Log/anotherErrorLog"

//Log目录下的日志前缀
#define kAnotherDeviceLogPrefix  @"anotherDeviceLog"
#define kAnotherLaunchLogPrefix  @"anotherLaunchLog"
#define kAnotherPageLogPrefix    @"anotherPageLog"
#define kAnotherEventLogPrefix   @"anotherEventLog"
#define kAnotherEventKvLogPrefix @"anotherEventKvLog"
#define kAnotherErrorLogPrefix   @"anotherErrorLog"

//临时数据日志相对路径
#define kTemporaryDataLog @"/Log/temporaryDataLog"

static OpenStatistics *sharedInstace = nil;

@synthesize isLogEnabled,isCrashReportEnabled,logSendInterval;


#pragma mark - singleton of OpenStatistics

/**
 *	@brief	OpenStatistics单例
 *
 *	@return	OpenStatistics实例
 */
+ (OpenStatistics *) sharedInstance
{
    @synchronized (self)
    {
        if (sharedInstace == nil)
        {
            sharedInstace = [[self alloc] init];
            
            //默认设置
            sharedInstace.isCrashReportEnabled = YES;
            sharedInstace.isLogEnabled = NO;
            sharedInstace.policy = BATCH;
            sharedInstace.appVersion = XcodeAppVersion;
            sharedInstace.channelId = @"App Store";
            
            sharedInstace.logSendInterval = 10;
            sharedInstace.longitude = @"";
            sharedInstace.latitude = @"";
        }
        return sharedInstace;
    }
}


- (void)dealloc
{
    [_log release];
    [_endDate release];
    
    [super dealloc];
}


#pragma mark - 常用设置
/**
 *	@brief	设置App版本号
 *
 *	@param 	appVersion App版本号
 *
 *	@return	void
 */
+ (void)setAppVersion:(NSString *)appVersion
{
    //默认为Bundle中的应用版本号
    [OpenStatistics sharedInstance].appVersion = appVersion;
}


/**
 *	@brief	开启CrashReport收集, 默认是开启状态
 *
 *	@param 	value 	YES为开启，NO为关闭
 *
 *	@return	void
 */
+ (void)setCrashReportEnabled:(BOOL)value
{
    //激活状态下绑定未捕获异常信息。记录错误码、错误描述、以及堆栈信息。
    [OpenStatistics sharedInstance].isCrashReportEnabled = value;
}


/**
 *	@brief	设置是否打印sdk的log信息,默认不开启。
 *
 *	@param 	value 	YES为开启，NO为不开启。
 *
 *	@return	void
 */
+ (void)setLogEnabled:(BOOL)value
{
    [OpenStatistics sharedInstance].isLogEnabled = value;
}


#pragma mark - 开启统计
/**
 *	@brief	开启统计,默认以BATCH方式发送log
 *
 *	@param 	appKey 	appKey
 *	@param 	rp 	发送策略，默认值为BATCH，即应用启动后发送
 *	@param 	cid 	渠道名称，值为nil或@""时，默认@"App Store"渠道
 *
 *	@return	void
 */
+ (void)startWithAppkey:(NSString *)appKey
{
    [[OpenStatistics sharedInstance] initWithAppkey:appKey
                                reportPolicy:BATCH
                                   channelId:@"App Store"];
}

+(void)startWithAppkey:(NSString *)appKey
          reportPolicy:(ReportPolicy)rp
             channelId:(NSString *)cid
{
    [[OpenStatistics sharedInstance] initWithAppkey:appKey
                                       reportPolicy:rp
                                          channelId:cid];
}

- (void)initWithAppkey:(NSString *)appKey
          reportPolicy:(ReportPolicy)rp
             channelId:(NSString *)cid
{
    if (isLogEnabled)
    {
        NSLog(@"begin to init the OpenStatistics SDK");
    }
    
    self.appKey = appKey;
    self.policy = rp;         //渠道默认是BATCH，以后台获取的优先
    if (cid.length == 0)
    {
        cid = @"App Store";   //当渠道值为nil或@""时，默认为@"App Store"
    }
    self.channelId = cid;
    
    //在线获取发送策略，发送策略以从服务器返回策略优先
    if (isLogEnabled)
    {
        NSLog(@"get the reportPolicy online");
    }
    //获取发送策略，如果获取成功则保存获取到的发送策略
    __block OSService *policyInfo = [[OSService alloc] init];
    
    [policyInfo sendReportPolicyInfoWithAppKey:self.appKey
                                        result:^(id responder){
                                            NSLog(@"获取发送策略返回数据:%@",responder);
                                            OSCommonReturn *result = [[OSCommonReturn alloc] init];
                                            result.status = [[responder objectForKey:@"status"] intValue];
                                            result.message = [responder objectForKey:@"msg"];
                                            result.result = [responder objectForKey:@"res"];     //字符串数组
                                            
                                            NSMutableDictionary *config = [result.result objectForKey:@"config"];
                                            NSInteger policy = [[config objectForKey:@"policy"] integerValue];
                                            switch (result.status)
                                            {
                                                case 200:
                                                    NSLog(@"请求发送策略成功！");
                                                    
                                                    //保存在线获取的发送策略
                                                    self.policy = policy;
                                                    
                                                    break;
                                                case 400:
                                                    NSLog(@"无效参数！");
                                                    break;
                                                case 403:
                                                    NSLog(@"无效appkey！");
                                                    break;
                                                case 406:
                                                    NSLog(@"无效数据库内容！");
                                                    break;
                                                case 500:
                                                    NSLog(@"数据库错误！");
                                                    break;
                                                default:
                                                    NSLog(@"获取发送策略失败，未知错误！");
                                                    break;
                                            }
                                            [result release];
                                            [policyInfo release];
                                        }];
    
    _log = [[OSLog alloc] init];    //实例化日志类
    
    //获取启动时间
    self.createDate = [NSDate getDateStr:[NSDate date]];
    if (isLogEnabled)
    {
        NSLog(@"createDate：%@",self.createDate);
    }
    
    //获取deviceID：byteToHex(SHA1(mac+":"+deviceid+":"+model))
    UIDevice *device = [[[UIDevice alloc] init] autorelease];
    NSString *deviceId = [NSString stringWithFormat:@"%@%@%@",[device macAddress],[OpenUDID value],[[UIDevice currentDevice] model]];
    deviceId = [[[deviceId sha1String] dataUsingEncoding:NSUTF8StringEncoding] hexString];
    self.deviceID = deviceId;
    
    //获取sessionID，方式：MD5(appkey + device_id + 当前时间)
    NSString *sessionIdentifier = [[NSString alloc] initWithFormat:@"%@%@%@",appKey,[OpenUDID value],self.createDate];
    self.sessionID = [sessionIdentifier md5DHexDigestString];
    
    if (isLogEnabled)
    {
        NSLog(@"sessionID：%@ ",_sessionID);
    }
    
    //异常崩溃报告
    if (isCrashReportEnabled)
    {
        NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);
    }
    
    //通知中心监听应用的启动和进入后台
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didBecomeActive:)
                                                 name:UIApplicationDidBecomeActiveNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didEnterBackground:)
                                                 name:UIApplicationDidEnterBackgroundNotification
                                               object:nil];

    //创建一个目录：用于存放重命名后的日志文件
    if ([[[OpenStatistics sharedInstance] log] createDirectoty])
    {
        NSLog(@"succeed in creating the Log folder");
    }else
    {
        NSLog(@"failed to create the Log folder");
    };
    
    //写入设备数据
    [[[OpenStatistics sharedInstance] log] writeDeviceLog];
    
    //写入启动数据
    [[[OpenStatistics sharedInstance] log] writeLaunchLog];
    
    //写入启动页面信息
    [[[OpenStatistics sharedInstance] log] writePageLogWithSessionId:_sessionID
                                                           startDate:[NSDate date]
                                                                page:@"initPage"
                                                            duration:0];
    
    [sessionIdentifier release];
}


/**
 *	@brief	异常处理
 *
 *	@param 	exception
 */
void uncaughtExceptionHandler(NSException *exception)

{
    //堆栈跟踪信息
    if ([[OpenStatistics sharedInstance] isLogEnabled])
    {
        NSLog(@"CRASH: %@", exception);
        NSLog(@"Stack Trace: %@", [exception callStackSymbols]);
    }
    NSString *stackTrace = [[NSString alloc] initWithFormat:@"%@\n%@",exception,[exception callStackSymbols]];
    [[OpenStatistics sharedInstance] saveErrorLog:stackTrace];
    
    [stackTrace release];
}


- (void)saveErrorLog:(NSString *)stackTrace
{
    @autoreleasepool
    {
        if (isLogEnabled)
        {
            NSLog(@"save error log");
        }
        [[[OpenStatistics sharedInstance] log] writeErrorLogWithSessionid:_sessionID
                                                                     page:@""
                                                                 errorLog:[NSError description]
                                                               stackTrace:stackTrace];
        [OpenStatistics sendClientDataBasedOnReportPolicy];
    }
}


- (void)didBecomeActive:(NSNotification *)notifation
{
    if (isLogEnabled)
    {
        NSLog(@"Application become active.");
    }
    
    //临时日志判断：如果有临时日志，把临时日志的开始时间改成当前时间
    if ([[NSFileManager defaultManager] fileExistsAtPath:[[[OpenStatistics sharedInstance] log] getFilePath:kTemporaryDataLog]])
    {
        //反归档
        NSMutableDictionary *temDataDic = [NSKeyedUnarchiver unarchiveObjectWithFile:[[[OpenStatistics sharedInstance] log] getFilePath:kTemporaryDataLog]];
        
        //遍历字典所有值
        for (NSMutableDictionary *key in [temDataDic allValues])
        {
            //如果临时日志有开始时间数据，把开始时间改成当前时间
            if ([key objectForKey:@"startDate"])
            {
                [key setObject:[NSDate date] forKey:@"startDate"];
            }
        }
        
        //重新写入临时日志
        if (temDataDic)
        {
            [NSKeyedArchiver archiveRootObject:temDataDic toFile:[[[OpenStatistics sharedInstance] log] getFilePath:kTemporaryDataLog]];
        }
    }
    
    
    //从应用结束时间判断是否要生成一个新的sessionID。如果重新生成，发送新的启动信息。
    if (_endDate)
    {
        NSTimeInterval sessionDuration = - [_endDate timeIntervalSinceNow];
        //退到后台或未操作30000毫秒后失效，重创session_id
        if (sessionDuration + 0.0000001 > 30)
        {
            if (isLogEnabled)
            {
                NSLog(@"Stop session more than 30 seconds, so create a new sessionId.");
            }
            
            //生成新的启动时间
            self.createDate = [NSDate getDateStr:[NSDate date]];
            if (isLogEnabled)
            {
                NSLog(@"新的启动时间:%@",self.createDate);
            }
            
            //重新生成sessionID
            NSString *sessionIdentifier = [[NSString alloc] initWithFormat:@"%@%@%@",_appKey,[OpenUDID value],self.createDate];
            self.sessionID = [sessionIdentifier md5DHexDigestString];
            [sessionIdentifier release];
            
            //把新的启动信息写入日志
            [[[OpenStatistics sharedInstance] log] writeLaunchLog];
        }
    }

    //如果发送策略为BATCH：则发送数据
    if ([[OpenStatistics sharedInstance] policy] == BATCH)
    {
        [self sendClientData];
    }
    else
    {
        //其他发送策略
        [OpenStatistics sendClientDataBasedOnReportPolicy];
    }
    
}


- (void)didEnterBackground:(NSNotification *)notifation
{
    if (isLogEnabled)
    {
        NSLog(@"Application Resign Active.");
    }
    
    //查找临时日志：有则计算出时长，写入正式日志
    if ([[[OpenStatistics sharedInstance] log] getFilePath:kTemporaryDataLog])
    {
        NSDictionary *temDataDic = [NSKeyedUnarchiver unarchiveObjectWithFile:[[[OpenStatistics sharedInstance] log] getFilePath:kTemporaryDataLog]];
        
        for (NSString *key in [temDataDic allKeys])
        {
            NSDictionary *data = [temDataDic objectForKey:key];
            //获取开始时间
            NSDate *startDate = [data objectForKey:@"startDate"];
            
            //是否有page数据
            if ([key hasPrefix:@"page"])
            {
                if ([[OpenStatistics sharedInstance] isLogEnabled])
                {
                    NSLog(@"退出时还有临时页面数据");
                }
                [[[OpenStatistics sharedInstance] log] writePageLogWithSessionId:[[OpenStatistics sharedInstance] sessionID]
                                                                       startDate:startDate
                                                                            page:[data objectForKey:@"pageName"]
                                                                        duration:-[startDate timeIntervalSinceNow]];
            }
            
            //是否有自定义事件EventKv数据
            if ([key hasPrefix:@"cEvent"])
            {
                if ([OpenStatistics sharedInstance])
                {
                    NSLog(@"退出时还有临时自定义事件数据");
                }
                [[[OpenStatistics sharedInstance] log] writeEventKvLogWithSessionId:[[OpenStatistics sharedInstance] sessionID]
                                                                         createDate:startDate
                                                                           eventKey:[data objectForKey:@"eventkey"]
                                                                               page:[data objectForKey:@"pageName"]
                                                                         attributes:[data objectForKey:@"attributes"]
                                                                              label:[data objectForKey:@"label"]
                                                                          noticeNum:1
                                                                           duration:-[startDate timeIntervalSinceNow]];
            }
            
            //是否有Event数据
            if ([key hasPrefix:@"event"])
            {
                if ([[OpenStatistics sharedInstance] isLogEnabled])
                {
                    NSLog(@"退出时还有临时事件数据");
                }
                
                [[[OpenStatistics sharedInstance] log] writeEventLogWithSessionId:[[OpenStatistics sharedInstance] sessionID]
                                                                       createDate:startDate
                                                                         eventKey:[data objectForKey:@"eventKey"]
                                                                             page:[data objectForKey:@"pageName"]
                                                                            label:[data objectForKey:@"label"]
                                                                        noticeNum:1
                                                                         duration:-[startDate timeIntervalSinceNow]];
            }
        }
    }
    
    //如果发送策略为退出发送
    if ([[OpenStatistics sharedInstance] policy] == SEND_ON_EXIT)
    {
        self.policy = BATCH;
//        [self sendClientData];
    }
//    else
//    {
//        [OpenStatistics sendClientDataBasedOnReportPolicy];
//    }
    
    if (_endDate)
    {
        [_endDate release];
        _endDate = nil;
    }
    _endDate = [[NSDate date] retain];
    
    if (isLogEnabled)
    {
        NSLog(@"程序最后退出");
    }
}


/**
 *	@brief	当reportPolicy为SEND_INTERVAL时，设定log发送间隔。
 *
 *	@param 	second 	单位为秒,最小为10秒,最大为86400秒(一天)
 *
 *	@return	void
 */
+ (void)setLogSendInterval:(double)second
{
    //根据second设置每隔多少秒发送日志
    [OpenStatistics sharedInstance].logSendInterval = second;
}


#pragma mark - 页面时长统计
/**
 *	@brief	页面时长统计,记录某个view被打开多长时间。也可以调用beginLogPageView,endLogPageView自动计时。
 *
 *	@param 	pageName 	需要记录时长的view名称
 *	@param 	seconds 	秒数，int型
 *
 *	@return	void
 */
+ (void)logPageView:(NSString *)pageName seconds:(int)seconds
{
    
    [[[OpenStatistics sharedInstance] log] writePageLogWithSessionId:[[OpenStatistics sharedInstance] sessionID]
                                                           startDate:[NSDate date]
                                                                page:pageName
                                                            duration:seconds];
}


/**
 *	@brief	开始页面统计
 *
 *	@param 	pageName 	页面名
 *
 *	@return	void
 */
+ (void)beginLogPageView:(NSString *)pageName
{
    //写入临时日志等待调用结束时正式写入日志，需要考虑应用崩溃或异常处理
    [[[OpenStatistics sharedInstance] log] writeTemporaryPageLogWithPageName:pageName
                                                                   startDate:[NSDate date]];
    //异常崩溃报告
    if ([OpenStatistics sharedInstance].isCrashReportEnabled)
    {
        NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);
    }
}


/**
 *	@brief	停止页面统计
 *
 *	@param 	pageName 	页面名
 *
 *	@return	void
 */
+ (void)endLogPageView:(NSString *)pageName
{
    //获取开始时间，用于计算出时长
    NSDictionary *data = [[[OpenStatistics sharedInstance] log] getPageStartDate:pageName];
    NSDate *startDate = [data objectForKey:@"startDate"];
    
    if (startDate ==nil)
    {
        startDate = [NSDate date];
    }
    
    //写入页面日志
    [[[OpenStatistics sharedInstance] log] writePageLogWithSessionId:[[OpenStatistics sharedInstance] sessionID]
                                                           startDate:startDate
                                                                page:pageName
                                                            duration:-[startDate timeIntervalSinceNow]];
    //异常崩溃报告
    if ([OpenStatistics sharedInstance].isCrashReportEnabled)
    {
        NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);
    }
    
    [OpenStatistics sendClientDataBasedOnReportPolicy];
    
    //删除临时页面数据
    [[[[OpenStatistics sharedInstance] log] temporaryDict] removeObjectForKey:[NSString stringWithFormat:@"page%@",pageName]];
    NSLog(@"temporaryDict:%@",[[[OpenStatistics sharedInstance] log] temporaryDict]);
    [NSKeyedArchiver archiveRootObject:[[[OpenStatistics sharedInstance] log] temporaryDict]
                                toFile:[[OpenStatistics sharedInstance].log getFilePath:kTemporaryDataLog]];
    NSLog(@"结束页面统计");
}


#pragma mark - 自定义事件
/**
 *	@brief	自定义事件
 *
 *	@param 	eventId 	事件Id
 *	@param 	label 	标签
 *	@param 	accumulation 	累加
 *
 *	@return	void
 */
+ (void)event:(NSString *)eventId
{
    //写入日志
    [[[OpenStatistics sharedInstance] log] writeEventLogWithSessionId:[[OpenStatistics sharedInstance] sessionID]
                                                           createDate:[NSDate date]
                                                             eventKey:eventId
                                                                 page:@""
                                                                label:@""
                                                            noticeNum:1
                                                             duration:0];
    [self sendClientDataBasedOnReportPolicy];
}


+ (void)event:(NSString *)eventId label:(NSString *)label
{
    //写入日志
    [[[OpenStatistics sharedInstance] log] writeEventLogWithSessionId:[[OpenStatistics sharedInstance] sessionID]
                                                           createDate:[NSDate date]
                                                             eventKey:eventId
                                                                 page:@""
                                                                label:label
                                                            noticeNum:1
                                                             duration:0];
    [self sendClientDataBasedOnReportPolicy];
}


+ (void)event:(NSString *)eventId acc:(NSInteger)accumulation
{
    //写入日志
    [[[OpenStatistics sharedInstance] log] writeEventLogWithSessionId:[[OpenStatistics sharedInstance] sessionID]
                                                           createDate:[NSDate date]
                                                             eventKey:eventId
                                                                 page:@""
                                                                label:@""
                                                            noticeNum:accumulation
                                                             duration:0];
    [self sendClientDataBasedOnReportPolicy];
}


+ (void)event:(NSString *)eventId label:(NSString *)label acc:(NSInteger)accumulation
{
    //写入日志
    [[[OpenStatistics sharedInstance] log] writeEventLogWithSessionId:[[OpenStatistics sharedInstance] sessionID]
                                                           createDate:[NSDate date]
                                                             eventKey:eventId
                                                                 page:@""
                                                                label:label
                                                            noticeNum:accumulation
                                                             duration:0];
    
    [self sendClientDataBasedOnReportPolicy];
}


+ (void)event:(NSString *)eventId attributes:(NSDictionary *)attributes
{
    //写入日志
    [[[OpenStatistics sharedInstance] log]  writeEventKvLogWithSessionId:[[OpenStatistics sharedInstance] sessionID]
                                                              createDate:[NSDate date]
                                                                eventKey:eventId
                                                                    page:@""
                                                              attributes:attributes
                                                                   label:@""
                                                               noticeNum:1
                                                                duration:0];
    [self sendClientDataBasedOnReportPolicy];
}


+ (void)beginEvent:(NSString *)eventId
{
    //写入临时日志等待调用结束统计时长时正式写入日志。需要考虑崩溃和异常处理
    [[[OpenStatistics sharedInstance] log]  writeTemporaryEventLogWithSessionId:eventId
                                                                      startDate:[NSDate date]
                                                                          label:@""
                                                                           page:@""];
    //异常崩溃报告
    if ([OpenStatistics sharedInstance].isCrashReportEnabled)
    {
        NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);
    }
}


+ (void)endEvent:(NSString *)eventId
{
    //写入临时日志等待调用结束统计时长时正式写入日志。需考虑崩溃和异常处理
    
    //获取事件开始时间
    NSDictionary *data = [[[OpenStatistics sharedInstance] log] getEventStartDateWithEventId:eventId
                                                                                      label:@""];
    
    NSDate *startDate = [data objectForKey:@"startDate"];
    
    //写入日志文件
    [[[OpenStatistics sharedInstance] log] writeEventLogWithSessionId:[[OpenStatistics sharedInstance] sessionID]
                                                           createDate:startDate
                                                             eventKey:eventId
                                                                 page:@""
                                                                label:@""
                                                            noticeNum:1
                                                             duration:-[startDate timeIntervalSinceNow]];
    
    //异常崩溃报告
    if ([OpenStatistics sharedInstance].isCrashReportEnabled)
    {
        NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);
    }
    
    [self sendClientDataBasedOnReportPolicy];
    
    //删除临时数据
    [[[[OpenStatistics sharedInstance] log] temporaryDict] removeObjectForKey:[NSString stringWithFormat:@"event%@%@",eventId,@""]];
    [NSKeyedArchiver archiveRootObject:[[[OpenStatistics sharedInstance] log] temporaryDict]
                                toFile:[[OpenStatistics sharedInstance].log getFilePath:kTemporaryDataLog]];
}


+ (void)beginEvent:(NSString *)eventId label:(NSString *)label
{
    //写入临时日志等待调用结束统计时长时正式写入日志。需要考虑崩溃和异常处理
    [[[OpenStatistics sharedInstance] log] writeTemporaryEventLogWithSessionId:eventId
                                                                     startDate:[NSDate date]
                                                                         label:label
                                                                          page:@""];
    //异常崩溃报告
    if ([OpenStatistics sharedInstance].isCrashReportEnabled)
    {
        NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);
    }
}


+ (void)endEvent:(NSString *)eventId label:(NSString *)label
{
    NSDictionary *data = [[[OpenStatistics sharedInstance] log] getEventStartDateWithEventId:eventId
                                                                                      label:label];
    //获取事件开始时间
    NSDate *startDate = [data objectForKey:@"startDate"];
    
    
    //写入日志文件
    [[[OpenStatistics sharedInstance] log] writeEventLogWithSessionId:[[OpenStatistics sharedInstance] sessionID]
                                                           createDate:startDate
                                                             eventKey:eventId
                                                                 page:@""
                                                                label:label
                                                            noticeNum:1
                                                             duration:-[startDate timeIntervalSinceNow]];
    [self sendClientDataBasedOnReportPolicy];
    
    [[[[OpenStatistics sharedInstance] log] temporaryDict] removeObjectForKey:[NSString stringWithFormat:@"event%@%@",eventId,label]];
    [NSKeyedArchiver archiveRootObject:[[[OpenStatistics sharedInstance] log] temporaryDict]
                                toFile:[[OpenStatistics sharedInstance].log getFilePath:kTemporaryDataLog]];
}


+ (void)beginEvent:(NSString *)eventId primarykey:(NSString *)keyName attributes:(NSDictionary *)attributes
{
    //写入临时日志等待调用结束统计时长时正式写入日志。需要考虑崩溃和异常处理
    [[[OpenStatistics sharedInstance] log] writeTemporaryEventKvLogWithEventKey:eventId
                                                                      startDate:[NSDate date]
                                                                     attributes:attributes
                                                                     primarykey:keyName
                                                                          label:@""
                                                                           page:@""];
    //异常崩溃报告
    if ([OpenStatistics sharedInstance].isCrashReportEnabled)
    {
        NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);
    }
    
}

+ (void)endEvent:(NSString *)eventId primarykey:(NSString *)keyName
{
    //写入临时日志等待调用结束统计时长时正式写入日志。需考虑崩溃和异常处理
    
    //获取事件开始时间
    NSDictionary *data = [[[OpenStatistics sharedInstance] log] getEventKvStartDateWithEventKey:eventId
                                                                                          label:@""
                                                                                     primarykey:keyName];
    NSDate *startDate = [data objectForKey:@"startDate"];
    
    
    
    [[[OpenStatistics sharedInstance] log] writeEventKvLogWithSessionId:[OpenStatistics sharedInstance].sessionID
                                                             createDate:startDate
                                                               eventKey:eventId
                                                                   page:@""
                                                             attributes:[data objectForKey:@"attributes"]
                                                                  label:@""
                                                              noticeNum:1
                                                               duration:-[startDate timeIntervalSinceNow]];
    //异常崩溃报告
    if ([OpenStatistics sharedInstance].isCrashReportEnabled)
    {
        NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);
    }
    
    //根据发送策略决定是否发送
    [self sendClientDataBasedOnReportPolicy];
    
    //删除临时数据
    [[[[OpenStatistics sharedInstance] log] temporaryDict] removeObjectForKey:[NSString stringWithFormat:@"cEvent%@%@%@",eventId,keyName,@""]];
    [NSKeyedArchiver archiveRootObject:[[[OpenStatistics sharedInstance] log] temporaryDict]
                                toFile:[[OpenStatistics sharedInstance].log getFilePath:kTemporaryDataLog]];
}


+ (void)event:(NSString *)eventId durations:(int)millisecond
{
    [[[OpenStatistics sharedInstance] log] writeEventLogWithSessionId:[[OpenStatistics sharedInstance] sessionID]
                                                           createDate:[NSDate date]
                                                             eventKey:eventId
                                                                 page:@""
                                                                label:@""
                                                            noticeNum:1
                                                             duration:millisecond];
    [self sendClientDataBasedOnReportPolicy];
}


+ (void)event:(NSString *)eventId label:(NSString *)label durations:(int)millisecond
{
    //写入日志
    [[[OpenStatistics sharedInstance] log] writeEventLogWithSessionId:[[OpenStatistics sharedInstance] sessionID]
                                                           createDate:[NSDate date]
                                                             eventKey:eventId
                                                                 page:@""
                                                                label:label
                                                            noticeNum:1
                                                             duration:millisecond];
    [self sendClientDataBasedOnReportPolicy];
}


+ (void)event:(NSString *)eventId attributes:(NSDictionary *)attributes durations:(int)millisecond
{
    //写入日志
    [[[OpenStatistics sharedInstance] log] writeEventKvLogWithSessionId:[[OpenStatistics sharedInstance] sessionID]
                                                             createDate:[NSDate date]
                                                               eventKey:eventId
                                                                   page:@""
                                                             attributes:attributes
                                                                  label:@""
                                                              noticeNum:1
                                                               duration:millisecond];
    [self sendClientDataBasedOnReportPolicy];
}


#pragma mark - 检测更新
+ (void)checkUpdate
{
    //调用服务器接口进行检测
}

+ (void)checkUpdate:(NSString *)title cancelButtonTitle:(NSString *)cancelTitle otherButtonTitles:(NSString *)otherTitle
{
    //调用服务器接口进行检测
}

+ (void)checkUpdateWithDelegate:(id)delegate selector:(SEL)callBackSelectorWithDictionary
{
    //调用服务器接口进行检测
}


#pragma mark - 在线设置
+ (void)updateOnlineConfig
{
}

+ (NSString *)getConfigParams:(NSString *)key
{
    return nil;
}

+ (NSDictionary *)getConfigParams
{
    //返回整个缓存在线参数配置
    return nil;
}


#pragma mark - 获取位置信息

/**
 *	@brief	获取位置信息
 *
 *	@param 	latitude 	纬度
 *	@param 	longitude 	经度
 *
 *	@return	void
 */
+ (void)setLatitude:(double)latitude longitude:(double)longitude
{
    [OpenStatistics sharedInstance].longitude = [NSString stringWithFormat:@"%f",longitude];
    [OpenStatistics sharedInstance].latitude = [NSString stringWithFormat:@"%f",latitude];
}


/**
 *	@brief	获取位置信息
 *
 *	@param 	location 	(CLLocation *)
 *
 *	@return	void
 */
+ (void)setLocation:(CLLocation *)location
{
    [OpenStatistics sharedInstance].longitude = [NSString stringWithFormat:@"%f",location.coordinate.longitude];
    [OpenStatistics sharedInstance].latitude = [NSString stringWithFormat:@"%f",location.coordinate.latitude];
}


#pragma mark - 是否越狱和被破解

/**
 *	@brief	是否越狱
 *
 *	@return	YES表示越狱，NO表示没有越狱
 */

+ (BOOL)isJailBroken
{
    static const char * __jb_app = NULL;
    static const char * __jb_apps[] =
    {
        "/Application/Cydia.app",
        "/Application/limera1n.app",
        "/Application/greenpois0n.app",
        "/Application/blackra1n.app",
        "/Application/blacksn0w.app",
        "/Application/redsn0w.app",
        NULL
    };
    __jb_app = NULL;
    for ( int i = 0; __jb_apps[i]; ++i )
    {
        if ( [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithUTF8String:__jb_apps[i]]] )
        {
            __jb_app = __jb_apps[i];
            return YES;
        }
    }
    if ( [[NSFileManager defaultManager] fileExistsAtPath:@"/private/var/lib/apt/"] )
    {
        return YES;
    }
    if ( 0 == system("ls") )
    {
        return YES;
    }
    return NO;
}


/**
 *	@brief	判断你的App是否被破解
 *
 *	@return	YES表示被破解，NO表示未被破解
 */
+ (BOOL)isPirated
{
    NSString *bundlePath = [[NSBundle mainBundle] bundlePath];
    /*SC _Info*/
    if (![[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@/SC_Info",bundlePath]]) {
        return YES;
    }
    /* iTunesMetadata.plist */
    if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@/iTunesMetadata.plist",bundlePath]]) {
        return YES;
    }
    return NO;
}


#pragma mark - 获取设备数据
- (OSDevice *)getDeviceInfo
{
    OSDevice *deviceInfo = [[[OSDevice alloc] init] autorelease];
    
    //获取设备deviceID、appVerison、appPackage、platformID、sdkVersion
    deviceInfo.deviceID = self.deviceID;
    deviceInfo.appVersion = XcodeAppVersion;
    deviceInfo.appPackage = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleDisplayName"];
    deviceInfo.platformID = PLATFORMID;
    deviceInfo.sdkVersion = SDKVERSION;
    
    //渠道名称、Mac地址、设备型号、系统版本、网络运营商
    deviceInfo.channelName = [[OpenStatistics sharedInstance] channelId];
    deviceInfo.mac = [[[[UIDevice alloc] init] autorelease] macAddress];
    deviceInfo.model = [[UIDevice currentDevice] model];
    deviceInfo.sysVersion = [[UIDevice currentDevice] systemVersion];
    CTTelephonyNetworkInfo *netInfo =[[[CTTelephonyNetworkInfo alloc] init] autorelease];
    CTCarrier *carrier =[netInfo subscriberCellularProvider];
    if (carrier == nil)
    {
        deviceInfo.carrier = @"";
    }
    else
    {
        NSString *mcc =[carrier mobileCountryCode];
        NSString *mnc =[carrier mobileNetworkCode];
        deviceInfo.carrier = [mcc stringByAppendingString:mnc];
    }
    
    //分辨率、设备厂商、网络类型、是否越狱、是否被破解
    CGRect rect = [[UIScreen mainScreen] bounds];
    CGFloat scale = [[UIScreen mainScreen] scale];
    deviceInfo.screenSize = [[[NSString alloc] initWithFormat:@"%.fx%.f",rect.size.width*scale,rect.size.height*scale] autorelease];
    deviceInfo.factory = FACTORY;
    switch ([[[[OSReachability alloc] init] autorelease] currentReachabilityStatus]) {
        case kCMNotReachable:
            deviceInfo.networkType = @"none";
            break;
        case kCMReachableViaWWAN:
            deviceInfo.networkType = @"2G/3G";
            break;
        case kCMReachableViaWiFi:
            deviceInfo.networkType = @"Wifi";
            break;
    }
    if ([OpenStatistics isJailBroken])
    {
        deviceInfo.isJailbroken = 1;
    }
    else
    {
        deviceInfo.isJailbroken = 0;
    }
    
    if ([OpenStatistics isPirated])
    {
        deviceInfo.isPirated = 1;
    }
    else
    {
        deviceInfo.isPirated = 0;
    }
    
    //经度、纬度设备语言、时区
    deviceInfo.longitude = [[OpenStatistics sharedInstance] longitude];
    deviceInfo.latitude = [[OpenStatistics sharedInstance] latitude];
    deviceInfo.language = [[NSLocale preferredLanguages] objectAtIndex:0];
    
    NSTimeZone *localTimeZone = [NSTimeZone localTimeZone];
    deviceInfo.timeZone = [[NSString stringWithFormat:@"%@",localTimeZone] substringWithRange:NSMakeRange(36, 2)];
    
    return deviceInfo;
    
}


#pragma mark - 获取启动信息
- (OSLaunch *)getLaunchData
{
    OSLaunch *launchInfo = [[[OSLaunch alloc] init] autorelease];
    launchInfo.sessionID = [[OpenStatistics sharedInstance] sessionID];
    launchInfo.createDate = [[OpenStatistics sharedInstance] createDate];
    
    return launchInfo;
}


#pragma mark - send data

/**
 *	@brief	根据发送策略判断是否发送数据
 *
 *	@return	void
 */
+ (void)sendClientDataBasedOnReportPolicy
{
    switch ([[OpenStatistics sharedInstance] policy])
    {
            //间隔发送：如距离上次发送成功的时间大于发送时间间隔则发送
        case SEND_INTERVAL:
            if ([[OpenStatistics sharedInstance] isLogEnabled])
            {
                NSLog(@"距离上次成功发送的时间：%f",-[[OpenStatistics sharedInstance].sendDate timeIntervalSinceNow]);
            }
            
            if (-[[OpenStatistics sharedInstance].sendDate timeIntervalSinceNow]>[[OpenStatistics sharedInstance] logSendInterval])
            {
                [[OpenStatistics sharedInstance] sendClientData];
            }
            break;
            
            //每日发送：距离上次发送成功的时间大于一天（86400秒）则发送
        case SENDDAILY:
            if (-[[OpenStatistics sharedInstance].sendDate timeIntervalSinceNow]>86400)
            {
                [[OpenStatistics sharedInstance] sendClientData];
            }
            break;
            
            //实时发送：立刻发送(REALTIME,SENDWIFIONLY 只在模拟器和DEBUG模式下生效，真机release模式会自动改成BATCH)
        case REALTIME:
            if ([[[UIDevice currentDevice] model]  isEqual: @"iPad Simulator"] || [[[UIDevice currentDevice] model] isEqualToString:@"iPhone Simulator"] || [[OpenStatistics sharedInstance] isLogEnabled])
            {
                [[OpenStatistics sharedInstance] sendClientData];
            }else
            {
                [OpenStatistics sharedInstance].policy = BATCH;
            }
            break;
            
            //Wifi环境下发送：如处于Wifi环境则发送(REALTIME,SENDWIFIONLY 只在模拟器和DEBUG模式下生效，真机release模式会自动改成BATCH)
        case SENDWIFIONLY:
            if ([[[UIDevice currentDevice] model]  isEqual: @"iPad Simulator"] || [[[UIDevice currentDevice] model] isEqualToString:@"iPhone Simulator"] || [[OpenStatistics sharedInstance] isLogEnabled])
            {
                if ([[[[UIDevice alloc] init] autorelease] isEnableWIFI])
                {
                    [[OpenStatistics sharedInstance] sendClientData];
                }
            }else
            {
                [OpenStatistics sharedInstance].policy = BATCH;
            }
            break;
            
        default:
            break;
    }
}


/**
 *	@brief	发送数据
 *
 *	@return	void
 */
- (void)sendClientData
{
    OSService *send = [[OSService alloc] init];
    
    OSLog *log = [[OpenStatistics sharedInstance] log];
    NSTimeInterval timestamp = [[NSDate date] timeIntervalSince1970];
    
    //每次发送做一次自增操作
    inc ++;
    timestamp += inc;
    
    //获取发送数据
    NSString *requestDataStr = [send requestDataWithDeviceDic:[log readDeviceLog]
                                                  launchArray:[log readLaunchLog:timestamp]
                                                    pageArray:[log readPageLog:timestamp]
                                                   eventArray:[log readEventLog:timestamp]
                                                 eventKvArray:[log readEventKvLog:timestamp]
                                                   errorArray:[log readErrorLog:timestamp]];
    
    //发送数据
    [send sendClientDataWithAppKey:[[OpenStatistics sharedInstance] appKey]
                        clientData:requestDataStr
                            result:^(id responder)
     {
         //请求返回信息
         NSLog(@"发送请求的返回数据:%@",responder);
         OSCommonReturn *result = [[OSCommonReturn alloc] init];
         result.status = [[responder objectForKey:@"status"] intValue];
         result.message = [responder objectForKey:@"msg"];
         result.result = [responder objectForKey:@"res"];     //字符串数组
         
         NSMutableDictionary *config = [result.result objectForKey:@"config"];
         NSInteger policy = [[config objectForKey:@"policy"] integerValue];
         NSInteger duration = [[config objectForKey:@"duraiton"] integerValue];
         NSString *apiPath = [config objectForKey:@"api_path"];
         NSLog(@"policy:%i,duration:%i,api_path:%@",policy,duration,apiPath);
         
         //发送数据成功，记录发送成功时间，删除重命名日志
         if (result.status == 200)
         {
             if (_sendDate)
             {
                 [_sendDate release];
             }
             _sendDate = [[NSDate date] retain];
             
             OSLog *log =[[OpenStatistics sharedInstance] log];
             [log deleteLog:[NSString stringWithFormat:@"%@%.0f",kAnotherLaunchLog,timestamp]];
             [log deleteLog:[NSString stringWithFormat:@"%@%.0f",kAnotherPageLog,timestamp]];
             [log deleteLog:[NSString stringWithFormat:@"%@%.0f",kAnotherEventLog,timestamp]];
             [log deleteLog:[NSString stringWithFormat:@"%@%.0f",kAnotherEventKvLog,timestamp]];
             [log deleteLog:[NSString stringWithFormat:@"%@%.0f",kAnotherErrorLog,timestamp]];
         }else
         {
        //发送失败，数组合并，删除重命名文件
             OSLog *log =[[OpenStatistics sharedInstance] log];
             
             log.deviceDic = [log readDeviceLog];
             
             if ([log readLaunchLog:timestamp])
             {
                 [log.launchArray addObjectsFromArray:[log readLaunchLog:timestamp]];
             }
             
             if ([log readPageLog:timestamp])
             {
                 [log.pageArray addObjectsFromArray:[log readPageLog:timestamp]];
             }
             
             if ([log readEventLog:timestamp])
             {
                 [log.eventArray addObjectsFromArray:[log readEventLog:timestamp]];
             }
             
             if ([log readEventKvLog:timestamp])
             {
                 [log.eventKvArray addObjectsFromArray:[log readEventKvLog:timestamp]];
             }
             
             if ([log readErrorLog:timestamp])
             {
                 [log.errorArray addObjectsFromArray:[log readErrorLog:timestamp]];
             }
             
             //写入文件
             [NSKeyedArchiver archiveRootObject:log.deviceDic toFile:[log getFilePath:kDeviceLog]];
             [NSKeyedArchiver archiveRootObject:log.launchArray toFile:[log getFilePath:kLaunchLog]];
             [NSKeyedArchiver archiveRootObject:log.pageArray toFile:[log getFilePath:kPageLog]];
             [NSKeyedArchiver archiveRootObject:log.eventArray toFile:[log getFilePath:kEventLog]];
             [NSKeyedArchiver archiveRootObject:log.eventKvArray toFile:[log getFilePath:kEventKvLog]];
             [NSKeyedArchiver archiveRootObject:log.errorArray toFile:[log getFilePath:kErrorLog]];
             
             //删除重命名文件
             [log deleteLog:[NSString stringWithFormat:@"%@%.0f",kAnotherLaunchLog,timestamp]];
             [log deleteLog:[NSString stringWithFormat:@"%@%.0f",kAnotherPageLog,timestamp]];
             [log deleteLog:[NSString stringWithFormat:@"%@%.0f",kAnotherEventLog,timestamp]];
             [log deleteLog:[NSString stringWithFormat:@"%@%.0f",kAnotherEventKvLog,timestamp]];
             [log deleteLog:[NSString stringWithFormat:@"%@%.0f",kAnotherErrorLog,timestamp]];
         }
         
         switch (result.status)
         {
             case 200:
                 NSLog(@"发送数据成功！");
                 break;
             case 400:
                 NSLog(@"无效参数！");
                 break;
             case 403:
                 NSLog(@"无效appkey！");
                 break;
             case 406:
                 NSLog(@"无效数据库内容！");
                 break;
             case 500:
                 NSLog(@"数据库错误！");
                 break;
             default:NSLog(@"发送数据失败，错误未知！");
                 break;
         }
         [result release];
     }];
    [send release];
}



@end
