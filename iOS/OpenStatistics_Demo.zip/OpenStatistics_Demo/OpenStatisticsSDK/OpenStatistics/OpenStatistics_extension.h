//
//  OpenStatistics_extension.h
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-3-11.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "OpenStatistics.h"
#import "OSDevice.h"
#import "OSLaunch.h"
#import "OSLog.h"

@interface OpenStatistics ()

@property (nonatomic, copy) NSString *appKey;          //appKey
@property (nonatomic, copy) NSString *appVersion;      //app版本号
@property (nonatomic, readwrite) ReportPolicy policy;  //发送策略
@property (nonatomic) BOOL isLogEnabled;               //是否打印日志
@property (nonatomic) BOOL isCrashReportEnabled;       //是否开启崩溃报告

@property (nonatomic, copy) NSString *channelId;     //渠道名
@property (nonatomic, copy) NSDate *startDate;       //开始时间
@property (nonatomic, copy) NSDate *endDate;         //结束时间
@property (nonatomic) double logSendInterval;        //日志发送的间隔时间
@property (nonatomic, copy) NSString *page;          //页面

@property (nonatomic, copy) NSString *sessionID;     //sessionID
@property (nonatomic, copy) NSString *createDate;    //创建时间
@property (nonatomic, copy) NSString *deviceID;      //设备ID
@property (nonatomic, strong) OSLog *log;            //日志类
@property (nonatomic, strong) NSDate *sendDate;      //发送数据成功的时刻

@property (nonatomic, copy) NSString *longitude;     //经度
@property (nonatomic, copy) NSString *latitude;      //纬度


+ (OpenStatistics *) sharedInstance;
- (OSDevice *)getDeviceInfo;
- (OSLaunch *)getLaunchData;

@end
