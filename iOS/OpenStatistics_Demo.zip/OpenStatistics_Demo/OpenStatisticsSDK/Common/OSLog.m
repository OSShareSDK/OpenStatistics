//
//  OSLog.m
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-2-27.
//  Copyright (c) 2014年 shareSDK. All rights reserved.
//

#import "OSLog.h"
#import "OSJSONKit.h"
#import "UIDevice+Common.h"
#import "OpenStatistics.h"
#import "OpenStatistics_extension.h"

#import "OSOpenUDID.h"
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>
#import <CoreTelephony/CTCall.h>
#import <CoreTelephony/CTCallCenter.h>

#import "OSDevice.h"
#import "OSLaunch.h"
#import "OSExit.h"
#import "OSPage.h"
#import "OSEvent.h"

#import "OSEventKv.h"
#import "OSError.h"
#import "NSString+Common.h"
#import "NSData+Common.h"
#import "NSDate+Common.h"


@implementation OSLog

//直接写入日志的相对路径
#define kDeviceLog  @"deviceLog"
#define kLaunchLog  @"launchLog"
#define kExitLog    @"exitLog"
#define kPageLog    @"pageLog"
#define kEventLog   @"eventLog"
#define kEventKvLog @"eventKvLog"
#define kErrorLog   @"errorLog"

//重命名的日志相对路径
#define kAnotherDeviceLog  @"/Log/anotherDeviceLog"
#define kAnotherLaunchLog  @"/Log/anotherLaunchLog"
#define kAnotherExitLog    @"/Log/anotherExitLog"
#define kAnotherPageLog    @"/Log/anotherPageLog"
#define kAnotherEventLog   @"/Log/anotherEventLog"
#define kAnotherEventKvLog @"/Log/anotherEventKvLog"
#define kAnotherErrorLog   @"/Log/anotherErrorLog"

//Log目录下的日志前缀
#define kAnotherDeviceLogPrefix  @"anotherDeviceLog"
#define kAnotherLaunchLogPrefix  @"anotherLaunchLog"
#define kAnotherExitLogPrefix    @"anotherExitLog"
#define kAnotherPageLogPrefix    @"anotherPageLog"
#define kAnotherEventLogPrefix   @"anotherEventLog"
#define kAnotherEventKvLogPrefix @"anotherEventKvLog"
#define kAnotherErrorLogPrefix   @"anotherErrorLog"

//临时数据日志相对路径
#define kTemporaryDataLog @"/Log/temporaryDataLog"

//文件夹相对路径
#define kLogDirectory     @"/Log"

//存储退出时间日志文件目录
#define kExitDateLog      @"exitDateLog"

- (id)init
{
    if (self = [super init])
    {
        //1，判断指定路径有没有文件，有则反序列化，没有则实例化。
        //2：反序列有没有数据，没有则实例化
        //3：发送文件夹有没有日志，有则合并
        
        //Device
        if ([[NSFileManager defaultManager] fileExistsAtPath:[self getFilePath:kDeviceLog]])
        {
            if (_deviceDic)
            {
                [_deviceDic release];
            }
            _deviceDic = [[NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:kDeviceLog]] retain];
            
            if (_deviceDic == nil)
            {
                _deviceDic = [[NSMutableDictionary alloc] init];
            }
        }else
        {
            _deviceDic = [[NSMutableDictionary alloc] init];
        }
        
        
        //Launch
        if ([[NSFileManager defaultManager] fileExistsAtPath:[self getFilePath:kLaunchLog]])
        {
            if (_launchArray)
            {
                [_launchArray release];
            }
            _launchArray = [[NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:kLaunchLog]] retain];
            
            if (_launchArray == nil)
            {
                _launchArray = [[NSMutableArray alloc] init];
            }
        }
        else
        {
            _launchArray = [[NSMutableArray alloc] init];
        }
        
        //从Log目录获取日志文件列表
        NSArray *launchFiles = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:[self getFilePath:kLogDirectory]
                                                                                   error:nil];
        for (NSString *fileName in launchFiles)
        {
            if ([fileName hasPrefix:kAnotherLaunchLogPrefix])
            {
                //如果重命名的日志不为空，则合并数组。
                id data = [NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:fileName]];
                if ([data isKindOfClass:[NSArray class]])
                {
                    [_launchArray addObjectsFromArray:data];
                }
                //合并后删除
                [[NSFileManager defaultManager] removeItemAtPath:[self getFilePath:[NSString stringWithFormat:@"%@/%@",kLogDirectory,fileName]] error:NULL];
            }
        }
        
        
        //Exit
        if ([[NSFileManager defaultManager] fileExistsAtPath:[self getFilePath:kExitLog]])
        {
            if (_exitArray)
            {
                [_exitArray release];
            }
            _exitArray = [[NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:kExitLog]] retain];
            if (_exitArray == nil)
            {
                _exitArray = [[NSMutableArray alloc] init];
            }
        }
        else
        {
            _exitArray = [[NSMutableArray alloc] init];
        }
        
        //从Log目录获取日志文件列表
        NSArray *exitFile = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:[self getFilePath:kLogDirectory]
                                                                                error:nil];
        for (NSString *fileName in exitFile)
        {
            if ([fileName hasPrefix:kAnotherExitLogPrefix])
            {
                //如果重命名的日志不为空，则合并数组
                id data = [NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:fileName]];
                if ([data isKindOfClass:[NSArray class]])
                {
                    [_exitArray addObjectsFromArray:data];
                }
                
                //合并后删除
                [[NSFileManager defaultManager] removeItemAtPath:[self getFilePath:[NSString stringWithFormat:@"%@/%@",kLogDirectory,fileName]]
                                                           error:NULL];
            }
        }
        
        //Page
        if ([[NSFileManager defaultManager] fileExistsAtPath:[self getFilePath:kPageLog]])
        {
            if (_pageArray)
            {
                [_pageArray release];
            }
            _pageArray = [[NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:kPageLog]] retain];
            
            //反序列化如果没有数据
            if (_pageArray == nil)
            {
                _pageArray = [[NSMutableArray alloc] init];
            }
            
        }else
        {
            _pageArray = [[NSMutableArray alloc] init];
        }
        
        
        //从Log目录获取日志文件列表
        NSArray *pageFiles = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:[self getFilePath:kLogDirectory] error:nil];
        for (NSString *fileName in pageFiles)
        {
            if ([fileName hasPrefix:kAnotherPageLogPrefix])
            {
                id data = [NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:fileName]];
                if ([data isKindOfClass:[NSArray class]])
                {
                    [_pageArray addObjectsFromArray:data];
                }
                
                //合并后删除
                [[NSFileManager defaultManager] removeItemAtPath:[self getFilePath:[NSString stringWithFormat:@"%@/%@",kLogDirectory,fileName]] error:nil];
            }
        }
        
        
        //Event
        if ([[NSFileManager defaultManager] fileExistsAtPath:[self getFilePath:kEventLog]])
        {
            if (_eventArray)
            {
                [_eventArray release];
            }
            _eventArray = [[NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:kEventLog]] retain];
            
            //反序列化如果没有数据
            if (_eventArray == nil)
            {
                _eventArray = [[NSMutableArray alloc] init];
            }
        }else
        {
            _eventArray = [[NSMutableArray alloc] init];
        }
        
        
        //从Log目录获取日志文件列表
        NSArray *eventFiles = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:[self getFilePath:kLogDirectory] error:nil];
        for (NSString *fileName in eventFiles)
        {
            if ([fileName hasPrefix:kAnotherEventLogPrefix])
            {
                id data = [NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:fileName]];
                if ([_eventArray isKindOfClass:[NSArray class]])
                {
                    [_eventArray addObjectsFromArray:data];
                }
                //合并后删除
                [[NSFileManager defaultManager] removeItemAtPath:[self getFilePath:[NSString stringWithFormat:@"%@/%@",kLogDirectory,fileName]] error:nil];
            }
        }
        
        
        //EventKv
        if ([[NSFileManager defaultManager] fileExistsAtPath:[self getFilePath:kEventKvLog]])
        {
            if (_eventKvArray)
            {
                [_eventKvArray release];
            }
            _eventKvArray = [[NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:kEventKvLog]] retain];
            
            if (_eventKvArray == nil)
            {
                _eventKvArray = [[NSMutableArray alloc] init];
            }
        }else
        {
            _eventKvArray = [[NSMutableArray alloc] init];
        }
        
        
        //从Log目录获取日志文件列表
        NSArray *eventKvFile = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:[self getFilePath:kLogDirectory] error:nil];
        
        //合并数组
        for (NSString *fileName in eventKvFile)
        {
            if ([fileName hasPrefix:kAnotherEventKvLogPrefix])
            {
                
                id data = [NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:fileName]];
                if ([_eventKvArray isKindOfClass:[NSArray class]])
                {
                    [_eventKvArray addObjectsFromArray:data];
                }
                //合并后删除
                [[NSFileManager defaultManager] removeItemAtPath:[self getFilePath:[NSString stringWithFormat:@"%@/%@",kLogDirectory,fileName]] error:nil];
            }
        }
        
        
        //Error
        if ([[NSFileManager defaultManager] fileExistsAtPath:[self getFilePath:kErrorLog]])
        {
            if (_errorArray)
            {
                [_errorArray release];
            }
            _errorArray = [[NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:kErrorLog]] retain];
            
            if (_errorArray == nil)
            {
                _errorArray = [[NSMutableArray alloc] init];
            }
        }else
        {
            _errorArray = [[NSMutableArray alloc] init];
        }
        
        
        //从Log目录获取日志文件列表
        NSArray *errorFile = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:[self getFilePath:kLogDirectory] error:nil];
        for (NSString *fileName in errorFile)
        {
            if ([fileName hasPrefix:kAnotherErrorLogPrefix])
            {
                id data = [NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:fileName]];
                if ([_errorArray isKindOfClass:[NSArray class]])
                {
                    [_errorArray addObjectsFromArray:data];
                }
                //合并后删除
                [[NSFileManager defaultManager] removeItemAtPath:[self getFilePath:[NSString stringWithFormat:@"%@/%@",kLogDirectory,fileName]] error:nil];
            }
        }
        
        
        //临时数据
        if ([[NSFileManager defaultManager] fileExistsAtPath:[self getFilePath:kTemporaryDataLog]])
        {
            if (_temporaryDict)
            {
                [_temporaryDict release];
            }
            _temporaryDict = [[NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:kTemporaryDataLog]] retain];
            
            if (_temporaryDict == nil)
            {
                //实例化临时字典
                _temporaryDict = [[NSMutableDictionary alloc] init];
            }
        }else
        {
            _temporaryDict = [[NSMutableDictionary alloc] init];
        }
        
    };
    
    return self;
}


- (void)dealloc
{
    [_deviceDic release];
    [_launchArray release];
    [_exitArray release];
    [_pageArray release];
    [_eventArray release];
    [_eventKvArray release];
    [_errorArray release];
    
    [_temporaryDict release];

    [super dealloc];
}


/**
 *	@brief	获取存储数据的路径(Library文件下的Cache目录)
 *
 *	@param 	fileName 	文件名字符串
 *
 *	@return	文件完整路径
 */
- (NSString *)getFilePath:(NSString *)fileName
{
    NSArray *array = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    return [[array objectAtIndex:0] stringByAppendingString:fileName];
}


/**
 *	@brief	创建目录
 *
 *	@return	YES表示创建成功
 */
- (BOOL)createDirectoty

{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *logDirectory = [self getFilePath:kLogDirectory];
    
    return [fileManager createDirectoryAtPath:logDirectory
                  withIntermediateDirectories:YES
                                   attributes:nil
                                        error:nil];
}


/**
 *	@brief	删除日志
 *
 *	@param 	path 	数据日志相对路径
 *
 *	@return	void
 */
- (void)deleteLog:(NSString *)path

{
    [[NSFileManager defaultManager] removeItemAtPath:[self getFilePath:path] error:NULL];
}


#pragma mark - Device

- (void)writeDeviceLog
{
    OSDevice *deviceInfo = [[OpenStatistics sharedInstance] getDeviceInfo];
    
    NSMutableDictionary *deviceDic = [[[NSMutableDictionary alloc] init] autorelease];
    
    NSNumber *isJailbroken = [NSNumber numberWithInt:deviceInfo.isJailbroken];
    NSNumber *isPirated = [NSNumber numberWithInt:deviceInfo.isPirated];
    NSNumber *platformID = [NSNumber numberWithInt:deviceInfo.platformID];
    
    
    //
    if (deviceInfo.deviceID)
    {
        [deviceDic setObject:deviceInfo.deviceID forKey:@"device_id"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"device_id"];
    }
    
    if (deviceInfo.appVersion)
    {
        [deviceDic setObject:deviceInfo.appVersion forKey:@"appver"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"appver"];
    }
    
    if (deviceInfo.appPackage)
    {
        [deviceDic setObject:deviceInfo.appPackage forKey:@"apppkg"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"apppkg"];
    }
    
    
    if (platformID)
    {
        [deviceDic setObject:platformID forKey:@"platform_id"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"platform_id"];
    }
    
    if (deviceInfo.sdkVersion)
    {
        [deviceDic setObject:deviceInfo.sdkVersion forKey:@"sdkver"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"sdkver"];
    }
    
    //
    if (deviceInfo.channelName)
    {
        [deviceDic setObject:deviceInfo.channelName forKey:@"channel_name"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"channel_name"];
    }
    
    if (deviceInfo.mac)
    {
        [deviceDic setObject:deviceInfo.mac forKey:@"mac"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"mac"];
    }
    
    if (deviceInfo.model)
    {
        [deviceDic setObject:deviceInfo.model forKey:@"model"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"model"];
    }
    
    if (deviceInfo.sysVersion)
    {
        [deviceDic setObject:deviceInfo.sysVersion forKey:@"sysver"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"sysver"];
    }
    
    
    if (deviceInfo.carrier)
    {
        [deviceDic setObject:deviceInfo.carrier forKey:@"carrier"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"carrier"];
    }
    
    //
    if (deviceInfo.screenSize)
    {
        [deviceDic setObject:deviceInfo.screenSize forKey:@"screensize"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"screensize"];
    }
    
    if (deviceInfo.factory)
    {
        [deviceDic setObject:deviceInfo.factory forKey:@"factory"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"factory"];
    }
    
    if (deviceInfo.networkType)
    {
        [deviceDic setObject:deviceInfo.networkType forKey:@"networktype"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"networktype"];
    }
    
    if (isJailbroken)
    {
        [deviceDic setObject:isJailbroken forKey:@"is_jailbroken"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"is_jailbroken"];
    }
    
    
    if (isPirated)
    {
        [deviceDic setObject:isPirated forKey:@"is_pirate"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"is_pirate"];
    }
    
    //
    if (deviceInfo.longitude)
    {
        [deviceDic setObject:deviceInfo.longitude forKey:@"longitude"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"longitude"];
    }
    
    if (deviceInfo.latitude)
    {
        [deviceDic setObject:deviceInfo.latitude forKey:@"latitude"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"latitude"];
    }
    
    if (deviceInfo.language)
    {
        [deviceDic setObject:deviceInfo.language forKey:@"language"];
    }
    else
    {
        [deviceDic setObject:@"" forKey:@"language"];
    }
    
    if (deviceInfo.timeZone)
    {
        [deviceDic setObject:deviceInfo.timeZone forKey:@"timezone"];    //时区
    }
    
    [deviceDic setObject:@"" forKey:@"cpu"];         //设备cpu
    [deviceDic setObject:@"" forKey:@"manuid"];      //设备版本号
    [deviceDic setObject:@"" forKey:@"manutime"];    //设备出厂时间
    
    if ([[OpenStatistics sharedInstance] isLogEnabled])
    {
        NSLog(@"succeed in writing device data to log");
    }
    [self writeDeviceLog:deviceDic];
}


- (void)writeDeviceLog:(NSMutableDictionary *)dic
{
    if (_deviceDic)
    {
        [_deviceDic release];
    }
    _deviceDic = [dic retain];
    
    
    if ([[OpenStatistics sharedInstance] isLogEnabled])
    {
        NSLog(@"deviceDic:%@",_deviceDic);
    }
    
    //数据保存到日志
    [NSKeyedArchiver archiveRootObject:_deviceDic toFile:[self getFilePath:kDeviceLog]];
}


- (NSMutableDictionary *)readDeviceLog
{
    return [NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:kDeviceLog]];
}


#pragma mark - Launch
//启动数据写入日志
- (void)writeLaunchLog
{
    OSLaunch *launchData = [[OpenStatistics sharedInstance] getLaunchData];
    
    NSString *createDate = [OpenStatistics sharedInstance].createDate;     //获取启动时间
    NSString *lastEndDate = [[OpenStatistics sharedInstance] lastEndDate]; //获取上次退出时间
    

    NSMutableDictionary *launchDic = [[NSMutableDictionary alloc] init];
    
    //判断放入字典的数据是否为nil
    if (launchData.sessionID)
    {
        [launchDic setObject:launchData.sessionID forKey:@"session_id"];
    }else
    {
        [launchDic setObject:@"" forKey:@"session_id"];
    }
    
    if (createDate)
    {
        [launchDic setObject:createDate  forKey:@"create_date"];
    }else
    {
        [launchDic setObject:@""  forKey:@"create_date"];
    }
    
    if (lastEndDate)
    {
        [launchDic setObject:lastEndDate forKey:@"last_end_date"];
    }else
    {
        [launchDic setObject:@"0" forKey:@"last_end_date"];
    }
    
    if ([OpenStatistics sharedInstance].isLogEnabled)
    {
        NSLog(@"succeed in writing launch data to log");
    }
    
    [self writeLaunchLog:launchDic];
    
    [launchDic release];
}


- (void)writeLaunchLog:(NSDictionary *)dic
{
    //字典数据放入数组
    [_launchArray addObject:dic];
    
    if ([[OpenStatistics sharedInstance] isLogEnabled])
    {
        NSLog(@"launchArray:%@",_launchArray);
    }
    
    //数据写入文件
    [NSKeyedArchiver archiveRootObject:_launchArray toFile:[self getFilePath:kLaunchLog]];
    
}

//从日志中读取启动数据
- (NSMutableArray *)readLaunchLog:(NSTimeInterval)timeStamp
{
    //加入时间戳重命名
    [[NSFileManager defaultManager] moveItemAtPath:[self getFilePath:kLaunchLog]
                                            toPath:[self getFilePath:[NSString stringWithFormat:@"%@%.0f",kAnotherLaunchLog,timeStamp]]
                                             error:NULL];
    
    [_launchArray removeAllObjects];
    
    //读取并返回数据
    return [NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:[NSString stringWithFormat:@"%@%.0f",kAnotherLaunchLog,timeStamp]]];
}

#pragma mark - Exit
-(void)writeExitLog
{
    OSExit *exitData = [[OpenStatistics sharedInstance] getExitData];
    NSMutableDictionary *exitDic = [[NSMutableDictionary alloc] init];
    
    if (exitData.sessionID)
    {
        [exitDic setObject:exitData.sessionID forKey:@"session_id"];
    }else
    {
        [exitDic setObject:@"" forKey:@"create_date"];
    }
    
    if (exitData.createDate)
    {
        [exitDic setObject:exitData.createDate forKey:@"create_date"];
    }else
    {
        [exitDic setObject:@"" forKey:@"create_date"];
    }
    
    if (exitData.endDate)
    {
        [exitDic setObject:exitData.endDate forKey:@"end_date"];
    }else
    {
        [exitDic setObject:@"" forKey:@"end_date"];
    }
    
    if ([[OpenStatistics sharedInstance] isLogEnabled])
    {
        NSLog(@"succeed in writing exit data to log");
    }
    
    [self writeExitLog:exitDic];
    [exitDic release];
}

-(void)writeExitLog:(NSDictionary *)dic
{
    //字典数组放入数组
    [_exitArray addObject:dic];
    if ([[OpenStatistics sharedInstance] isLogEnabled])
    {
        NSLog(@"exitArray:%@",_exitArray);
    }
    //数据写入文件
    [NSKeyedArchiver archiveRootObject:_exitArray toFile:[self getFilePath:kExitLog]];
}

//从日志中读取退出数据
- (NSMutableArray *)readExitLog:(NSTimeInterval)timeStamp
{
    //加入时间戳重命名
    [[NSFileManager defaultManager] moveItemAtPath:[self getFilePath:kExitLog]
                                            toPath:[self getFilePath:[NSString stringWithFormat:@"%@%.0f",kAnotherExitLog,timeStamp]]
                                             error:NULL];
    [_exitArray removeAllObjects];
    //读取并返回数据
    return [NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:[NSString stringWithFormat:@"%@%.0f",kAnotherExitLog,timeStamp]]];
}


//退出时间的写入和取出
-(void)writeExitDateWithExitDate:(NSString *)exitDate
{
    NSMutableDictionary *endDateDic = [NSMutableDictionary dictionaryWithObject:exitDate forKey:@"exitDate"];
    
    if (endDateDic)
    {
        NSLog(@"退出数据日志路径：%@",kExitDateLog);
        [NSKeyedArchiver archiveRootObject:endDateDic toFile:[self getFilePath:kExitDateLog]];
    }else
    {
        NSLog(@"failed to write exitDate to log");
    }
}

-(NSString *)readExitDate
{
    return [[NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:kExitDateLog]] objectForKey:@"exitDate"];
}\


#pragma makr - Page
- (void)writePageLogWithSessionId:(NSString *)sessionId
                        startDate:(NSDate *)startDate
                             page:(NSString *)pag
                         fromPage:(NSString *)lastPageName
                         duration:(NSInteger)dura
{
    NSMutableDictionary *pageDataDic = [NSMutableDictionary dictionary];
    NSNumber *duration = [NSNumber numberWithLong:dura];
    
    
    if (sessionId)
    {
        [pageDataDic setObject:sessionId forKey:@"session_id"];
    }
    else
    {
        [pageDataDic setObject:@"" forKey:@"session_id"];
    }
    
    
    NSString *startTime= [NSDate getDateStr:startDate];
    if (startDate)
    {
        [pageDataDic setObject:startTime forKey:@"start_date"];
    }
    else
    {
        [pageDataDic setObject:@"" forKey:@"start_date"];
    }
    
    NSString *endTime= [NSDate getDateStr:[NSDate date]];
    
    if (endTime)
    {
        [pageDataDic setObject:endTime forKey:@"end_date"];
    }
    else
    {
        [pageDataDic setObject:@"" forKey:@"end_date"];
    }
    
    if (pag)
    {
        [pageDataDic setObject:pag forKey:@"page"];
    }
    else
    {
        [pageDataDic setObject:@"" forKey:@"page"];
    }
    
    if (lastPageName)
    {
        [pageDataDic setObject:lastPageName forKey:@"from_page"];
    }
    else
    {
        [pageDataDic setObject:@"" forKey:@"from_page"];
    }
    
    if (duration)
    {
        [pageDataDic setObject:duration forKey:@"duration"];
    }
    else
    {
        [pageDataDic setObject:@"" forKey:@"duration"];
    }
    
    if ([[OpenStatistics sharedInstance] isLogEnabled])
    {
        NSLog(@"succeed in writing page data to log");
    }
    
    [self writePageLog:pageDataDic];
}

- (void)writePageLog:(NSDictionary *)dic
{
    [_pageArray addObject:dic];
    
    if ([[OpenStatistics sharedInstance] isLogEnabled])
    {
        NSLog(@"pageArray：%@",_pageArray);
        
    }
    
    NSString *pageLogPath = [self getFilePath:kPageLog];
    
    if (_pageArray)
    {
        [NSKeyedArchiver archiveRootObject:_pageArray toFile:pageLogPath];
    }
    else
    {
        NSLog(@"failed to write page data to log");
    }
}


- (NSMutableArray *)readPageLog:(NSTimeInterval)timeStamp
{
    //加入时间戳重命名文件
    [[NSFileManager defaultManager] moveItemAtPath:[self getFilePath:kPageLog]
                                            toPath:[self getFilePath:[NSString stringWithFormat:@"%@%.0f",kAnotherPageLog,timeStamp]]
                                             error:NULL];
    [_pageArray removeAllObjects];
    
    //读取并返回数据
    return [NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:[NSString stringWithFormat:@"%@%.0f",kAnotherPageLog,timeStamp]]];
}


#pragma mark - 临时页面
- (void)writeTemporaryPageLogWithPageName:(NSString *)pageName
                                startDate:(NSDate *)date
{
    NSMutableDictionary *data = [NSMutableDictionary dictionaryWithObject:pageName forKey:@"pageName"];
    
    if (date)
    {
        [data setObject:date forKey:@"startDate"];
    }
    
    if ([[OpenStatistics sharedInstance] isLogEnabled])
    {
        NSLog(@"temporary page data:%@",data);
    }
    
    if (data)
    {
        [_temporaryDict setObject:data forKey:[NSString stringWithFormat:@"page%@",pageName]];
    }
    else
    {
        NSLog(@"页面：%@ 对应的开始数据为空",pageName);
    }
    
    if (_temporaryDict)
    {
        [NSKeyedArchiver archiveRootObject:_temporaryDict toFile:[self getFilePath:kTemporaryDataLog]];
    }
    else
    {
        NSLog(@"_temporaryDic为空，写入临时文件失败");
    }
    
}


- (NSDictionary *)getPageStartDate:(NSString *)pageName
{
    return [_temporaryDict objectForKey:[NSString stringWithFormat:@"page%@",pageName]];
}


#pragma mark - Event 

/**
 *	@brief	写入事件日志
 *
 *	@param 	eventId 	事件Id
 *	@param 	label 	标签
 *
 *	@return	void
 */
- (void)writeEventLogWithSessionId:(NSString *)sessionId
                        createDate:(NSDate *)date
                          eventKey:(NSString *)eventId
                              page:(NSString *)page
                             label:(NSString *)label
                         noticeNum:(NSInteger )noticeNum
                          duration:(NSInteger )durat
{
    NSNumber *noticeNumObj = [NSNumber numberWithInteger:noticeNum];
    NSNumber *duration = [NSNumber numberWithInteger:durat];
    NSMutableDictionary *eventDictData = [NSMutableDictionary dictionary];
    
    NSString *eventCreateDateStr = [NSDate getDateStr:date];
    
    if (sessionId)
    {
        [eventDictData setObject:sessionId forKey:@"session_id"];
    }
    else
    {
        [eventDictData setObject:@"" forKey:@"session_id"];
    }
    
    if (eventCreateDateStr)
    {
        [eventDictData setObject:eventCreateDateStr forKey:@"create_date"];
    }
    else
    {
        [eventDictData setObject:@"" forKey:@"create_date"];
    }
    
    if (eventId)
    {
        [eventDictData setObject:eventId forKey:@"eventkey"];
    }
    else
    {
        [eventDictData setObject:@"" forKey:@"eventkey"];
    }
    
    if (page)
    {
        [eventDictData setObject:page forKey:@"page"];
    }
    else
    {
        [eventDictData setObject:@"" forKey:@"page"];
    }
    
    if (label)
    {
        [eventDictData setObject:label forKey:@"label"];
    }
    else
    {
        [eventDictData setObject:@"" forKey:@"label"];
    }
    
    if (noticeNumObj)
    {
        [eventDictData setObject:noticeNumObj forKey:@"notice_num"];
    }
    else
    {
        [eventDictData setObject:@"" forKey:@"notice_num"];
    }
    
    if (duration)
    {
        [eventDictData setObject:duration forKey:@"duration"];
    }
    else
    {
        [eventDictData setObject:@"" forKey:@"duration"];
    }
    
    
    if ([OpenStatistics sharedInstance].isLogEnabled)
    {
        NSLog(@"succeed in writing event data to log");
    }
    [self writeEventLog:eventDictData];
}


/**
 *	@brief	将数据保存到本地日志
 *
 *	@param 	dic 	需要存到数组的字典数据
 *
 *	@return	void
 */
- (void)writeEventLog:(NSMutableDictionary *)dic
{
    //往数组添加一个事件字典
    [_eventArray addObject:dic];
    
    if ([OpenStatistics sharedInstance].isLogEnabled)
    {
        NSLog(@"eventArray:%@",_eventArray);
    }
    
    //数据保存到xxxx，覆盖原来的日志。
    NSString *eventLogPath = [self getFilePath:kEventLog];
    [NSKeyedArchiver archiveRootObject:_eventArray toFile:eventLogPath];
}



- (NSMutableArray *)readEventLog:(NSTimeInterval)timeStamp
{
    //加入时间戳重命名
    [[NSFileManager defaultManager] moveItemAtPath:[self getFilePath:kEventLog]
                                            toPath:[self getFilePath:[NSString stringWithFormat:@"%@%.0f",kAnotherEventLog,timeStamp]]
                                             error:NULL];
    
    [_eventArray removeAllObjects];
    
    //读取并返回数据
    return [NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:[NSString stringWithFormat:@"%@%.0f",kAnotherEventLog,timeStamp]]];
}


#pragma mark - 临时事件

- (void)writeTemporaryEventLogWithSessionId:(NSString *)eventkey
                                  startDate:(NSDate *)startDate
                                      label:(NSString *)label
                                       page:(NSString *)page
{
    NSString *eventKeyStr = [NSString stringWithFormat:@"event%@%@",eventkey,label];
    
    NSMutableDictionary *data = [NSMutableDictionary dictionaryWithObject:eventkey forKey:@"eventKey"];
    [data setObject:startDate forKey:@"startDate"];
    [data setObject:label forKey:@"label"];
    [data setObject:page forKey:@"pageName"];
    
    if (data)
    {
        [_temporaryDict setObject:data forKey:eventKeyStr];
        
    }
    else
    {
        NSLog(@"事件：%@ 对应的数据为空",eventkey);
    }
    
    [NSKeyedArchiver archiveRootObject:_temporaryDict toFile:[self getFilePath:kTemporaryDataLog]];
}

//获取事件开始时间
- (NSDictionary *)getEventStartDateWithEventId:(NSString *)eventId label:(NSString *)label
{
    return [_temporaryDict objectForKey:[NSString stringWithFormat:@"event%@%@",eventId,label]];
}


#pragma mark - EvnetKv
- (void)writeEventKvLogWithSessionId:(NSString *)sessionId
                          createDate:(NSDate *)date
                            eventKey:(NSString *)eventId
                                page:(NSString *)page
                          attributes:(NSDictionary *)attributes
                               label:(NSString *)label
                           noticeNum:(NSInteger)noticeNum
                            duration:(NSInteger)durat
{
    //基本数据类型的转化
    NSNumber *noticeNumObj = [NSNumber numberWithInteger:noticeNum];
    NSNumber *duration = [NSNumber numberWithInteger:durat];
    NSMutableDictionary *eventKvDictData = [NSMutableDictionary dictionary];
    
    NSString *eventKvCreateDateStr = [NSDate getDateStr:date];
    [eventKvDictData setObject:sessionId forKey:@"session_id"];
    
    if (eventKvCreateDateStr)
    {
        [eventKvDictData setObject:eventKvCreateDateStr forKey:@"create_date"];
    }
    else
    {
        [eventKvDictData setObject:@"" forKey:@"create_date"];
    }
    
    if (eventId)
    {
        [eventKvDictData setObject:eventId forKey:@"eventkey"];
    }
    else
    {
        [eventKvDictData setObject:@"" forKey:@"eventkey"];
    }
    
    if (page)
    {
        [eventKvDictData setObject:page forKey:@"page"];
    }
    else
    {
        [eventKvDictData setObject:@"" forKey:@"page"];
    }
    
    
    NSArray *keyArray = [attributes allKeys];
    NSMutableDictionary *newAttr = [NSMutableDictionary dictionary];
    for (int i = 0; i < 10 && i < [keyArray count]; i++)
    {
        NSString *key = [keyArray objectAtIndex:i];
        [newAttr setObject:[attributes objectForKey:key] forKey:key];
    }

    if (newAttr)
    {
        [eventKvDictData setObject:newAttr forKey:@"attributes"];
    }
    else
    {
        [eventKvDictData setObject:@"" forKey:@"attributes"];
    }
    
    if (label)
    {
        [eventKvDictData setObject:label forKey:@"label"];
    }
    else
    {
        [eventKvDictData setObject:@"" forKey:@"label"];
    }
    
    if (noticeNumObj)
    {
        [eventKvDictData setObject:noticeNumObj forKey:@"notice_num"];
    }
    else
    {
        [eventKvDictData setObject:@"" forKey:@"notice_num"];
    }
    
    if (duration)
    {
        [eventKvDictData setObject:duration forKey:@"duration"];
    }
    else
    {
        [eventKvDictData setObject:@"" forKey:@"duration"];
    }
    
    
    if ([OpenStatistics sharedInstance].isLogEnabled)
    {
        NSLog(@"事件数据写入日志。");
    }
    
    [self writeEventKvLog:eventKvDictData];
}

- (void)writeEventKvLog:(NSDictionary *)dic
{
    //往数组添加一个事件字典
    [_eventKvArray addObject:dic];
    
    //数据保存到xxxx，覆盖原来的日志。
    NSLog(@"eventKvArray:%@",_eventKvArray);
    NSString *eventKvLogPath = [self getFilePath:kEventKvLog];
    [NSKeyedArchiver archiveRootObject:_eventKvArray toFile:eventKvLogPath];
}


- (NSMutableArray *)readEventKvLog:(NSTimeInterval)timeStamp
{
    //加入时间戳重命名
    [[NSFileManager defaultManager] moveItemAtPath:[self getFilePath:kEventKvLog]
                                            toPath:[self getFilePath:[NSString stringWithFormat:@"%@%.0f",kAnotherEventKvLog,timeStamp]]
                                             error:NULL];
    
    [_eventKvArray removeAllObjects];
    
    //读取并返回数据
    return [NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:[NSString stringWithFormat:@"%@%.0f",kAnotherEventKvLog,timeStamp]]];
}


#pragma mark - 临时的EventKv
- (void)writeTemporaryEventKvLogWithEventKey:(NSString *)eventkey
                                   startDate:(NSDate *)startDate
                                  attributes:(NSDictionary *)attributes
                                  primarykey:(NSString *)keyName
                                       label:(NSString *)label
                                        page:(NSString *)page
{
    NSMutableDictionary *data = [NSMutableDictionary dictionaryWithObject:startDate forKey:@"startDate"];
    
    if (eventkey)
    {
        [data setObject:eventkey forKey:@"eventkey"];
    }
    
    if (attributes)
    {
        [data setObject:attributes forKey:@"attributes"];
    }
    
    if (label)
    {
        [data setObject:label forKey:@"label"];
    }
    
    if (page)
    {
        [data setObject:page forKey:@"pageName"];
    }
    
    
    NSString *eventKvStr = [NSString stringWithFormat:@"cEvent%@%@%@",eventkey,keyName,label];
    
    if (data)
    {
        [_temporaryDict setObject:data forKey:eventKvStr];
    }
    
    [NSKeyedArchiver archiveRootObject:_temporaryDict toFile:[self getFilePath:kTemporaryDataLog]];
}


//获取临时自定义事件的开始时间
- (NSDictionary *)getEventKvStartDateWithEventKey:(NSString *)eventkey
                                            label:(NSString *)label
                                       primarykey:(NSString *)keyName;
{
    return [_temporaryDict objectForKey:[NSString stringWithFormat:@"cEvent%@%@%@",eventkey,keyName,label]];
}


#pragma mark - Error
- (void)writeErrorLogWithSessionid:(NSString *)sessionId
                             page:(NSString *)page
                         errorLog:(NSString *)errLog
                       stackTrace:(NSString *)stackTrace
{
    NSMutableDictionary *errorDic = [[NSMutableDictionary alloc] init];
    [errorDic setObject:sessionId forKey:@"session_id"];
    
    if ([NSDate getDateStr:[NSDate date]])
    {
        [errorDic setObject:[NSDate getDateStr:[NSDate date]] forKey:@"create_date"];
    }
    else
    {
        [errorDic setObject:@"" forKey:@"create_date"];
    }
    
    if (page)
    {
        [errorDic setObject:page forKey:@"page"];
    }
    else
    {
        [errorDic setObject:@"" forKey:@"page"];
    }
    
    if (errLog)
    {
        [errorDic setObject:errLog forKey:@"error_log"];
    }
    else
    {
        [errorDic setObject:@"" forKey:@"error_log"];
    }
    
    if (stackTrace)
    {
        [errorDic setObject:stackTrace forKey:@"stack_trace"];
    }
    else
    {
        [errorDic setObject:@"" forKey:@"stack_trace"];
    }
    
    
    if ([OpenStatistics sharedInstance].isLogEnabled)
    {
        NSLog(@"错误异常数据写入日志。");
    }
    
    [self writeErrorLog:errorDic];
    
    [errorDic release];
}


- (void)writeErrorLog:(NSDictionary *)dic
{
    [_errorArray addObject:dic];
    
    NSLog(@"errorArray:%@",_errorArray);
    NSString *errorLogPath = [self getFilePath:kErrorLog];
    [NSKeyedArchiver archiveRootObject:_errorArray toFile:errorLogPath];
    
}


- (NSMutableArray *)readErrorLog:(NSTimeInterval)timeStamp
{
    //加入时间戳重命名
    [[NSFileManager defaultManager] moveItemAtPath:[self getFilePath:kErrorLog]
                                            toPath:[self getFilePath:[NSString stringWithFormat:@"%@%.0f",kAnotherErrorLog,timeStamp]]
                                             error:NULL];
    
    [_errorArray removeAllObjects];
    
    //读取并返回数据
    return [NSKeyedUnarchiver unarchiveObjectWithFile:[self getFilePath:[NSString stringWithFormat:@"%@%.0f",kAnotherErrorLog,timeStamp]]];
}


@end
