//
//  OSLog.h
//  OpenStatistics
//
//  Created by 刘 靖煌 on 14-2-27.
//  Copyright (c) 2014年 shareSDK. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OSEvent.h"
#import "OSDevice.h"


/**
 *	@brief	日志类，与日志操作相关
 */
@interface OSLog : NSObject

{
    NSMutableDictionary *_deviceDic; //设备数据
    
    NSMutableArray *_launchArray;    //应用启动数据
    NSMutableArray *_pageArray;      //页面数据
    NSMutableArray *_eventArray;     //事件数据
    NSMutableArray *_eventKvArray;   //事件参数值数据
    NSMutableArray *_errorArray;     //错误数据
    
    NSMutableDictionary *_temporaryDict;  //临时字典：用于存放临时事件的开始时间
}

@property (nonatomic, strong)NSMutableDictionary *deviceDic;
@property (nonatomic, strong)NSMutableArray *launchArray;
@property (nonatomic, strong)NSMutableArray *pageArray;
@property (nonatomic, strong)NSMutableArray *eventArray;
@property (nonatomic, strong)NSMutableArray *eventKvArray;
@property (nonatomic, strong)NSMutableArray *errorArray;

@property (nonatomic, strong)NSMutableDictionary *temporaryDict;



//获取存储数据的路径
- (NSString *)getFilePath:(NSString *)fileName;

//创建目录
- (BOOL)createDirectoty;

//删除日志
- (void)deleteLog:(NSString *)path;

#pragma mark - Device
- (void)writeDeviceLog:(NSMutableDictionary *)dic;
- (void)writeDeviceLog;
- (NSMutableDictionary *)readDeviceLog;


#pragma mark - Launch
- (void)writeLaunchLog:(NSDictionary *)dic;
- (void)writeLaunchLog;
- (NSMutableArray *)readLaunchLog:(NSTimeInterval)timeStamp;


#pragma mark - Page
- (void)writePageLog:(NSDictionary *)dic;
- (void)writePageLogWithSessionId:(NSString *)sessionId
                        startDate:(NSDate *)startDate
                             page:(NSString *)pag
                         duration:(NSInteger)dura;
- (NSMutableArray *)readPageLog:(NSTimeInterval)timeStamp;


#pragma mark - temporary Page 临时页面
- (void)writeTemporaryPageLogWithPageName:(NSString *)pageName
                                startDate:(NSDate *)date;
//获取页面开始时间
- (NSDictionary *)getPageStartDate:(NSString *)pageName;


#pragma mark - Event
- (void)writeEventLogWithSessionId:(NSString *)sessionId
                        createDate:(NSDate *)date
                          eventKey:(NSString *)eventId
                              page:(NSString *)page
                             label:(NSString *)label
                         noticeNum:(NSInteger )noticeNum
                          duration:(NSInteger )durat;
- (NSMutableArray *)readEventLog:(NSTimeInterval)timeStamp;


#pragma mark - temporary Event 临时事件
- (void)writeTemporaryEventLogWithSessionId:(NSString *)eventkey
                                  startDate:(NSDate *)startDate
                                      label:(NSString *)label
                                       page:(NSString *)page;
//获取事件开始时间
- (NSDictionary *)getEventStartDateWithEventId:(NSString *)eventId label:(NSString *)label;


#pragma mark - EvnetKv
- (void)writeEventKvLogWithSessionId:(NSString *)sessionId
                          createDate:(NSDate *)date
                            eventKey:(NSString *)eventId
                                page:(NSString *)page
                          attributes:(NSDictionary *)attributes
                               label:(NSString *)label
                           noticeNum:(NSInteger)noticeNum
                            duration:(NSInteger)durat;
- (void)writeEventKvLog:(NSDictionary *)dic;
- (NSMutableArray *)readEventKvLog:(NSTimeInterval)timeStamp;


#pragma mark - temporary EventKv
- (void)writeTemporaryEventKvLogWithEventKey:(NSString *)eventkey
                                   startDate:(NSDate *)startDate
                                  attributes:(NSDictionary *)attributes
                                  primarykey:(NSString *)keyName
                                       label:(NSString *)label
                                        page:(NSString *)page;
////获取事件开始时间
- (NSDictionary *)getEventKvStartDateWithEventKey:(NSString *)eventkey
                                            label:(NSString *)label
                                       primarykey:(NSString *)keyName;


#pragma mark - Error
- (void)writeErrorLogWithSessionid:(NSString *)sessionId
                             page:(NSString *)page
                         errorLog:(NSString *)errLog
                       stackTrace:(NSString *)stackTrace;
- (void)writeErrorLog:(NSDictionary *)dic;
- (NSMutableArray *)readErrorLog:(NSTimeInterval)timeStamp;

@end
