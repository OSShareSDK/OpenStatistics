//
//  OSService.m
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-3-24.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import "OSService.h"

#import "OSJSONKit.h"
#import "OSHTTPRequestParameters.h"
#import "OpenStatistics_extension.h"
#import "NSString+Common.h"
#import "NSData+Common.h"
#import "OSCommonReturn.h"
#import "OSHTTPPostedFile.h"


@implementation OSService


/**
 *	@brief	获取发送策略
 *
 *	@param 	appkey 	appkey
 *
 *	@return	return value description
 */
- (void)sendReportPolicyInfoWithAppKey:(NSString *)appkey
                               result:(void (^)(id))result
{
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:kGetReportPolicyURL]] ;
    
    [request setHTTPMethod:@"POST"];
    OSHTTPRequestParameters *params = [[OSHTTPRequestParameters alloc] init];
    [params addParameterWithName:@"appkey" value:appkey];
    [request setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
    
    _HT = [OSHTTPToken tokenWithRequest:request userData:nil worker:self];
    [_HT start];
    [params release];
    
    
    if (_resultHandler)
    {
        Block_release(_resultHandler);
    }
    _resultHandler = Block_copy(result);
}


#pragma mark - 请求数据
/**
 *	@brief	请求发送数据  把各个数组打包到字典（JSON），后转换压缩返回
 *
 *	@param 	deviceDic 	设备数据
 *	@param 	launchArray 	启动数据
 *	@param 	pageArray 	页面数据
 *	@param 	eventArray 	事件数据
 *	@param 	eventKvArray 	自定义事件数据
 *	@param 	errorArray 	异常错误数据
 *
 *	@return	压缩处理后的数据（NSString）
 */
- (NSString *)requestDataWithDeviceDic:(NSMutableDictionary *)deviceDic
                           launchArray:(NSMutableArray *)launchArray
                             pageArray:(NSMutableArray *)pageArray
                            eventArray:(NSMutableArray *)eventArray
                          eventKvArray:(NSMutableArray *)eventKvArray
                            errorArray:(NSMutableArray *)errorArray
{
    
    NSMutableDictionary *data = [NSMutableDictionary dictionary];
    if (deviceDic)
    {
        [data setObject:deviceDic forKey:@"device_data"];
    }
    
    if (launchArray)
    {
        [data setObject:launchArray forKey:@"launch_data"];
    }
    
    if (pageArray)
    {
        [data setObject:pageArray forKey:@"page_data"];
    }
    
    if (eventArray)
    {
        [data setObject:eventArray forKey:@"event_data"];
    }
    if (eventKvArray)
    {
        [data setObject:eventKvArray forKey:@"eventKv_data"];
    }
    if (errorArray)
    {
        [data setObject:errorArray forKey:@"error_data"];
    }

    
    if ([[OpenStatistics sharedInstance] isLogEnabled])
    {
        NSLog(@"要发送的数据：%@",data);
    }
    
    NSString *dataStr = [data JSONString];
    NSData *clientData = [dataStr dataUsingEncoding:NSUTF8StringEncoding];
    
    return [[clientData gzipData] stringWithBase64Encode];
}


/**
 *	@brief	发送客户端数据
 *
 *	@param 	appkey 	AppKey
 *	@param 	requestData 	要发送的数据
 *
 *	@return	void
 */
- (void)sendClientDataWithAppKey:(NSString *)appkey
                      clientData:(NSString *)requestData
                          result:(void (^)(id responder))result

{
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:kSendClientDataURL]] ;
    [request setHTTPMethod:@"POST"];
    OSHTTPRequestParameters *params = [[OSHTTPRequestParameters alloc] init];
    [params addParameterWithName:@"appkey" value:appkey];
    [params addParameterWithName:@"m" value:requestData];
    [request setHTTPBody:[params dataUsingEncoding:NSUTF8StringEncoding]];
    
    _HT = [OSHTTPToken tokenWithRequest:request userData:nil worker:self];
    [_HT start];
    [params release];
    
    if (_resultHandler)
    {
        Block_release(_resultHandler);
    }
    _resultHandler = Block_copy(result);
}


//下载完成
- (void)httpResult:(OSHTTPToken *)token
{
    NSString *returnStr = [[NSString alloc] initWithData:token.responseData encoding:NSUTF8StringEncoding];
    NSDictionary *returnDic = [returnStr objectFromJSONStringWithParseOptions:OSParseOptionLooseUnicode];
    
    if (_resultHandler)
    {
        _resultHandler (returnDic);
    }
    
    [returnStr release];
}


-(void)dealloc
{
    if (_resultHandler)
    {
        Block_release(_resultHandler);
    }
    
    [super dealloc];
}


#pragma mark - other
//以下几个方法是协议必须实现的方法，在此SDK暂时不需要用到，因此是空实现
- (void) httpCacheResult:(OSHTTPToken *)token cacheData:(NSString *)cacheData
{
    
}


- (void) httpFault:(OSHTTPToken *)token
{
    
}


- (NSString *)httpCacheData:(OSHTTPToken *)token
{
    return nil;
}


-(BOOL)httpShouldGetCacheData:(OSHTTPToken *)token
{
    return NO;
}


@end
