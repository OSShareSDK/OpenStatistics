//
//  OSService.h
//  OpenStatistics_Demo
//
//  Created by 刘 靖煌 on 14-3-24.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OSLog.h"
#import "OpenStatistics.h"
#import "OSHTTPToken.h"


//获取发送策略、发送数据的接口URL
#define kGetReportPolicyURL @"http://192.168.1.195/statistics.sharesdk.cn/api/index.php/client/config/getpolicy"
#define kSendClientDataURL @"http://192.168.1.195/statistics.sharesdk.cn/api/index.php/client/send/setdata"


/**
 *	@brief	服务类，和服务器端接口交互
 */
@interface OSService : NSObject<ICMHTTPWorker>
{
    OSHTTPToken *_HT;
    void(^_resultHandler)(id responder);
}


/**
 *	@brief	获取在线发送策略
 *
 *	@param 	appkey 	appkey
 *
 *	@return	void  
 */
-(void)sendReportPolicyInfoWithAppKey:(NSString *)appkey
                               result:(void(^)(id responder))result;


/**
 *	@brief	请求发送数据
 *
 *	@param 	deviceDic 	设备数据
 *	@param 	launchArray 	启动数据
 *	@param 	pageArray 	页面数据
 *	@param 	eventArray 	事件数据
 *	@param 	eventKvArray 	自定义事件数据
 *	@param 	errorArray 	异常错误数据
 *
 *	@return	处理后的数据
 */
- (NSString *)requestDataWithDeviceDic:(NSDictionary *)deviceDic
                           launchArray:(NSMutableArray *)launchArray
                             pageArray:(NSMutableArray *)pageArray
                            eventArray:(NSMutableArray *)eventArray
                          eventKvArray:(NSMutableArray *)eventKvArray
                            errorArray:(NSMutableArray *)errorArray;


/**
 *	@brief	发送客户端数据
 *
 *	@param 	appkey 	AppKey
 *	@param 	requestData 	要发送的数据
 *
 *	@return	void
 */
- (void)sendClientDataWithAppKey:(NSString *)appkey
                      clientData:(NSString *)requestData
                          result:(void(^)(id responder))result;



@end
