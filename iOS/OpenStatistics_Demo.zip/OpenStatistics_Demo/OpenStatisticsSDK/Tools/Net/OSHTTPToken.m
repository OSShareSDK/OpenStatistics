//
//  HTTPToken.m
//  Common
//
//  Created by 冯 鸿杰 on 12/8/18.
//
//

#import "OSHTTPToken.h"
#import "CoreDefinition.h"

@interface OSHTTPToken (Private)

/**
 *	@brief	获取获取数据线程
 */
- (void)doGetCacheDataThread;

/**
 *	@brief	执行请求
 */
- (void)doLoadRequest;

/**
 *	@brief	派发获取缓存数据通知
 *
 *  @param  cacheData    缓存数据
 */
- (void)postGetCacheDataNotification:(NSString *)cacheData;


@end

@implementation OSHTTPToken

@synthesize request = _request;
@synthesize userData = _userData;
@synthesize response = _response;
@synthesize responseData = _responseData;
@synthesize error = _error;

+ (OSHTTPToken *)tokenWithUrlString:(NSString *)urlString
                         userData:(id)userData
                           worker:(id<ICMHTTPWorker>)worker
{
    return [[[OSHTTPToken alloc] initWithURLString:urlString
                                        userData:userData
                                          worker:worker]
            autorelease];
}

+ (OSHTTPToken *)tokenWithUrl:(NSURL *)url
                   userData:(id)userData
                     worker:(id<ICMHTTPWorker>)worker
{
    return [[[OSHTTPToken alloc] initWithURL:url
                                  userData:userData
                                    worker:worker]
            autorelease];
}

+ (OSHTTPToken *)tokenWithRequest:(NSMutableURLRequest *)request
                       userData:(id)userData
                         worker:(id<ICMHTTPWorker>)worker
{
    return [[[OSHTTPToken alloc] initWithRequest:request
                                      userData:userData
                                        worker:worker]
            autorelease];
}

- (id)initWithURL:(NSURL *)url
         userData:(id)userData
           worker:(id<ICMHTTPWorker>)worker
{
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    if (self = [self initWithRequest:request userData:userData worker:worker])
    {
    }
    return self;
}

- (id)initWithURLString:(NSString *)urlString
               userData:(id)userData
                 worker:(id<ICMHTTPWorker>)worker
{
    NSURL *url = [NSURL URLWithString:urlString];
    if (self = [self initWithURL:url userData:userData worker:worker])
    {
    }
    return self;
}

- (id)initWithRequest:(NSMutableURLRequest *)request
             userData:(id)userData
               worker:(id<ICMHTTPWorker>)worker
{
    if(self = [super init])
    {
        _request = [request retain];
        _userData = [userData retain];
        
        _worker = [worker retain];
        _useCacheResponse = YES;
    }
    return self;
}

- (void)dealloc
{
    //如果在请求未响应时释放对象则需要取消HTTP请求
    [self cancelRequest];
    
    SAFE_RELEASE(_responseData);
    SAFE_RELEASE(_response);
    SAFE_RELEASE(_connection);
    SAFE_RELEASE(_worker);
    SAFE_RELEASE(_request);
    SAFE_RELEASE(_userData);
    SAFE_RELEASE(_error);
    
    [super dealloc];
}

- (void)start
{
    //取消上次请求
    [self cancelRequest];
    
    if ([_worker httpShouldGetCacheData:self])
    {
        [NSThread detachNewThreadSelector:@selector(doGetCacheDataThread) toTarget:self withObject:nil];
    }
    else
    {
        [self doLoadRequest];
    }
}

- (void)cancelRequest
{
    if (_connection)
    {
        [_connection cancel];
    }
}

- (NSString *)responseString:(NSStringEncoding)encoding
{
    if (_responseData)
    {
        return [[[NSString alloc] initWithData:_responseData encoding:encoding] autorelease];
    }
    
    return nil;
}

#pragma mark - Private

- (void)doLoadRequest
{
    if (_request)
    {
        [self cancelRequest];
        SAFE_RELEASE(_connection);
        
        //清空回复数据
        if (_responseData == nil)
        {
            _responseData = [[NSMutableData alloc] init];
        }
        [_responseData setData:nil];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            //发起请求
            SAFE_RELEASE(_connection);
            _connection = [[NSURLConnection alloc] initWithRequest:_request delegate:self];
            [_connection start];
            
        });

    }
}

- (void)doGetCacheDataThread
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    NSString *cacheData = [_worker httpCacheData:self];
    if (cacheData)
    {
        [self performSelectorOnMainThread:@selector(postGetCacheDataNotification:)
                               withObject:cacheData
                            waitUntilDone:NO];
    }
    else
    {
        //如果缓存数据为nil，则进行请求
        [self performSelectorOnMainThread:@selector(doLoadRequest)
                               withObject:nil
                            waitUntilDone:NO];
    }
    
    [pool release];
}

- (void)postGetCacheDataNotification:(NSString *)cacheData
{
    if (_worker)
    {
        [_worker httpCacheResult:self cacheData:cacheData];
    }
    else
    {
        [self postNotificationWithName:NOTIF_HTTP_CACHE_DATA
                                  data:[NSDictionary dictionaryWithObjectsAndKeys:
                                        cacheData,
                                        NOTIF_HTTP_KEY_CACHE_DATA,
                                        _userData,
                                        NOTIF_HTTP_KEY_USER_DATA,
                                        nil]];
    }
}

#pragma mark - NSURLConnectionDelegate

- (NSCachedURLResponse *)connection:(NSURLConnection *)connection willCacheResponse:(NSCachedURLResponse *)cachedResponse
{
    if (!_useCacheResponse)
    {
        return nil;
    }
    
    return cachedResponse;
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    SAFE_RELEASE(_connection);
    SAFE_RELEASE(_error);
    
    _error = [error retain];
    
    if (_worker)
    {
        [_worker httpFault:self];
    }
    else
    {
        [self postNotificationWithName:NOTIF_HTTP_ERROR
                                  data:[NSDictionary dictionaryWithObjectsAndKeys:
                                        _error,
                                        NOTIF_HTTP_KEY_ERROR,
                                        _userData,
                                        NOTIF_HTTP_KEY_USER_DATA,
                                        nil]];
    }
}

#pragma mark - NSURLConnectionDataDelegate

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    SAFE_RELEASE(_response);
    _response = (NSHTTPURLResponse *)[response retain];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [_responseData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    SAFE_RELEASE(_connection);
    SAFE_RELEASE(_error);
    
    if (_worker)
    {
        [_worker httpResult:self];
    }
    else
    {
        [self postNotificationWithName:NOTIF_HTTP_RESULT
                                  data:[NSDictionary dictionaryWithObjectsAndKeys:
                                        _response,
                                        NOTIF_HTTP_KEY_RESPONSE,
                                        _responseData,
                                        NOTIF_HTTP_KEY_RESPONSE_DATA,
                                        _userData,
                                        NOTIF_HTTP_KEY_USER_DATA,
                                        nil]];
    }
}

@end
