//
//  HTTPPostedFile.m
//  CommonModule
//
//  Created by 冯 鸿杰 on 12-11-27.
//  Copyright (c) 2012年 掌淘科技. All rights reserved.
//

#import "CoreDefinition.h"
#import "OSHTTPPostedFile.h"

@implementation OSHTTPPostedFile

@synthesize fileName = _fileName;
@synthesize fileData = _fileData;
@synthesize contentType = _contentType;
@synthesize transferEncoding = _transferEncoding;

- (id)initWithFileName:(NSString *)fileName
                  data:(NSData *)data
           contentType:(NSString *)contentType
{
    if (self = [super init])
    {
        _fileName = [fileName copy];
        _fileData = [data retain];
        _contentType = [contentType copy];
        _transferEncoding = nil;
    }
    
    return self;
}

- (id)initWithFileName:(NSString *)fileName
                  data:(NSData *)data
           contentType:(NSString *)contentType
      transferEncoding:(NSString *)transferEncoding
{
    if (self = [super init])
    {
        _fileName = [fileName copy];
        _fileData = [data retain];
        _contentType = [contentType copy];
        _transferEncoding = [transferEncoding copy];
    }
    
    return self;
}

- (id)initWithFilePath:(NSString *)path contentType:(NSString *)contentType
{
    NSString *fileName = [path lastPathComponent];
    NSData *data = [NSData dataWithContentsOfFile:path];
    if (self = [self initWithFileName:fileName data:data contentType:contentType])
    {
        
    }
    
    return self;
}

- (void)dealloc
{
    SAFE_RELEASE(_fileName);
    SAFE_RELEASE(_fileData);
    SAFE_RELEASE(_contentType);
    SAFE_RELEASE(_transferEncoding);
    
    [super dealloc];
}


@end
