//
//  NSData+Common.m
//  Common
//
//  Created by 冯 鸿杰 on 12/8/20.
//
//

#import "NSData+Common.h"
#import <CommonCrypto/CommonHMAC.h>
#import <zlib.h>

@interface NSData (Private)

/**
 *	@brief	AES128位加/解密
 *
 *	@param 	operation 	操作类型（加密/解密）
 *	@param 	key 	密钥
 *	@param 	iv 	初始向量,允许为nil
 *  @param  options     选项
 *
 *	@return	加密后数据
 */
- (NSData *)dataUsingAES128Operation:(CCOperation)operation
                                 key:(NSData *)key
                                  iv:(NSData *)iv
                             options:(CCOptions)options;

/**
 *	@brief	AES256位加密/解密
 *
 *  @param  operation 	操作类型（加密/解密）
 *	@param 	key 	密钥
 *  @param  iv      初始化向量，允许为nil
 *  @param  options     选项
 *
 *	@return	加密后数据
 */
- (NSData *)dataUsingAES256EncryptOperation:(CCOperation)operation
                                        key:(NSData *)key
                                         iv:(NSData *)iv
                                    options:(CCOptions)options;

@end

@implementation NSData (Private)

- (NSData *)dataUsingAES128Operation:(CCOperation)operation
                                 key:(NSData *)key
                                  iv:(NSData *)iv
                             options:(CCOptions)options
{
//    if (operation == 0)
//    {
//        operation = kCCOptionPKCS7Padding | kCCOptionECBMode;
//    }
    
    char keyPtr[kCCKeySizeAES128 + 1];
    memset(keyPtr, 0, sizeof(keyPtr));
    [key getBytes:keyPtr length:sizeof(keyPtr)];
//    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:encoding];
    
    char *ivPtr = NULL;
    if (iv)
    {
        char ivStr[kCCBlockSizeAES128 + 1];
        memset(ivStr, 0, sizeof(ivStr));
        [iv getBytes:ivPtr length:sizeof(ivStr)];
//        [iv getCString:ivPtr maxLength:sizeof(ivStr) encoding:encoding];
        ivPtr = ivStr;
    }
    
    NSUInteger dataLength = [self length];
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    
    size_t numBytesCrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(operation,
                                          kCCAlgorithmAES128,
                                          options,
                                          keyPtr,
                                          kCCBlockSizeAES128,
                                          ivPtr,
                                          [self bytes],
                                          dataLength,
                                          buffer,
                                          bufferSize,
                                          &numBytesCrypted);
    if (cryptStatus == kCCSuccess)
    {
        return [NSData dataWithBytesNoCopy:buffer length:numBytesCrypted];
    }
    
    free(buffer);
    return nil;
}

- (NSData *)dataUsingAES256EncryptOperation:(CCOperation)operation
                                        key:(NSData *)key
                                         iv:(NSData *)iv
                                    options:(CCOptions)options
{
//    if (operation == 0)
//    {
//        operation = kCCOptionPKCS7Padding | kCCOptionECBMode;
//    }
    
	// 'key' should be 32 bytes for AES256, will be null-padded otherwise
	char keyPtr[kCCKeySizeAES256+1]; // room for terminator (unused)
	bzero(keyPtr, sizeof(keyPtr)); // fill with zeroes (for padding)
    [key getBytes:keyPtr length:sizeof(keyPtr)];
//    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:encoding];
    
    char *ivPtr = NULL;
    if (iv)
    {
        char ivStr[kCCBlockSizeAES128 + 1];
        memset(ivStr, 0, sizeof(ivStr));
        [iv getBytes:ivStr length:sizeof(ivStr)];
//        [iv getCString:ivPtr maxLength:sizeof(ivStr) encoding:encoding];
        ivPtr = ivStr;
    }
    
	NSUInteger dataLength = [self length];
	size_t bufferSize = dataLength + kCCBlockSizeAES128;
	void *buffer = malloc(bufferSize);
    bzero(buffer, sizeof(buffer));
	
	size_t numBytesEncrypted = 0;
	CCCryptorStatus cryptStatus = CCCrypt(operation,
                                          kCCAlgorithmAES128,
                                          options,
                                          keyPtr,
                                          kCCKeySizeAES256,
										  ivPtr, /* initialization vector (optional) */
										  [self bytes],
                                          dataLength, /* input */
										  buffer, bufferSize, /* output */
										  &numBytesEncrypted);
	if (cryptStatus == kCCSuccess)
    {
        return [NSData dataWithBytesNoCopy:buffer length:numBytesEncrypted];
	}
	
	free(buffer); //free the buffer;
	return nil;
}

@end

@implementation NSData (Common)

- (NSData *)dataByUsingHMacSHA1WithKey:(NSData *)key
{
    void* buffer = malloc(CC_SHA1_DIGEST_LENGTH);
    CCHmac(kCCHmacAlgSHA1, [key bytes], [key length], [self bytes], [self length], buffer);
    return [NSData dataWithBytesNoCopy:buffer length:CC_SHA1_DIGEST_LENGTH freeWhenDone:YES];
}

- (NSString *)stringWithBase64Encode
{
    static char base64EncodingTable[64] =
    {
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
        'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
        'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
        'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'
    };
    
    NSData *data = self;
    
    int length = [data length];
    unsigned long ixtext, lentext;
    long ctremaining;
    unsigned char input[3], output[4];
    short i, charsonline = 0, ctcopy;
    const unsigned char *raw;
    
    NSMutableString *result;
    lentext = [data length];
    
    if (lentext < 1)
    {
        return @"";
    }
    
    result = [NSMutableString stringWithCapacity: lentext];
    raw = [data bytes];
    ixtext = 0;
    
    while (true)
    {
        
        ctremaining = lentext - ixtext;
        if (ctremaining <= 0)
        {
            break;
        }
        
        for (i = 0; i < 3; i++)
        {
            unsigned long ix = ixtext + i;
            if (ix < lentext)
            {
                input[i] = raw[ix];
            }
            else
            {
                input[i] = 0;
            }
        }
        
        output[0] = (input[0] & 0xFC) >> 2;
        output[1] = ((input[0] & 0x03) << 4) | ((input[1] & 0xF0) >> 4);
        output[2] = ((input[1] & 0x0F) << 2) | ((input[2] & 0xC0) >> 6);
        output[3] = input[2] & 0x3F;
        
        ctcopy = 4;
        
        switch (ctremaining)
        {
                
            case 1:
                ctcopy = 2;
                break;
            case 2:
                ctcopy = 3;
                break;
                
        }
        
        for (i = 0; i < ctcopy; i++)
        {
            [result appendString: [NSString stringWithFormat: @"%c", base64EncodingTable[output[i]]]];
        }
        
        for (i = ctcopy; i < 4; i++)
        {
            [result appendString: @"="];
        }
        
        ixtext += 3;
        charsonline += 4;
        
        if ((length > 0) && (charsonline >= length))
        {
            charsonline = 0;
        }
    }
    
    return result;
}

- (NSString *)hexString
{
    NSMutableString *hexStr = [NSMutableString string];
    const char *buf = [self bytes];
    for (int i = 0; i < [self length]; i++)
    {
        [hexStr appendFormat:@"%02X", buf[i] & 0xff];
    }
    
    return hexStr;
}

- (NSData *)dataUsingAES128EncryptWithKey:(NSString *)key
                                       iv:(NSString *)iv
                                 encoding:(NSStringEncoding)encoding
{
    return [self dataUsingAES128EncryptWithKey:[key dataUsingEncoding:encoding]
                                            iv:[iv dataUsingEncoding:encoding]
                                       options:kCCOptionPKCS7Padding | kCCOptionECBMode];
}

- (NSData *)dataUsingAES128DecryptWithKey:(NSString *)key
                                       iv:(NSString *)iv
                                 encoding:(NSStringEncoding)encoding
{
    return [self dataUsingAES128DecryptWithKey:[key dataUsingEncoding:encoding]
                                            iv:[iv dataUsingEncoding:encoding]
                                       options:kCCOptionPKCS7Padding | kCCOptionECBMode];
}

- (NSData *)dataUsingAES128EncryptWithKey:(NSData *)key
                                       iv:(NSData *)iv
                                  options:(CCOptions)options
{
    return [self dataUsingAES128Operation:kCCEncrypt
                                      key:key
                                       iv:iv
                                  options:options];
}

- (NSData *)dataUsingAES128DecryptWithKey:(NSData *)key
                                       iv:(NSData *)iv
                                  options:(CCOptions)options
{
    return [self dataUsingAES128Operation:kCCDecrypt
                                      key:key
                                       iv:iv
                                  options:options];
}

- (NSData *)dataUsingAES256EncryptWithKey:(NSString *)key
                                       iv:(NSString *)iv
                                 encoding:(NSStringEncoding)encoding
{
    return [self dataUsingAES256EncryptWithKey:[key dataUsingEncoding:encoding]
                                            iv:[iv dataUsingEncoding:encoding]
                                       options:kCCOptionPKCS7Padding | kCCOptionECBMode];
}

- (NSData *)dataUsingAES256DecryptWithKey:(NSString *)key
                                       iv:(NSString *)iv
                                 encoding:(NSStringEncoding)encoding
{
    return [self dataUsingAES256DecryptWithKey:[key dataUsingEncoding:encoding]
                                            iv:[iv dataUsingEncoding:encoding]
                                       options:kCCOptionPKCS7Padding | kCCOptionECBMode];
}

- (NSData *)dataUsingAES256EncryptWithKey:(NSData *)key
                                       iv:(NSData *)iv
                                  options:(CCOptions)options
{
    return [self dataUsingAES256EncryptOperation:kCCEncrypt
                                             key:key
                                              iv:iv
                                         options:options];
}

- (NSData *)dataUsingAES256DecryptWithKey:(NSData *)key
                                       iv:(NSData *)iv
                                  options:(CCOptions)options
{
    return [self dataUsingAES256EncryptOperation:kCCDecrypt
                                             key:key
                                              iv:iv
                                         options:options];
}

- (NSData *)gzipData
{
    if ([self length] == 0)
    {
        return self;
    }
    
    z_stream strm;
    
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    strm.total_out = 0;
    strm.next_in=(Bytef *)[self bytes];
    strm.avail_in = [self length];
    
    // Compresssion Levels:
    //   Z_NO_COMPRESSION
    //   Z_BEST_SPEED
    //   Z_BEST_COMPRESSION
    //   Z_DEFAULT_COMPRESSION
    
    if (deflateInit2(&strm, Z_DEFAULT_COMPRESSION, Z_DEFLATED, (15+16), 8, Z_DEFAULT_STRATEGY) != Z_OK) return nil;
    
    NSMutableData *compressed = [NSMutableData dataWithLength:16384];  // 16K chunks for expansion
    
    do {
        
        if (strm.total_out >= [compressed length])
            [compressed increaseLengthBy: 16384];
        
        strm.next_out = [compressed mutableBytes] + strm.total_out;
        strm.avail_out = [compressed length] - strm.total_out;
        
        deflate(&strm, Z_FINISH);
        
    } while (strm.avail_out == 0);
    
    deflateEnd(&strm);
    
    [compressed setLength: strm.total_out];
    return [NSData dataWithData:compressed];
}

- (NSData *)uncompressGZipData;
{
	if ([self length] == 0)
    {
		return self;
	}
	
    unsigned full_length = [self length];
    unsigned half_length = [self length] / 2;
	
    NSMutableData *decompressed = [NSMutableData dataWithLength: full_length + half_length];
    BOOL done = NO;
    int status;
    
    z_stream strm;
    strm.next_in = (Bytef *)[self bytes];
    strm.avail_in = [self length];
    strm.total_out = 0;
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    if (inflateInit2(&strm, (15+32)) != Z_OK)
		return nil;
    while (!done) {
        // Make sure we have enough room and reset the lengths.
        if (strm.total_out >= [decompressed length]) {
            [decompressed increaseLengthBy: half_length];
        }
        strm.next_out = [decompressed mutableBytes] + strm.total_out;
        strm.avail_out = [decompressed length] - strm.total_out;
        // Inflate another chunk.
        status = inflate (&strm, Z_SYNC_FLUSH);
        if (status == Z_STREAM_END) {
            done = YES;
        } else if (status != Z_OK) {
            break;
        }
		
    }
    if (inflateEnd (&strm) != Z_OK)
		return nil;
    // Set real length.
    if (done) {
        [decompressed setLength: strm.total_out];
        return [NSData dataWithData: decompressed];
    } else {
        return nil;
    }
}

- (NSData *)dataByUsingMD5
{
    unsigned char result[CC_MD5_DIGEST_LENGTH];
    CC_MD5([self bytes], [self length], result);
    
    return [NSData dataWithBytes:result length:CC_MD5_DIGEST_LENGTH];
}

@end
