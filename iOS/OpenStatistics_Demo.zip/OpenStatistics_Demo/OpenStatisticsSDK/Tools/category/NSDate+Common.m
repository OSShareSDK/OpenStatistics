//
//  NSDate+Additions.m
//  MeYou
//
//  Created by hower on 7/5/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "NSDate+Common.h"

@implementation NSDate (Common)

+ (NSDate *)dateByStringFormat:(NSString *)format dateString:(NSString *)dateString
{
	NSDateFormatter *formatter=[[NSDateFormatter alloc] init];
	[formatter setDateFormat:format];
	NSDate *date=[formatter dateFromString:dateString];
	[formatter release];
	
	return date;
}

+ (NSDate *)dateByStringFormat:(NSString *)format dateString:(NSString *)dateString locale:(NSLocale *)locale
{
    NSDateFormatter *formatter=[[NSDateFormatter alloc] init];
	[formatter setDateFormat:format];
    [formatter setLocale:locale];
	NSDate *date=[formatter dateFromString:dateString];
	[formatter release];
	
	return date;
}

+ (NSString *)stringByStringFormat:(NSString *)format data:(NSDate *)date
{
	NSDateFormatter *formatter=[[NSDateFormatter alloc] init];
	[formatter setDateFormat:format];
	NSString *dateStr=[formatter stringFromDate:date];
	[formatter release];
    
	return dateStr;
}


/**
 *	@brief	获取当地时间字符串(考虑时区)
 *
 *	@return	NSString
 */
+ (NSDate *)getCurrentTime
{
    NSDateFormatter *dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
    dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"ABC"];
    [dateFormatter setTimeZone:gmt];
    NSString *timeStamp = [dateFormatter stringFromDate:[NSDate date]];
    
    NSDate *localDate = [dateFormatter dateFromString:timeStamp];
    
    return localDate;
    [dateFormatter release];
}


/**
 *	@brief	获取当地时间（考虑时区）
 *
 *	@return	当地时间
 */
+ (NSDate *)getCurrentDate
{
    NSDate *currentDate = [NSDate date];
    NSTimeZone *zone = [NSTimeZone systemTimeZone];
    NSInteger interval = [zone secondsFromGMTForDate:currentDate];
    NSDate *localDate = [currentDate dateByAddingTimeInterval:interval];
    return localDate;
}


/**
 *	@brief	把NSDate转换成NSString(注意用 NSDateFormatter 后会自动考虑上时区)
 *
 *	@param 	inputDate 	需要转换的时间
 *
 *	@return	时间字符串
 */
+ (NSString *)getDateStr:(NSDate *)inputDate
{
    NSDateFormatter *dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
    dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    NSString *timeStamp = [dateFormatter stringFromDate:inputDate];
    return timeStamp;
    
    [dateFormatter release];
}

+ (NSString*) stringFromFomate:(NSDate*) date formate:(NSString*)formate {
	NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
	[formatter setDateFormat:formate];
	NSString *str = [formatter stringFromDate:date];
	[formatter release];
	return str;
}

+ (NSDate *) dateFromFomate:(NSString *)datestring formate:(NSString*)formate
{
	NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:formate];
    NSDate *date = [formatter dateFromString:datestring];
    [formatter release];
    return date;
}

+ (NSDate *)getLocalCurrentDate
{
    NSDate *currentDate = [NSDate date];
    NSInteger interval = [[NSTimeZone systemTimeZone] secondsFromGMTForDate:currentDate];
    NSDate *localCurrentDate = [currentDate dateByAddingTimeInterval:interval];
    return localCurrentDate;
}


@end
